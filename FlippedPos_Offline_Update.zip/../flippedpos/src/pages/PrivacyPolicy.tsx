import { useEffect } from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function PrivacyPolicy() {
  useEffect(() => { window.scrollTo(0, 0) }, [])

  return (
    <div className="min-h-screen bg-[#080a0e] text-zinc-100">
      <Navbar />
      <div className="max-w-4xl mx-auto px-6 pt-32 pb-16">
        <div className="mb-10">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-3">Legal</p>
          <h1 className="text-4xl font-black text-white mb-3">Privacy Policy</h1>
          <p className="text-zinc-500 text-sm">Last updated: April 2026</p>
        </div>

        <div className="space-y-8 text-zinc-300 leading-relaxed">

          <Section title="1. Introduction">
            <p>FlippedPos ("we", "our", or "us") is committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our point-of-sale software and visit our website.</p>
            <p>Please read this policy carefully. If you disagree with its terms, please discontinue use of our services.</p>
          </Section>

          <Section title="2. Information We Collect">
            <p>We may collect the following types of information:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong className="text-white">Account Information:</strong> Business name, administrator name, email address, and phone number provided during setup.</li>
              <li><strong className="text-white">Business Data:</strong> Product listings, sales records, customer records, inventory data, and financial transactions entered into the system.</li>
              <li><strong className="text-white">Usage Data:</strong> Log files, IP addresses, browser type, pages visited, and timestamps when you access our hosted service.</li>
              <li><strong className="text-white">Device Information:</strong> Device type, operating system, and browser information for compatibility purposes.</li>
              <li><strong className="text-white">Payment Information:</strong> For paid plans, billing details are processed securely by our payment provider and are not stored on our servers.</li>
            </ul>
          </Section>

          <Section title="3. How We Use Your Information">
            <p>We use the information we collect to:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Provide, operate, and maintain the FlippedPos software and services.</li>
              <li>Process transactions and send related billing information.</li>
              <li>Send technical notices, updates, security alerts, and support messages.</li>
              <li>Respond to customer support requests and questions.</li>
              <li>Monitor and analyse usage patterns to improve the product.</li>
              <li>Detect, prevent, and address technical issues or fraudulent activity.</li>
            </ul>
          </Section>

          <Section title="4. Self-Hosted Deployments">
            <p>If you choose to self-host FlippedPos on your own server or infrastructure, we do not have access to your business data, customer records, or any information stored in your database. You are solely responsible for the security and management of that data, including compliance with applicable local laws.</p>
          </Section>

          <Section title="5. Data Sharing and Disclosure">
            <p>We do not sell, trade, or rent your personal information to third parties. We may share information only in these limited circumstances:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong className="text-white">Service Providers:</strong> Trusted third-party vendors who assist in operating our services, bound by confidentiality agreements.</li>
              <li><strong className="text-white">Legal Requirements:</strong> When required by law, court order, or governmental authority.</li>
              <li><strong className="text-white">Business Transfers:</strong> In connection with a merger or acquisition, with notice provided to users.</li>
            </ul>
          </Section>

          <Section title="6. Data Security">
            <p>We implement industry-standard security measures including encrypted connections (HTTPS/TLS), secure database access controls, and regular security reviews. However, no method of transmission over the Internet is 100% secure.</p>
          </Section>

          <Section title="7. Data Retention">
            <p>We retain your account and business data for as long as your account is active or as needed to provide services. Upon account termination, data will be deleted or anonymised within 90 days, unless retention is required by law.</p>
          </Section>

          <Section title="8. Your Rights">
            <p>You may have the right to: access your personal data, request correction or deletion, object to processing, and receive a portable copy of your data. Contact us at <strong className="text-brand">info@flippedpos.com</strong> to exercise these rights.</p>
          </Section>

          <Section title="9. Cookies">
            <p>Our website uses minimal cookies necessary for the site to function (session management, security tokens). We do not use advertising or tracking cookies.</p>
          </Section>

          <Section title="10. Changes to This Policy">
            <p>We may update this Privacy Policy from time to time. We will notify users of significant changes by posting a notice on our website. Continued use of our services after changes are posted constitutes acceptance.</p>
          </Section>

          <Section title="11. Contact Us">
            <div className="card-border rounded-xl p-5 space-y-1">
              <p><strong className="text-white">FlippedPos</strong></p>
              <p>Juba, South Sudan</p>
              <p>Email: <a href="mailto:info@flippedpos.com" className="text-brand hover:underline">info@flippedpos.com</a></p>
              <p>Phone: <a href="tel:+211920000000" className="text-brand hover:underline">+211 92 000 0000</a></p>
            </div>
          </Section>

        </div>
      </div>
      <Footer />
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-3 pb-2 border-b border-white/8">{title}</h2>
      <div className="space-y-3 text-zinc-400">{children}</div>
    </div>
  )
}
