import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import { Terminal, Download, Play, Database } from 'lucide-react'

export default function DockerSetup() {
  return (
    <div className="min-h-screen bg-[#080a0e] text-zinc-100 flex flex-col">
      <Navbar />
      <main className="flex-1 max-w-4xl mx-auto w-full px-6 py-24">
        <h1 className="text-4xl md:text-5xl font-black text-white mb-6">
          <span className="gradient-text">Docker</span> Setup Guide
        </h1>
        <p className="text-lg text-zinc-400 mb-12">
          Follow these step-by-step instructions to get FlippedPos running locally on your machine using Docker.
        </p>

        <div className="space-y-12">
          {/* Step 1 */}
          <section className="relative pl-10 border-l border-white/10 pb-2">
            <div className="absolute top-0 left-[-20px] w-10 h-10 rounded-xl bg-brand/10 border border-brand/20 flex items-center justify-center text-brand">
              <Download size={20} />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">1. Clone the Repository</h2>
            <p className="text-zinc-400 mb-4">
              First, download the FlippedPos source code to your local machine using Git.
            </p>
            <div className="bg-black/50 border border-white/5 rounded-xl p-4 font-mono text-sm text-zinc-300">
              git clone https://github.com/kembe699/davinscs.git<br/>
              cd davinscs
            </div>
          </section>

          {/* Step 2 */}
          <section className="relative pl-10 border-l border-white/10 pb-2">
            <div className="absolute top-0 left-[-20px] w-10 h-10 rounded-xl bg-brand/10 border border-brand/20 flex items-center justify-center text-brand">
              <Terminal size={20} />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">2. Configure Environment Variables</h2>
            <p className="text-zinc-400 mb-4">
              Copy the example environment file and update it with your settings. The default settings will work out of the box for a local test.
            </p>
            <div className="bg-black/50 border border-white/5 rounded-xl p-4 font-mono text-sm text-zinc-300">
              cp .env.example .env
            </div>
          </section>

          {/* Step 3 */}
          <section className="relative pl-10 border-l border-white/10 pb-2">
            <div className="absolute top-0 left-[-20px] w-10 h-10 rounded-xl bg-brand/10 border border-brand/20 flex items-center justify-center text-brand">
              <Database size={20} />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">3. Start the Services</h2>
            <p className="text-zinc-400 mb-4">
              Use Docker Compose to build and start the application containers. This will automatically pull the necessary images, set up the database, and run both the API and the frontend.
            </p>
            <div className="bg-black/50 border border-white/5 rounded-xl p-4 font-mono text-sm text-zinc-300">
              docker-compose up -d --build
            </div>
          </section>

          {/* Step 4 */}
          <section className="relative pl-10 border-l border-transparent">
            <div className="absolute top-0 left-[-20px] w-10 h-10 rounded-xl bg-brand/10 border border-brand/20 flex items-center justify-center text-brand">
              <Play size={20} />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">4. Access the Application</h2>
            <p className="text-zinc-400 mb-4">
              Once the containers are up and running, you can access the FlippedPos dashboard in your web browser.
            </p>
            <div className="bg-black/50 border border-white/5 rounded-xl p-4">
              <p className="text-zinc-300 mb-2"><span className="font-semibold text-brand">Frontend Dashboard:</span> http://localhost:3000</p>
              <p className="text-zinc-300 mb-2"><span className="font-semibold text-brand">Backend API:</span> http://localhost:8000</p>
              <p className="text-zinc-300"><span className="font-semibold text-brand">Default Login:</span> admin@flippedpos.com / password</p>
            </div>
          </section>
        </div>

        <div className="mt-16 p-6 rounded-2xl bg-brand/5 border border-brand/20">
          <h3 className="text-xl font-bold text-white mb-3">Need Help?</h3>
          <p className="text-zinc-400 mb-4">
            If you encounter any issues during the setup, ensure that Docker Desktop is running. You can also view logs using <code className="bg-white/10 px-1.5 py-0.5 rounded">docker-compose logs -f</code>.
          </p>
          <a
            href="https://github.com/kembe699/davinscs/issues"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white/5 hover:bg-white/10 text-white font-medium px-5 py-2.5 rounded-lg transition-colors border border-white/10"
          >
            Open GitHub Issues
          </a>
        </div>
      </main>
      <Footer />
    </div>
  )
}
