import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { docsContent } from './DocsContent'

export default function Docs() {
  return (
    <div className="min-h-screen bg-[#080a0e] text-zinc-300 flex flex-col font-sans">
      <Navbar />
      <main className="flex-1 max-w-4xl mx-auto w-full px-6 py-24">
        <div className="w-full">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h1: ({node, ...props}) => <h1 className="text-4xl md:text-5xl font-black text-white mb-6 pb-4 border-b border-white/10" {...props} />,
              h2: ({node, ...props}) => <h2 className="text-3xl font-bold text-white mt-12 mb-6 border-l-4 border-brand pl-4" {...props} />,
              h3: ({node, ...props}) => <h3 className="text-xl font-bold text-white mt-8 mb-4" {...props} />,
              p: ({node, ...props}) => <p className="mb-4 text-zinc-400 leading-relaxed" {...props} />,
              ul: ({node, ...props}) => <ul className="list-disc pl-6 mb-6 space-y-2 text-zinc-400" {...props} />,
              ol: ({node, ...props}) => <ol className="list-decimal pl-6 mb-6 space-y-2 text-zinc-400" {...props} />,
              li: ({node, ...props}) => <li {...props} />,
              table: ({node, ...props}) => (
                <div className="overflow-x-auto mb-8 mt-4">
                  <table className="w-full text-sm text-left border-collapse" {...props} />
                </div>
              ),
              thead: ({node, ...props}) => <thead className="bg-white/5 text-white" {...props} />,
              th: ({node, ...props}) => <th className="p-3 border border-white/10 font-semibold" {...props} />,
              tbody: ({node, ...props}) => <tbody className="divide-y divide-white/10" {...props} />,
              td: ({node, ...props}) => <td className="p-3 border border-white/10" {...props} />,
              code: ({node, className, children, ...props}) => {
                const match = /language-(\w+)/.exec(className || '')
                return !match ? (
                  <code className="bg-white/10 text-brand px-1.5 py-0.5 rounded text-sm font-mono" {...props}>
                    {children}
                  </code>
                ) : (
                  <pre className="bg-black/50 border border-white/5 p-4 rounded-xl overflow-x-auto mb-6">
                    <code className="font-mono text-sm text-zinc-300" {...props}>
                      {children}
                    </code>
                  </pre>
                )
              },
              blockquote: ({node, ...props}) => <blockquote className="bg-brand/5 border border-brand/20 p-6 rounded-xl mt-6 mb-6 text-zinc-300 italic" {...props} />,
              strong: ({node, ...props}) => <strong className="font-semibold text-white" {...props} />,
              em: ({node, ...props}) => <em className="italic text-zinc-400" {...props} />,
              hr: ({node, ...props}) => <hr className="my-10 border-white/10" {...props} />
            }}
          >
            {docsContent}
          </ReactMarkdown>
        </div>
      </main>
      <Footer />
    </div>
  )
}
