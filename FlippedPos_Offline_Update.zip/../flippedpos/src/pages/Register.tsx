import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Store, Mail, Lock, ArrowRight, CheckCircle, Copy, Eye, EyeOff, Check, Zap, AlertCircle, RotateCcw } from 'lucide-react';

interface Plan { id: number; name: string; price: string; sub_label: string; description: string; features: string[]; highlight: boolean; }

const FALLBACK_PLANS: Plan[] = [
  { id: 0, name: 'Self-Hosted', price: 'Free', sub_label: 'Forever', highlight: false, description: 'Run it on your own server.', features: ['Full POS terminal', 'Unlimited products', 'Community support'] },
  { id: 0, name: 'Professional', price: '$29', sub_label: 'per month', highlight: true, description: 'Fully hosted by us.', features: ['Everything in Self-Hosted', 'Cloud hosting', 'Priority support'] },
  { id: 0, name: 'Enterprise', price: 'Custom', sub_label: 'contact us', highlight: false, description: 'For chains & franchises.', features: ['Multiple branches', 'Dedicated server', 'SLA guarantee'] },
];

export default function Register() {
  const [businessName, setBusinessName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [successData, setSuccessData] = useState<{ customerCode: string; schemaName: string; tenantSlug: string } | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState('');
  const [plans, setPlans] = useState<Plan[]>(FALLBACK_PLANS);
  const [selectedPlan, setSelectedPlan] = useState<string>('Professional');
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas/pricing`)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data && data.length > 0) {
          const parsed = data.map((p: any) => ({ ...p, features: Array.isArray(p.features) ? p.features : JSON.parse(p.features || '[]') }));
          setPlans(parsed);
          const popular = parsed.find((p: Plan) => p.highlight);
          if (popular) setSelectedPlan(popular.name);
        }
      })
      .catch(() => {});
  }, []);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ businessName, email, password, plan: selectedPlan })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Registration failed');
      setSuccessData({ customerCode: data.customerCode, schemaName: data.schemaName, tenantSlug: data.tenantSlug });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (value: string, key: string) => {
    navigator.clipboard.writeText(value).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(''), 2000);
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-12">

      {/* Logo & branding */}
      <div className="text-center mb-8">
        <img src="/logo.png" alt="FlippedPOS" className="h-20 w-auto mx-auto mb-5 object-contain" />
        <p className="font-mono-tech text-[10px] text-white tracking-[0.5em] uppercase mb-1">
          Create Your Instance
        </p>
        <p className="text-xs text-white/70">
          7-day free trial · No credit card required
        </p>
      </div>

      {/* Card */}
      <div className="w-full max-w-sm bg-chassis border border-border-subtle p-6">

        {successData ? (
          /* ── Success state ── */
          <div className="space-y-4">
            <div className="text-center pb-2">
              <div className="w-10 h-10 flex items-center justify-center bg-white/10 border border-white/20 mx-auto mb-3">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <p className="font-mono-tech text-[10px] text-white uppercase tracking-widest mb-1">Instance Created!</p>
              <p className="text-xs text-white/70">Save these credentials now — you'll need them to log in.</p>
            </div>

            {/* Credentials */}
            <div className="space-y-3 border border-border-subtle p-4 bg-background/30">
              {/* Email */}
              <div>
                <p className="font-mono-tech text-[9px] text-white/50 uppercase tracking-widest mb-1">Email</p>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-white font-mono truncate">{email}</span>
                  <button onClick={() => copyToClipboard(email, 'email')} className="text-white/40 hover:text-white transition-colors shrink-0">
                    {copied === 'email' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Password */}
              <div>
                <p className="font-mono-tech text-[9px] text-white/50 uppercase tracking-widest mb-1">Password</p>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-white font-mono">{showPassword ? password : '••••••••'}</span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button onClick={() => setShowPassword(!showPassword)} className="text-white/40 hover:text-white transition-colors">
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                    <button onClick={() => copyToClipboard(password, 'password')} className="text-white/40 hover:text-white transition-colors">
                      {copied === 'password' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Customer Code */}
              <div className="border-t border-border-subtle pt-3">
                <p className="font-mono-tech text-[9px] text-white/50 uppercase tracking-widest mb-1">Customer Code <span className="text-yellow-400">(keep safe!)</span></p>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-base font-bold text-white font-mono tracking-widest">{successData.customerCode}</span>
                  <button onClick={() => copyToClipboard(successData.customerCode, 'code')} className="text-white/40 hover:text-white transition-colors shrink-0">
                    {copied === 'code' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] text-white/40 font-mono-tech mt-1">Use this on the portal login page</p>
              </div>
            </div>

            <button
              onClick={() => { window.location.href = 'https://app.flippedpos.com/portal'; }}
              className="w-full h-11 bg-primary text-background font-bold uppercase tracking-widest text-xs hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
            >
              Go to Portal Login <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        ) : (
          /* ── Registration form ── */
          <>
            {/* Plan selector */}
            <div className="mb-5">
              <p className="font-mono-tech text-[10px] text-white uppercase tracking-widest mb-3">Choose a Plan</p>
              <div className="grid grid-cols-3 gap-2">
                {plans.map(plan => (
                  <button
                    key={plan.name}
                    type="button"
                    onClick={() => setSelectedPlan(plan.name)}
                    className={`relative p-2.5 text-left border transition-colors ${
                      selectedPlan === plan.name
                        ? 'border-white/40 bg-white/5'
                        : 'border-border-subtle bg-background/30 hover:border-white/20'
                    }`}
                  >
                    {plan.highlight && (
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-white text-black text-[8px] font-bold px-1.5 py-0.5 flex items-center gap-0.5 whitespace-nowrap">
                        <Zap size={7} className="fill-black" /> Popular
                      </span>
                    )}
                    <p className="font-mono-tech text-[9px] text-white/50 uppercase tracking-widest mb-0.5">{plan.name}</p>
                    <p className="font-bold text-sm text-white">{plan.price}</p>
                    <p className="text-[9px] text-white/40">{plan.sub_label}</p>
                    {selectedPlan === plan.name && (
                      <div className="absolute top-1.5 right-1.5"><Check className="w-2.5 h-2.5 text-white" /></div>
                    )}
                  </button>
                ))}
              </div>
              {selectedPlan && (
                <p className="mt-2 text-[10px] text-white/50 font-mono-tech">
                  {plans.find(p => p.name === selectedPlan)?.description}
                </p>
              )}
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono-tech mb-4">
                <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                {error}
              </div>
            )}

            <form onSubmit={handleRegister} className="space-y-4">
              {/* Business Name */}
              <div>
                <label className="font-mono-tech text-[10px] text-white uppercase tracking-widest block mb-2">Business Name</label>
                <div className="relative">
                  <Store className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                  <input
                    type="text"
                    required
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    className="w-full h-11 pl-9 pr-4 bg-background border border-border-subtle text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-white/40 transition-colors"
                    placeholder="e.g. Davin's Electronics"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="font-mono-tech text-[10px] text-white uppercase tracking-widest block mb-2">Admin Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-11 pl-9 pr-4 bg-background border border-border-subtle text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-white/40 transition-colors"
                    placeholder="admin@yourbusiness.com"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="font-mono-tech text-[10px] text-white uppercase tracking-widest block mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-11 pl-9 pr-4 bg-background border border-border-subtle text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-white/40 transition-colors"
                    placeholder="••••••••"
                  />
                </div>
                <p className="mt-1.5 text-[10px] text-white/40 font-mono-tech">Minimum 6 characters</p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 bg-primary text-background font-bold uppercase tracking-widest text-xs hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-2"
              >
                {loading ? (
                  <>
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                    Provisioning Instance…
                  </>
                ) : (
                  <>Create My Free Instance <ArrowRight className="w-3.5 h-3.5" /></>
                )}
              </button>
            </form>
          </>
        )}
      </div>

      {/* Footer */}
      <p className="text-center text-[10px] font-mono-tech text-white/60 mt-6 uppercase tracking-widest">
        Already have an account?{' '}
        <a
          href="https://app.flippedpos.com/portal"
          className="text-white underline hover:text-white/80 transition-colors"
        >
          Go to Portal
        </a>
      </p>
    </div>
  );
}
