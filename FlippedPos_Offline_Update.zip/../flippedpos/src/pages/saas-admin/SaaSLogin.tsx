import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Mail, ArrowRight, ShieldCheck } from 'lucide-react';

export default function SaaSLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Login failed');
      }

      localStorage.setItem('saas_admin_token', data.token);
      localStorage.setItem('saas_admin_user', JSON.stringify(data.admin));
      navigate('/admin/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050709] flex flex-col items-center justify-center font-sans relative overflow-hidden">
      {/* Background grid effect */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: 'linear-gradient(#00ff88 1px, transparent 1px), linear-gradient(90deg, #00ff88 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />
      {/* Radial glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-[#00ff88]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-sm px-6">
        {/* Logo block */}
        <div className="flex flex-col items-center mb-10">
          <img src="/logo.png" alt="FlippedPOS" className="h-24 w-auto mb-5 drop-shadow-[0_0_20px_rgba(0,255,136,0.3)]" />
          <p className="text-[10px] text-[#00ff88] tracking-[0.5em] uppercase font-mono mb-1">Master Admin Portal</p>
          <p className="text-xs text-zinc-600 tracking-widest font-mono">&mdash; Restricted Access &mdash;</p>
        </div>

        {/* Card */}
        <div className="bg-[#0d1117]/90 border border-white/10 backdrop-blur-sm p-8 shadow-2xl">
          {/* Top accent line */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00ff88]/50 to-transparent" />

          <div className="flex items-center gap-2 mb-6">
            <ShieldCheck className="w-4 h-4 text-[#00ff88]" />
            <h1 className="text-sm font-bold text-white tracking-widest uppercase">Sign In</h1>
          </div>

          {error && (
            <div className="mb-5 p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono">
              ⚠ {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[10px] text-zinc-500 uppercase tracking-widest font-mono mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-600" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-black/60 border border-white/10 text-white text-sm placeholder-zinc-700 focus:outline-none focus:border-[#00ff88]/50 transition-colors"
                  placeholder="admin@flippedpos.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-zinc-500 uppercase tracking-widest font-mono mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-600" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-black/60 border border-white/10 text-white text-sm placeholder-zinc-700 focus:outline-none focus:border-[#00ff88]/50 transition-colors"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#00ff88] text-black font-bold text-sm uppercase tracking-widest hover:bg-[#00ff88]/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed mt-2"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                  Authenticating…
                </span>
              ) : (
                <>Authenticate <ArrowRight className="w-4 h-4" /></>
              )}
            </button>
          </form>
        </div>

        {/* Footer */}
        <div className="mt-6 flex items-center justify-between px-1">
          <button
            onClick={() => navigate('/')}
            className="text-[11px] text-zinc-600 hover:text-zinc-400 transition-colors font-mono"
          >
            ← Back to website
          </button>
          <p className="text-[11px] text-zinc-700 font-mono">© {new Date().getFullYear()} FlippedPOS</p>
        </div>
      </div>
    </div>
  );
}
