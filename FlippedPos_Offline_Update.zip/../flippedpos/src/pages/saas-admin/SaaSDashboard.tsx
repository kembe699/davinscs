import { useState, useEffect, useCallback, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LogOut, Users, Search, RefreshCw, CheckCircle2, XCircle, Clock,
  LayoutDashboard, Tag, DollarSign, ChevronDown, ChevronUp, Save,
  Plus, Trash2, Menu, X, Database, TrendingUp, AlertCircle,
  Receipt, Printer, FileText, Sun, Moon
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;
type View = 'overview' | 'customers' | 'billing' | 'pricing' | 'users' | 'reports';

interface Invoice {
  id: number;
  invoice_number: string;
  tenant_id: number;
  business_name: string;
  customer_code: string;
  tenant_slug: string;
  plan_name: string;
  amount: number;
  currency: string;
  status: 'pending' | 'paid';
  notes: string;
  issued_at: string;
  paid_at: string | null;
}

interface AdminUser {
  id: number;
  email: string;
  name: string;
  created_at: string;
}

interface GlobalDBHistory {
  date: string;
  total_size: number;
}

interface Tenant {
  id: number;
  business_name: string;
  schema_name: string;
  customer_code: string;
  tenant_slug: string;
  status: 'active' | 'trial' | 'suspended';
  trial_ends_at: string;
  subscription_start: string | null;
  subscription_end: string | null;
  created_at: string;
  user_count: string;
  db_size_bytes: number;
}

interface PricingPlan {
  id: number;
  name: string;
  price: string;
  sub_label: string;
  description: string;
  features: string[];
  cta_label: string;
  cta_href: string;
  highlight: boolean;
  sort_order: number;
  billing_period: 'monthly' | 'quarterly' | 'annual';
}

function fmtBytes(bytes: number) {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function StatusBadge({ status, trialEnded }: { status: string; trialEnded: boolean }) {
  const map: Record<string, string> = {
    active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    suspended: 'bg-red-500/10 text-red-400 border-red-500/20',
    trial: trialEnded ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  };
  const icons: Record<string, React.ReactNode> = {
    active: <CheckCircle2 className="w-3 h-3" />,
    suspended: <XCircle className="w-3 h-3" />,
    trial: <Clock className="w-3 h-3" />,
  };
  const label = status === 'trial' && trialEnded ? 'Expired' : status.charAt(0).toUpperCase() + status.slice(1);
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${map[status] || map.trial}`}>
      {icons[status]}{label}
    </span>
  );
}

export default function SaaSDashboard() {
  const [view, setView] = useState<View>('overview');
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [plans, setPlans] = useState<PricingPlan[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [globalDBHistory, setGlobalDBHistory] = useState<GlobalDBHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [savingPlan, setSavingPlan] = useState<number | null>(null);
  const [printInvoice, setPrintInvoice] = useState<Invoice | null>(null);
  const [showCreateInvoice, setShowCreateInvoice] = useState(false);
  const [markPaidTenant, setMarkPaidTenant] = useState<Tenant | null>(null);
  const [invoiceForm, setInvoiceForm] = useState({ tenant_id: 0, plan_name: '', amount: '', currency: 'USD', notes: '', billing_period: 'monthly' });
  const [savingInvoice, setSavingInvoice] = useState(false);
  const [showAddPlan, setShowAddPlan] = useState(false);
  const [addPlanForm, setAddPlanForm] = useState({ name: '', price: '', sub_label: 'per month', description: '', billing_period: 'monthly' });
  const [savingAddPlan, setSavingAddPlan] = useState(false);
  const [showCreateAdmin, setShowCreateAdmin] = useState(false);
  const [adminForm, setAdminForm] = useState({ name: '', email: '', password: '' });
  const [savingAdmin, setSavingAdmin] = useState(false);
  const [expandedTenant, setExpandedTenant] = useState<number | null>(null);
  const [tenantDetails, setTenantDetails] = useState<Record<number, { users: any[], history: any[] }>>({});
  const navigate = useNavigate();

  const [theme, setTheme] = useState(document.documentElement.getAttribute('data-theme') || 'dark');
  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('saas_theme', newTheme);
  };

  const token = localStorage.getItem('saas_admin_token');
  const userStr = localStorage.getItem('saas_admin_user');
  let user = null;
  try {
    user = userStr && userStr !== 'undefined' ? JSON.parse(userStr) : null;
  } catch (e) {
    console.error('Failed to parse saas_admin_user:', e);
    localStorage.removeItem('saas_admin_user');
  }

  const authHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  const guardedFetch = useCallback(async (url: string, opts?: RequestInit) => {
    const res = await fetch(url, { ...opts, headers: { ...authHeaders, ...(opts?.headers || {}) } });
    if (res.status === 401 || res.status === 403) {
      localStorage.removeItem('saas_admin_token');
      navigate('/admin');
      throw new Error('Unauthorized');
    }
    if (!res.ok) throw new Error(await res.text());
    
    // Safely parse JSON to handle 200 OK with HTML responses gracefully
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch (e) {
      console.error(`Invalid JSON from ${url}:`, text.substring(0, 100));
      throw new Error('Invalid JSON response from server');
    }
  }, [token]);

  const fetchAll = useCallback(async () => {
    if (!token) { navigate('/admin'); return; }
    setLoading(true); setError('');
    try {
      const [stats, pricing, billing, adminUsers, dbHistory] = await Promise.all([
        guardedFetch(`${API}/tenants/stats`),
        guardedFetch(`${API}/pricing`),
        guardedFetch(`${API}/billing`),
        guardedFetch(`${API}/admins`),
        guardedFetch(`${API}/tenants/db-history-global`),
      ]);
      setTenants(stats);
      setPlans(pricing.map((p: PricingPlan) => {
        let parsedFeatures = [];
        try {
          parsedFeatures = Array.isArray(p.features) ? p.features : JSON.parse(p.features as any || '[]');
        } catch (e) {
          parsedFeatures = [];
        }
        return { ...p, features: parsedFeatures };
      }));
      setInvoices(billing);
      setAdmins(adminUsers);
      setGlobalDBHistory(dbHistory);
    } catch (err: any) {
      if (err.message !== 'Unauthorized') setError(err.message);
    } finally { setLoading(false); }
  }, [guardedFetch, token]);

  useEffect(() => {
    const localTheme = localStorage.getItem('saas_theme');
    if (localTheme) {
      setTheme(localTheme);
      document.documentElement.setAttribute('data-theme', localTheme);
    } else {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
    fetchAll();
  }, [fetchAll]);

  const updateStatus = async (id: number, status: string) => {
    try {
      await guardedFetch(`${API}/tenants/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) });
      setTenants(prev => prev.map(t => t.id === id ? { ...t, status: status as any } : t));
    } catch (err: any) { alert(err.message); }
  };

  const createInvoice = async (tenantId: number, markTenantPaid = false) => {
    setSavingInvoice(true);
    try {
      const body = { ...invoiceForm, tenant_id: tenantId, amount: parseFloat(invoiceForm.amount) || 0, billing_period: invoiceForm.billing_period };
      const inv = await guardedFetch(`${API}/billing`, { method: 'POST', body: JSON.stringify(body) });
      let paidInv = inv;
      if (markTenantPaid) {
        paidInv = await guardedFetch(`${API}/billing/${inv.id}/pay`, { method: 'PUT' });
      }
      const full = await guardedFetch(`${API}/billing`);
      setInvoices(full);
      if (markTenantPaid) setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, status: 'active' as const } : t));
      setShowCreateInvoice(false);
      setMarkPaidTenant(null);
      setInvoiceForm({ tenant_id: 0, plan_name: '', amount: '', currency: 'USD', notes: '', billing_period: 'monthly' });
      const created = full.find((i: Invoice) => i.id === (paidInv.id ?? inv.id)) || paidInv;
      setPrintInvoice(created);
    } catch (err: any) { alert(err.message); }
    finally { setSavingInvoice(false); }
  };

  const createNewPlan = async () => {
    if (!addPlanForm.name || !addPlanForm.price) return;
    setSavingAddPlan(true);
    try {
      const newPlan = await guardedFetch(`${API}/pricing`, { method: 'POST', body: JSON.stringify(addPlanForm) });
      setPlans(prev => [...prev, { ...newPlan, features: Array.isArray(newPlan.features) ? newPlan.features : (() => { try { return JSON.parse(newPlan.features || '[]'); } catch { return []; } })() }]);
      setInvoiceForm(f => ({ ...f, plan_name: `${newPlan.name} — ${newPlan.price}/${newPlan.sub_label}`, billing_period: newPlan.billing_period || 'monthly' }));
      setShowAddPlan(false);
      setAddPlanForm({ name: '', price: '', sub_label: 'per month', description: '', billing_period: 'monthly' });
    } catch (err: any) { alert(err.message); }
    finally { setSavingAddPlan(false); }
  };

  const payInvoice = async (inv: Invoice) => {
    try {
      await guardedFetch(`${API}/billing/${inv.id}/pay`, { method: 'PUT' });
      const updated = { ...inv, status: 'paid' as const, paid_at: new Date().toISOString() };
      setInvoices(prev => prev.map(i => i.id === inv.id ? updated : i));
      setPrintInvoice(updated);
    } catch (err: any) { alert(err.message); }
  };

  const savePlan = async (plan: PricingPlan) => {
    setSavingPlan(plan.id);
    try {
      const updated = await guardedFetch(`${API}/pricing/${plan.id}`, { method: 'PUT', body: JSON.stringify(plan) });
      setPlans(prev => prev.map(p => p.id === plan.id ? { ...updated, features: Array.isArray(updated.features) ? updated.features : (() => { try { return JSON.parse(updated.features || '[]'); } catch { return []; } })() } : p));
    } catch (err: any) { alert(err.message); }
    finally { setSavingPlan(null); }
  };

  const deletePlan = async (id: number) => {
    if (!confirm('Delete this plan? This cannot be undone.')) return;
    try {
      await guardedFetch(`${API}/pricing/${id}`, { method: 'DELETE' });
      setPlans(prev => prev.filter(p => p.id !== id));
    } catch (err: any) { alert(err.message); }
  };

  const reorderPlans = async (newOrder: PricingPlan[]) => {
    setPlans(newOrder);
    try {
      await guardedFetch(`${API}/pricing-reorder`, {
        method: 'PUT',
        body: JSON.stringify({ order: newOrder.map((p, i) => ({ id: p.id, sort_order: i })) }),
      });
    } catch (err: any) { alert('Reorder failed: ' + err.message); }
  };

  const createAdmin = async () => {
    if (!adminForm.name || !adminForm.email || !adminForm.password) return;
    setSavingAdmin(true);
    try {
      const newAdmin = await guardedFetch(`${API}/admins`, { method: 'POST', body: JSON.stringify(adminForm) });
      setAdmins(prev => [newAdmin, ...prev]);
      setShowCreateAdmin(false);
      setAdminForm({ name: '', email: '', password: '' });
    } catch (err: any) { alert(err.message); }
    finally { setSavingAdmin(false); }
  };

  const deleteAdmin = async (id: number) => {
    if (!confirm('Delete this administrator?')) return;
    try {
      await guardedFetch(`${API}/admins/${id}`, { method: 'DELETE' });
      setAdmins(prev => prev.filter(a => a.id !== id));
    } catch (err: any) { alert(err.message); }
  };

  const toggleTenantRow = async (id: number) => {
    if (expandedTenant === id) {
      setExpandedTenant(null);
      return;
    }
    setExpandedTenant(id);
    if (!tenantDetails[id]) {
      try {
        const data = await guardedFetch(`${API}/tenants/${id}/details`);
        setTenantDetails(prev => ({ ...prev, [id]: data }));
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('saas_admin_token');
    localStorage.removeItem('saas_admin_user');
    navigate('/admin');
  };

  const filtered = tenants.filter(t => {
    const q = searchTerm.toLowerCase();
    const matchQ = !q || t.business_name.toLowerCase().includes(q) || (t.customer_code || '').toLowerCase().includes(q);
    const matchS = statusFilter === 'all' || t.status === statusFilter || (statusFilter === 'expired' && t.status === 'trial' && new Date(t.trial_ends_at) < new Date());
    return matchQ && matchS;
  });

  const stats = {
    total: tenants.length,
    active: tenants.filter(t => t.status === 'active').length,
    trial: tenants.filter(t => t.status === 'trial' && new Date(t.trial_ends_at) >= new Date()).length,
    expired: tenants.filter(t => t.status === 'trial' && new Date(t.trial_ends_at) < new Date()).length,
    suspended: tenants.filter(t => t.status === 'suspended').length,
  };
  const maxBytes = Math.max(...tenants.map(t => Number(t.db_size_bytes) || 0), 1);

  const navItems = [
    { id: 'overview' as View,   label: 'Overview',   icon: LayoutDashboard },
    { id: 'customers' as View,  label: 'Customers',  icon: Users },
    { id: 'billing' as View,    label: 'Billing',    icon: Receipt },
    { id: 'pricing' as View,    label: 'Pricing',    icon: Tag },
    { id: 'users' as View,      label: 'Users',      icon: Users },
    { id: 'reports' as View,    label: 'Reports',    icon: FileText },
  ];

  const billingSearch = searchTerm.toLowerCase();
  const filteredInvoices = invoices.filter(i =>
    !billingSearch ||
    i.invoice_number.toLowerCase().includes(billingSearch) ||
    i.business_name.toLowerCase().includes(billingSearch) ||
    (i.plan_name || '').toLowerCase().includes(billingSearch)
  );

  return (
    <div className="min-h-screen bg-background text-foreground font-sans flex flex-col">
      {/* Top bar */}
      <header className="bg-[#1f1f1f] border-b border-[#3d3d3d] sticky top-0 z-30 h-20 flex items-center px-4 gap-4">
        <button className="lg:hidden p-1.5 text-zinc-100 hover:text-white" onClick={() => setSidebarOpen(o => !o)}>
          {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="FlippedPOS" className="h-16 w-auto" />
          <div className="hidden sm:block">
            <p className="font-bold text-white text-sm leading-tight">FlippedPOS</p>
            <p className="text-[10px] text-white/50 font-mono tracking-widest uppercase">Master Control</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <span className="text-xs text-zinc-300 hidden sm:block">{user?.name || user?.email}</span>
          <button onClick={toggleTheme} className="p-1.5 text-zinc-300 hover:text-white" title="Toggle Theme">
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button onClick={fetchAll} disabled={loading} className="p-2 hover:bg-background/50 rounded transition-colors text-muted-foreground hover:text-foreground disabled:opacity-50">
            {loading ? (
              <span className="flex items-center gap-1">
                <span className="w-1 h-1 bg-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1 h-1 bg-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1 h-1 bg-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </span>
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
          </button>
          <button onClick={handleLogout} className="flex items-center gap-1.5 text-xs text-zinc-300 hover:text-white">
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar overlay on mobile */}
        {sidebarOpen && <div className="fixed inset-0 bg-black/60 z-20 lg:hidden" onClick={() => setSidebarOpen(false)} />}

        {/* Sidebar */}
        <aside className={`fixed lg:static inset-y-0 left-0 z-20 w-56 bg-[#1f1f1f] border-r border-[#3d3d3d] pt-20 lg:pt-0 flex flex-col transition-transform duration-200
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
          <div className="p-4 border-b border-[#3d3d3d]">
            <p className="font-mono-tech text-[10px] text-white/50 tracking-[0.3em] uppercase">Navigation</p>
          </div>
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {navItems.map(item => (
              <button key={item.id} onClick={() => { setView(item.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-none text-sm font-medium transition-colors
                  ${view === item.id ? 'bg-white/10 text-white border-l-2 border-white' : 'text-zinc-100 hover:text-white hover:bg-white/5'}`}>
                <item.icon className="w-4 h-4 flex-shrink-0" />
                {item.label}
              </button>
            ))}
          </nav>
          <div className="p-4 border-t border-[#3d3d3d]">
            <p className="text-[10px] text-zinc-500">FlippedPOS Admin &copy; {new Date().getFullYear()}</p>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-auto p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-none text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
            </div>
          )}

          {/* ── OVERVIEW ──────────────────────────────────────────────── */}
          {view === 'overview' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-xl font-bold text-foreground">Overview</h1>
                <p className="text-sm text-muted-foreground">Platform health at a glance</p>
              </div>

              {/* KPI cards */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                {[
                  { label: 'Total Tenants',  value: stats.total,     color: 'text-foreground',          icon: Users },
                  { label: 'Paid / Active',  value: stats.active,    color: 'text-emerald-400',    icon: CheckCircle2 },
                  { label: 'On Trial',       value: stats.trial,     color: 'text-blue-400',       icon: Clock },
                  { label: 'Trial Expired',  value: stats.expired,   color: 'text-orange-400',     icon: AlertCircle },
                  { label: 'Suspended',      value: stats.suspended, color: 'text-red-400',        icon: XCircle },
                ].map(k => (
                  <div key={k.label} className="bg-chassis border border-border-subtle rounded-none p-4">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-xs text-muted-foreground">{k.label}</p>
                      <k.icon className={`w-4 h-4 ${k.color}`} />
                    </div>
                    <p className={`text-3xl font-bold font-mono ${k.color}`}>{k.value}</p>
                  </div>
                ))}
              </div>

              <div className="bg-chassis border border-border-subtle rounded-none p-5">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xs font-bold text-muted-foreground tracking-widest uppercase flex items-center gap-2"><Database className="w-4 h-4 text-primary" /> Database Growth Over Time</h2>
                  <span className="text-[10px] text-muted-foreground font-mono tracking-widest uppercase">{globalDBHistory.length} Snapshots Recorded</span>
                </div>
                {loading ? <p className="text-sm text-muted-foreground">Loading...</p> : globalDBHistory.length === 0 ? <p className="text-sm text-muted-foreground">No storage data available yet.</p> : (
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={globalDBHistory.map(h => ({ ...h, total_size: Number(h.total_size) }))} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorSizeGlobalOverview" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#00ff88" stopOpacity={0.15}/>
                            <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                        <XAxis
                          dataKey="date"
                          tickFormatter={(val) => new Date(val).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }}
                          dy={10}
                        />
                        <YAxis
                          tickFormatter={fmtBytes}
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }}
                          width={70}
                        />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#09090b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 0, fontFamily: 'monospace', fontSize: 12 }}
                          itemStyle={{ color: '#00ff88' }}
                          labelStyle={{ color: '#a1a1aa', marginBottom: '4px' }}
                          labelFormatter={(l) => new Date(l).toLocaleDateString()}
                          formatter={(val: any) => [fmtBytes(Number(val)), 'Size']}
                        />
                        <Area
                          type="stepAfter"
                          dataKey="total_size"
                          stroke="#00ff88"
                          strokeWidth={2}
                          fillOpacity={1}
                          fill="url(#colorSizeGlobalOverview)"
                          dot={{ r: 3, fill: '#09090b', stroke: '#00ff88', strokeWidth: 1.5 }}
                          activeDot={{ r: 4, fill: '#00ff88', stroke: '#09090b', strokeWidth: 2 }}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* DB size bar chart */}
                <div className="bg-chassis border border-border-subtle rounded-none p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Database className="w-4 h-4 text-primary" />
                    <h2 className="text-sm font-bold text-foreground">Storage per Tenant</h2>
                  </div>
                  {loading ? (
                    <p className="text-muted-foreground text-sm">Loading…</p>
                  ) : tenants.length === 0 ? (
                    <p className="text-muted-foreground text-sm">No tenants yet.</p>
                  ) : (
                    <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                      {[...tenants].sort((a, b) => Number(b.db_size_bytes) - Number(a.db_size_bytes)).map(t => {
                        const pct = Math.max((Number(t.db_size_bytes) / maxBytes) * 100, 2);
                        return (
                          <div key={t.id}>
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs text-foreground truncate max-w-[60%]">{t.business_name}</span>
                              <span className="text-xs text-foreground/60 font-mono">{fmtBytes(Number(t.db_size_bytes))}</span>
                            </div>
                            <div className="h-2 bg-background/50 rounded-full overflow-hidden">
                              <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Payment status donut */}
                <div className="bg-chassis border border-border-subtle rounded-none p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <DollarSign className="w-4 h-4 text-primary" />
                    <h2 className="text-sm font-bold text-foreground">Payment Status</h2>
                  </div>
                  {stats.total === 0 ? (
                    <p className="text-muted-foreground text-sm">No tenants yet.</p>
                  ) : (
                    <div className="flex items-center gap-6">
                      {/* CSS donut */}
                      <div className="relative flex-shrink-0">
                        <svg width="120" height="120" viewBox="0 0 120 120">
                          {(() => {
                            const segments = [
                              { val: stats.active,   color: '#10b981' },
                              { val: stats.trial,    color: '#3b82f6' },
                              { val: stats.expired,  color: '#f97316' },
                              { val: stats.suspended,color: '#ef4444' },
                            ];
                            const total = segments.reduce((s, x) => s + x.val, 0) || 1;
                            const r = 48, cx = 60, cy = 60;
                            let cumAngle = -Math.PI / 2;
                            return segments.filter(s => s.val > 0).map((seg, i) => {
                              const angle = (seg.val / total) * 2 * Math.PI;
                              const x1 = cx + r * Math.cos(cumAngle);
                              const y1 = cy + r * Math.sin(cumAngle);
                              cumAngle += angle;
                              const x2 = cx + r * Math.cos(cumAngle);
                              const y2 = cy + r * Math.sin(cumAngle);
                              const large = angle > Math.PI ? 1 : 0;
                              return (
                                <path key={i}
                                  d={`M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`}
                                  fill={seg.color} opacity="0.85"
                                />
                              );
                            });
                          })()}
                          <circle cx="60" cy="60" r="30" fill="#0d1117" />
                          <text x="60" y="56" textAnchor="middle" fill="white" fontSize="16" fontWeight="bold">{stats.total}</text>
                          <text x="60" y="70" textAnchor="middle" fill="#71717a" fontSize="9">tenants</text>
                        </svg>
                      </div>
                      <div className="space-y-2 text-sm">
                        {[
                          { label: 'Paid / Active', val: stats.active,    color: 'bg-emerald-500' },
                          { label: 'On Trial',      val: stats.trial,     color: 'bg-blue-500' },
                          { label: 'Trial Expired', val: stats.expired,   color: 'bg-orange-500' },
                          { label: 'Suspended',     val: stats.suspended, color: 'bg-red-500' },
                        ].map(l => (
                          <div key={l.label} className="flex items-center gap-2">
                            <div className={`w-2.5 h-2.5 rounded-full ${l.color}`} />
                            <span className="text-muted-foreground text-xs">{l.label}</span>
                            <span className="text-foreground font-semibold text-xs ml-auto pl-4">{l.val}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Unpaid alert */}
              {(stats.expired + stats.suspended) > 0 && (
                <div className="bg-orange-500/10 border border-orange-500/20 rounded-none p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-orange-300">{stats.expired + stats.suspended} account(s) need attention</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{stats.expired} expired trial(s), {stats.suspended} suspended. Go to Customers to take action.</p>
                  </div>
                  <button onClick={() => setView('customers')} className="ml-auto text-xs text-orange-400 hover:text-orange-300 underline whitespace-nowrap">View →</button>
                </div>
              )}
            </div>
          )}

          {/* ── CUSTOMERS ─────────────────────────────────────────────── */}
          {view === 'customers' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-xl font-bold text-foreground">Customers</h1>
                  <p className="text-sm text-muted-foreground">{tenants.length} registered tenant(s)</p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                      placeholder="Search…"
                      className="pl-9 pr-3 py-2 bg-background border border-border-subtle rounded-none text-sm text-foreground focus:outline-none focus:border-primary/60 w-48" />
                  </div>
                  <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                    className="py-2 px-3 bg-background border border-border-subtle rounded-none text-sm text-foreground focus:outline-none focus:border-primary/60">
                    <option value="all">All statuses</option>
                    <option value="active">Paid / Active</option>
                    <option value="trial">On Trial</option>
                    <option value="expired">Expired</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="bg-chassis border border-border-subtle rounded-none overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-background/50 border-b border-border-subtle">
                        {['Business','Status','DB Size','Users','Trial Ends','Actions'].map(h => (
                          <th key={h} className="px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border-subtle">
                      {loading && filtered.length === 0 ? (
                        <tr><td colSpan={6} className="p-8 text-center text-muted-foreground text-sm">Loading…</td></tr>
                      ) : filtered.length === 0 ? (
                        <tr><td colSpan={6} className="p-8 text-center text-muted-foreground text-sm">No tenants found.</td></tr>
                      ) : filtered.map(t => {
                        const trialEnded = new Date(t.trial_ends_at) < new Date();
                        const isExpanded = expandedTenant === t.id;
                        const details = tenantDetails[t.id];
                        return (
                          <Fragment key={t.id}>
                            <tr onClick={() => toggleTenantRow(t.id)} className={`hover:bg-background/20 transition-colors cursor-pointer group ${isExpanded ? 'bg-background/30' : ''}`}>
                              <td className="px-4 py-3">
                                <p className="font-medium text-foreground text-sm">{t.business_name}</p>
                                <p className="text-[11px] text-muted-foreground/50 font-mono">{t.schema_name}</p>
                                {t.customer_code && (
                                  <span className="inline-block mt-1 px-1.5 py-0.5 bg-primary/10 border border-brand/20 rounded text-[10px] font-mono text-primary">{t.customer_code}</span>
                                )}
                              </td>
                              <td className="px-4 py-3"><StatusBadge status={t.status} trialEnded={trialEnded} /></td>
                              <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{fmtBytes(Number(t.db_size_bytes))}</td>
                              <td className="px-4 py-3">
                                <span className="flex items-center gap-1 text-sm text-zinc-300"><Users className="w-3.5 h-3.5 text-muted-foreground/50" />{t.user_count}</span>
                              </td>
                              <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                                {t.status === 'active' && t.subscription_end ? (
                                  <>
                                    <span className="text-emerald-400">Renews {new Date(t.subscription_end).toLocaleDateString()}</span>
                                    {new Date(t.subscription_end) < new Date() && <span className="text-red-400 ml-1">(expired)</span>}
                                  </>
                                ) : (
                                  <>
                                    {new Date(t.trial_ends_at).toLocaleDateString()}
                                    {t.status === 'trial' && trialEnded && <span className="text-orange-400 ml-1">(expired)</span>}
                                  </>
                                )}
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2 flex-wrap" onClick={e => e.stopPropagation()}>
                                  {t.status !== 'active' && (
                                    <button onClick={() => {
                                      setMarkPaidTenant(t);
                                      setInvoiceForm(f => ({ ...f, tenant_id: t.id, plan_name: '' }));
                                    }}
                                      className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-foreground rounded text-xs font-medium transition-colors whitespace-nowrap">
                                      Mark Paid
                                    </button>
                                  )}
                                  {t.status !== 'trial' && (
                                    <button onClick={() => updateStatus(t.id, 'trial')}
                                      className="px-2.5 py-1 bg-blue-500/10 text-blue-400 hover:bg-blue-500 hover:text-foreground rounded text-xs font-medium transition-colors">
                                      Trial
                                    </button>
                                  )}
                                  {t.status !== 'suspended' && (
                                    <button onClick={() => { if (confirm('Suspend this account?')) updateStatus(t.id, 'suspended'); }}
                                      className="px-2.5 py-1 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-foreground rounded text-xs font-medium transition-colors">
                                      Suspend
                                    </button>
                                  )}
                                  {t.tenant_slug && (
                                    <a href={`https://app.flippedpos.com/${t.tenant_slug}/admin/login`} target="_blank" rel="noopener noreferrer"
                                      className="px-2.5 py-1 bg-background/50 text-muted-foreground hover:text-foreground rounded text-xs font-medium transition-colors">
                                      Open ↗
                                    </a>
                                  )}
                                </div>
                              </td>
                            </tr>
                            {isExpanded && (
                              <tr className="bg-background/10 border-b border-border-subtle">
                                <td colSpan={6} className="p-4">
                                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                    <div className="bg-chassis p-4 border border-border-subtle rounded-none">
                                      <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2"><Users className="w-4 h-4 text-primary" /> Contacts &amp; Users</h3>
                                      {!details ? <p className="text-sm text-muted-foreground">Loading...</p> : details.users.length === 0 ? <p className="text-sm text-muted-foreground">No users found.</p> : (
                                        <div className="space-y-2 max-h-48 overflow-y-auto">
                                          {details.users.map((u: any) => (
                                            <div key={u.id} className="flex justify-between items-center bg-black/20 p-2 text-sm rounded border border-white/5">
                                              <span className="text-foreground">{u.email}</span>
                                              <span className="text-[10px] text-muted-foreground font-mono">{new Date(u.created_at).toLocaleDateString()}</span>
                                            </div>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                    <div className="bg-chassis p-5 border border-border-subtle rounded-none">
                                      <div className="flex items-center justify-between mb-6">
                                        <h3 className="text-xs font-bold text-muted-foreground tracking-widest uppercase flex items-center gap-2"><Database className="w-4 h-4 text-primary" /> Database Growth Over Time</h3>
                                        <span className="text-[10px] text-muted-foreground font-mono tracking-widest uppercase">{details?.history?.length || 0} Snapshots Recorded</span>
                                      </div>
                                      {!details ? <p className="text-sm text-muted-foreground">Loading...</p> : details.history.length === 0 ? <p className="text-sm text-muted-foreground">No storage data available yet.</p> : (
                                        <div className="h-48 w-full">
                                          <ResponsiveContainer width="100%" height="100%">
                                            <AreaChart data={[...details.history].reverse().map(h => ({ ...h, size_bytes: Number(h.size_bytes) }))} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                                              <defs>
                                                <linearGradient id={`colorSize-${t.id}`} x1="0" y1="0" x2="0" y2="1">
                                                  <stop offset="5%" stopColor="#00ff88" stopOpacity={0.15}/>
                                                  <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
                                                </linearGradient>
                                              </defs>
                                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                                              <XAxis 
                                                dataKey="recorded_at" 
                                                tickFormatter={(val) => new Date(val).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                                axisLine={false}
                                                tickLine={false}
                                                tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }}
                                                dy={10}
                                              />
                                              <YAxis 
                                                tickFormatter={fmtBytes}
                                                axisLine={false}
                                                tickLine={false}
                                                tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }}
                                                width={60}
                                              />
                                              <Tooltip 
                                                contentStyle={{ backgroundColor: '#09090b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 0, fontFamily: 'monospace', fontSize: 12 }}
                                                itemStyle={{ color: '#00ff88' }}
                                                labelStyle={{ color: '#a1a1aa', marginBottom: '4px' }}
                                                labelFormatter={(l) => new Date(l).toLocaleDateString()}
                                                formatter={(val: any) => [fmtBytes(Number(val)), 'Size']}
                                              />
                                              <Area 
                                                type="stepAfter" 
                                                dataKey="size_bytes" 
                                                stroke="#00ff88" 
                                                strokeWidth={2}
                                                fillOpacity={1} 
                                                fill={`url(#colorSize-${t.id})`}
                                                dot={{ r: 3, fill: '#09090b', stroke: '#00ff88', strokeWidth: 1.5 }}
                                                activeDot={{ r: 4, fill: '#00ff88', stroke: '#09090b', strokeWidth: 2 }}
                                              />
                                            </AreaChart>
                                          </ResponsiveContainer>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </Fragment>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* ── PRICING ───────────────────────────────────────────────── */}
          {view === 'pricing' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-xl font-bold text-foreground">Pricing Plans</h1>
                  <p className="text-sm text-muted-foreground">Drag to reorder · changes reflect live on the website immediately after saving.</p>
                </div>
                <button onClick={() => { setShowAddPlan(true); setAddPlanForm({ name: '', price: '', sub_label: 'per month', description: '', billing_period: 'monthly' }); }}
                  className="flex items-center gap-1.5 px-3 py-2 bg-primary text-black font-semibold text-sm rounded-none hover:bg-primary/90 transition-colors self-start sm:self-auto">
                  <Plus className="w-4 h-4" /> Add Plan
                </button>
              </div>

              {loading ? (
                <p className="text-muted-foreground text-sm">Loading plans…</p>
              ) : (
                <div className="grid lg:grid-cols-3 gap-5">
                  {plans.map((plan, index) => (
                    <div
                      key={plan.id}
                      draggable
                      onDragStart={(e) => { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('planId', String(plan.id)); }}
                      onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }}
                      onDrop={(e) => {
                        e.preventDefault();
                        const draggedId = parseInt(e.dataTransfer.getData('planId'));
                        if (draggedId === plan.id) return;
                        const newOrder = [...plans];
                        const fromIdx = newOrder.findIndex(p => p.id === draggedId);
                        const toIdx = index;
                        const [moved] = newOrder.splice(fromIdx, 1);
                        newOrder.splice(toIdx, 0, moved);
                        reorderPlans(newOrder);
                      }}
                      className="cursor-grab active:cursor-grabbing"
                    >
                      <PlanEditor plan={plan} saving={savingPlan === plan.id} onSave={savePlan} onDelete={deletePlan} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── BILLING ───────────────────────────────────────────────── */}
          {view === 'billing' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-xl font-bold text-foreground">Billing &amp; Invoices</h1>
                  <p className="text-sm text-muted-foreground">{invoices.length} invoice(s) total · {invoices.filter(i => i.status === 'paid').length} paid</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                      placeholder="Search invoices…"
                      className="pl-9 pr-3 py-2 bg-background border border-border-subtle rounded-none text-sm text-foreground focus:outline-none focus:border-primary/60 w-48" />
                  </div>
                  <button onClick={() => { setShowCreateInvoice(true); setInvoiceForm({ tenant_id: 0, plan_name: '', amount: '', currency: 'USD', notes: '', billing_period: 'monthly' }); }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-primary text-black font-semibold text-sm rounded-none hover:bg-primary/90 transition-colors">
                    <Plus className="w-4 h-4" /> New Invoice
                  </button>
                </div>
              </div>

              <div className="bg-chassis border border-border-subtle rounded-none overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-background/50 border-b border-border-subtle">
                        {['Invoice #','Business','Plan','Amount','Status','Issued','Actions'].map(h => (
                          <th key={h} className="px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border-subtle">
                      {loading ? (
                        <tr><td colSpan={7} className="p-8 text-center text-muted-foreground text-sm">Loading…</td></tr>
                      ) : filteredInvoices.length === 0 ? (
                        <tr><td colSpan={7} className="p-8 text-center text-muted-foreground text-sm">No invoices found. Click "New Invoice" to create one.</td></tr>
                      ) : filteredInvoices.map(inv => (
                        <tr key={inv.id} className="hover:bg-background/20 transition-colors">
                          <td className="px-4 py-3 font-mono text-xs text-primary">{inv.invoice_number}</td>
                          <td className="px-4 py-3">
                            <p className="text-sm text-foreground font-medium">{inv.business_name}</p>
                            {inv.customer_code && <p className="text-[10px] font-mono text-muted-foreground/50">{inv.customer_code}</p>}
                          </td>
                          <td className="px-4 py-3 text-sm text-zinc-300">{inv.plan_name || '—'}</td>
                          <td className="px-4 py-3 text-sm font-bold text-foreground">{inv.currency} {Number(inv.amount).toFixed(2)}</td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                              inv.status === 'paid' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                            }`}>
                              {inv.status === 'paid' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                              {inv.status === 'paid' ? 'Paid' : 'Pending'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(inv.issued_at).toLocaleDateString()}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <button onClick={() => setPrintInvoice(inv)}
                                className="flex items-center gap-1 px-2.5 py-1 bg-background/50 text-muted-foreground hover:text-foreground rounded text-xs font-medium transition-colors">
                                <FileText className="w-3.5 h-3.5" /> View
                              </button>
                              {inv.status === 'pending' && (
                                <button onClick={() => payInvoice(inv)}
                                  className="flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-foreground rounded text-xs font-medium transition-colors">
                                  <CheckCircle2 className="w-3.5 h-3.5" /> Pay
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── USERS ─────────────────────────────────────────────────── */}
          {view === 'users' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-xl font-bold text-foreground">Administrators</h1>
                  <p className="text-sm text-muted-foreground">Manage Master Admin users for the SaaS portal.</p>
                </div>
                <button onClick={() => { setShowCreateAdmin(true); setAdminForm({ name: '', email: '', password: '' }); }}
                  className="flex items-center gap-1.5 px-3 py-2 bg-primary text-black font-semibold text-sm rounded-none hover:bg-primary/90 transition-colors">
                  <Plus className="w-4 h-4" /> New Admin
                </button>
              </div>

              <div className="bg-chassis border border-border-subtle rounded-none overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-background/50 border-b border-border-subtle">
                        {['Name','Email','Created','Actions'].map(h => (
                          <th key={h} className="px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border-subtle">
                      {loading ? (
                        <tr><td colSpan={4} className="p-8 text-center text-muted-foreground text-sm">Loading…</td></tr>
                      ) : admins.length === 0 ? (
                        <tr><td colSpan={4} className="p-8 text-center text-muted-foreground text-sm">No administrators found.</td></tr>
                      ) : admins.map(admin => (
                        <tr key={admin.id} className="hover:bg-background/20 transition-colors">
                          <td className="px-4 py-3 font-medium text-sm text-foreground">{admin.name}</td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">{admin.email}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(admin.created_at).toLocaleDateString()}</td>
                          <td className="px-4 py-3">
                            {admin.email !== user?.email && (
                              <button onClick={() => deleteAdmin(admin.id)}
                                className="flex items-center gap-1 px-2.5 py-1 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-foreground rounded text-xs font-medium transition-colors">
                                <Trash2 className="w-3.5 h-3.5" /> Delete
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── REPORTS ───────────────────────────────────────────────── */}
          {view === 'reports' && (
            <div className="space-y-5">
              <div>
                <h1 className="text-xl font-bold text-foreground">Financial Reports</h1>
                <p className="text-sm text-muted-foreground">Revenue overview based on paid invoices.</p>
              </div>

              {loading ? (
                <p className="text-muted-foreground text-sm">Loading reports…</p>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {(() => {
                      const paid = invoices.filter(i => i.status === 'paid');
                      const totalRev = paid.reduce((sum, i) => sum + Number(i.amount), 0);
                      const thisMonthRev = paid.filter(i => new Date(i.paid_at || i.issued_at).getMonth() === new Date().getMonth()).reduce((sum, i) => sum + Number(i.amount), 0);
                      return (
                        <>
                          <div className="bg-chassis border border-border-subtle rounded-none p-4">
                            <p className="text-xs text-muted-foreground mb-2">Total Revenue</p>
                            <p className="text-3xl font-bold font-mono text-emerald-400">${totalRev.toFixed(2)}</p>
                          </div>
                          <div className="bg-chassis border border-border-subtle rounded-none p-4">
                            <p className="text-xs text-muted-foreground mb-2">This Month</p>
                            <p className="text-3xl font-bold font-mono text-emerald-400">${thisMonthRev.toFixed(2)}</p>
                          </div>
                          <div className="bg-chassis border border-border-subtle rounded-none p-4">
                            <p className="text-xs text-muted-foreground mb-2">Total Paid Invoices</p>
                            <p className="text-3xl font-bold font-mono text-foreground">{paid.length}</p>
                          </div>
                        </>
                      );
                    })()}
                  </div>

                  <div className="bg-chassis border border-border-subtle rounded-none p-5">
                    <h2 className="text-sm font-bold text-foreground mb-4">Monthly Revenue</h2>
                    {(() => {
                      const paid = invoices.filter(i => i.status === 'paid');
                      if (paid.length === 0) return <p className="text-muted-foreground text-sm">No revenue data yet.</p>;
                      
                      const monthlyRev: Record<string, number> = {};
                      paid.forEach(i => {
                        const d = new Date(i.paid_at || i.issued_at);
                        const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
                        monthlyRev[k] = (monthlyRev[k] || 0) + Number(i.amount);
                      });
                      
                      const sortedKeys = Object.keys(monthlyRev).sort();
                      const maxRev = Math.max(...Object.values(monthlyRev), 1);
                      
                      return (
                        <div className="flex items-end gap-2 h-48 mt-8 border-b border-border-subtle pb-2 overflow-x-auto">
                          {sortedKeys.map(k => {
                            const val = monthlyRev[k];
                            const pct = Math.max((val / maxRev) * 100, 2);
                            const label = new Date(k + '-01').toLocaleDateString(undefined, { month: 'short', year: '2-digit' });
                            return (
                              <div key={k} className="flex flex-col justify-end items-center group relative min-w-[3rem] h-full">
                                <div className="absolute -top-6 opacity-0 group-hover:opacity-100 transition-opacity bg-black text-xs px-2 py-1 rounded whitespace-nowrap z-10 font-mono pointer-events-none">
                                  ${val.toFixed(2)}
                                </div>
                                <div className="w-full bg-emerald-500/20 group-hover:bg-emerald-500/40 transition-colors border-t border-emerald-500" style={{ height: `${pct}%` }} />
                                <span className="text-[10px] text-muted-foreground mt-2">{label}</span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* ── MARK PAID MODAL ──────────────────────────────────────────── */}
      {markPaidTenant && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setMarkPaidTenant(null); }}>
          <div className="bg-chassis border border-border-subtle rounded-none w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground">Mark Paid &amp; Generate Invoice</h2>
              <button onClick={() => setMarkPaidTenant(null)} className="text-muted-foreground hover:text-foreground"><X className="w-5 h-5" /></button>
            </div>
            <p className="text-sm text-muted-foreground mb-5">Marking <strong className="text-foreground">{markPaidTenant.business_name}</strong> as paid and generating an invoice receipt.</p>
            <div className="space-y-4">
              <div>
                <label className="field-label">Plan / Description</label>
                <select value={invoiceForm.plan_name} onChange={e => {
                  const val = e.target.value;
                  const matched = plans.find(p => `${p.name} — ${p.price}/${p.sub_label}` === val);
                  const numeric = matched ? String(matched.price).replace(/[^0-9.]/g, '') : '';
                  setInvoiceForm(f => ({ ...f, plan_name: val, amount: numeric || f.amount, billing_period: matched?.billing_period || f.billing_period }));
                }}
                  className="field-input">
                  <option value="">— Select a plan —</option>
                  {plans.map(p => (
                    <option key={p.id} value={`${p.name} — ${p.price}/${p.sub_label}`}>
                      {p.name} — {p.price}/{p.sub_label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="field-label">Amount</label>
                  <input type="number" min="0" step="0.01" value={invoiceForm.amount} onChange={e => setInvoiceForm(f => ({ ...f, amount: e.target.value }))}
                    placeholder="29.00"
                    className="field-input" />
                </div>
                <div className="w-24">
                  <label className="field-label">Currency</label>
                  <select value={invoiceForm.currency} onChange={e => setInvoiceForm(f => ({ ...f, currency: e.target.value }))}
                    className="field-input">
                    <option>USD</option><option>EUR</option><option>GBP</option><option>ZAR</option><option>NGN</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="field-label">Notes (optional)</label>
                <textarea value={invoiceForm.notes} onChange={e => setInvoiceForm(f => ({ ...f, notes: e.target.value }))} rows={2}
                  className="field-input resize-none" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setMarkPaidTenant(null)}
                className="flex-1 py-2.5 border border-border-subtle text-muted-foreground rounded-none text-sm hover:border-white/20 hover:text-foreground transition-colors">
                Cancel
              </button>
              <button onClick={() => createInvoice(markPaidTenant.id, true)} disabled={savingInvoice}
                className="flex-1 py-2.5 bg-primary text-black font-bold rounded-none text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {savingInvoice ? (
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                ) : <Receipt className="w-4 h-4" />}
                {savingInvoice ? 'Saving…' : 'Mark Paid + Generate Invoice'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── CREATE INVOICE MODAL ─────────────────────────────────────── */}
      {showCreateInvoice && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setShowCreateInvoice(false); }}>
          <div className="bg-chassis border border-border-subtle rounded-none w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground">New Invoice</h2>
              <button onClick={() => setShowCreateInvoice(false)} className="text-muted-foreground hover:text-foreground"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="field-label">Customer *</label>
                <select value={invoiceForm.tenant_id} onChange={e => setInvoiceForm(f => ({ ...f, tenant_id: parseInt(e.target.value) }))}
                  className="field-input">
                  <option value={0}>— Select customer —</option>
                  {tenants.map(t => <option key={t.id} value={t.id}>{t.business_name}</option>)}
                </select>
              </div>
              <div>
                <label className="field-label">Plan / Description</label>
                <select value={invoiceForm.plan_name} onChange={e => {
                  const val = e.target.value;
                  const matched = plans.find(p => `${p.name} — ${p.price}/${p.sub_label}` === val);
                  const numeric = matched ? String(matched.price).replace(/[^0-9.]/g, '') : '';
                  setInvoiceForm(f => ({ ...f, plan_name: val, amount: numeric || f.amount, billing_period: matched?.billing_period || f.billing_period }));
                }}
                  className="field-input">
                  <option value="">— Select a plan —</option>
                  {plans.map(p => (
                    <option key={p.id} value={`${p.name} — ${p.price}/${p.sub_label}`}>
                      {p.name} — {p.price}/{p.sub_label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="field-label">Amount *</label>
                  <input type="number" min="0" step="0.01" value={invoiceForm.amount} onChange={e => setInvoiceForm(f => ({ ...f, amount: e.target.value }))}
                    placeholder="29.00"
                    className="field-input" />
                </div>
                <div className="w-24">
                  <label className="field-label">Currency</label>
                  <select value={invoiceForm.currency} onChange={e => setInvoiceForm(f => ({ ...f, currency: e.target.value }))}
                    className="field-input">
                    <option>USD</option><option>EUR</option><option>GBP</option><option>ZAR</option><option>NGN</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="field-label">Notes (optional)</label>
                <textarea value={invoiceForm.notes} onChange={e => setInvoiceForm(f => ({ ...f, notes: e.target.value }))} rows={2}
                  className="field-input resize-none" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowCreateInvoice(false)}
                className="flex-1 py-2.5 border border-border-subtle text-muted-foreground rounded-none text-sm hover:border-white/20 hover:text-foreground transition-colors">
                Cancel
              </button>
              <button onClick={() => createInvoice(invoiceForm.tenant_id)} disabled={savingInvoice || !invoiceForm.tenant_id || !invoiceForm.amount}
                className="flex-1 py-2.5 bg-primary text-black font-bold rounded-none text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {savingInvoice ? (
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                ) : <Receipt className="w-4 h-4" />}
                {savingInvoice ? 'Creating…' : 'Create Invoice'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── PRINT / VIEW INVOICE MODAL ────────────────────────────────── */}
      {printInvoice && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={e => { if (e.target === e.currentTarget) setPrintInvoice(null); }}>
          <div className="bg-white text-gray-900 w-full max-w-2xl rounded-none shadow-2xl overflow-hidden max-h-[90vh] flex flex-col print:max-h-none print:shadow-none print:rounded-none">
            <style>{`@media print { body * { visibility: hidden; } #invoice-print-area, #invoice-print-area * { visibility: visible; } #invoice-print-area { position: fixed; top: 0; left: 0; width: 100%; height: auto; overflow: visible; background: white; } }`}</style>
            <div id="invoice-print-area" className="flex flex-col flex-1 overflow-y-auto print:overflow-visible">

              {/* Header band */}
              <div className="bg-[#0a0e17] px-10 py-8">
                <div className="flex items-start justify-between">
                  <div>
                    <img src="/logo.png" alt="FlippedPOS" className="h-16 w-auto mb-3" />
                    <p className="text-gray-400 text-xs tracking-wide">FlippedPOS · SaaS Platform</p>
                    <p className="text-gray-500 text-xs">support@flippedpos.com</p>
                  </div>
                  <div className="text-right">
                    <p className="text-foreground font-extrabold text-2xl tracking-tight letter-spacing-tight">
                      {printInvoice.status === 'paid' ? 'RECEIPT' : 'INVOICE'}
                    </p>
                    <p className="text-gray-500 text-xs font-mono mt-1">{printInvoice.invoice_number}</p>
                    <span className={`inline-block mt-3 px-3 py-1 text-[11px] font-bold tracking-widest uppercase rounded ${
                      printInvoice.status === 'paid'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-400/10 text-amber-400 border border-amber-400/30'
                    }`}>
                      {printInvoice.status === 'paid' ? 'PAID' : 'PENDING'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-gray-100" />

              {/* Body */}
              <div className="px-10 py-8 space-y-8 bg-white">

                {/* Bill To + Dates row */}
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.15em] mb-2">Bill To</p>
                    <p className="font-bold text-gray-900 text-xl leading-tight">{printInvoice.business_name}</p>
                    {printInvoice.customer_code && (
                      <p className="text-[11px] font-mono text-gray-400 mt-1">Customer Code: {printInvoice.customer_code}</p>
                    )}
                  </div>
                  <div className="text-right space-y-1.5">
                    <div className="flex items-center justify-end gap-6 text-sm">
                      <span className="text-gray-400 text-xs font-medium">Issue Date</span>
                      <span className="font-semibold text-gray-800 text-xs w-36 text-right">
                        {new Date(printInvoice.issued_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}
                      </span>
                    </div>
                    {printInvoice.paid_at && (
                      <div className="flex items-center justify-end gap-6 text-sm">
                        <span className="text-gray-400 text-xs font-medium">Date Paid</span>
                        <span className="font-semibold text-emerald-600 text-xs w-36 text-right">
                          {new Date(printInvoice.paid_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Line items table */}
                <div className="border border-gray-200 rounded-none overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200">
                        <th className="px-5 py-3 text-left text-[10px] font-bold text-gray-500 uppercase tracking-[0.12em] w-16">#</th>
                        <th className="px-5 py-3 text-left text-[10px] font-bold text-gray-500 uppercase tracking-[0.12em]">Description</th>
                        <th className="px-5 py-3 text-right text-[10px] font-bold text-gray-500 uppercase tracking-[0.12em]">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t border-gray-100">
                        <td className="px-5 py-4 text-gray-400 text-xs">01</td>
                        <td className="px-5 py-4 text-gray-800 font-medium">{printInvoice.plan_name || 'Subscription Service'}</td>
                        <td className="px-5 py-4 text-right font-semibold text-gray-900">
                          {printInvoice.currency} {Number(printInvoice.amount).toFixed(2)}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="bg-gray-50 border-t border-gray-200 px-5 py-4 flex justify-between items-center">
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Total Due</span>
                    <span className="text-2xl font-extrabold text-gray-900">
                      {printInvoice.currency} {Number(printInvoice.amount).toFixed(2)}
                    </span>
                  </div>
                </div>

                {printInvoice.notes && (
                  <div className="border-l-4 border-gray-200 pl-4">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.15em] mb-1">Notes</p>
                    <p className="text-sm text-gray-600 leading-relaxed">{printInvoice.notes}</p>
                  </div>
                )}

                {/* Footer */}
                <div className="border-t border-gray-100 pt-6 flex items-center justify-between">
                  <p className="text-xs text-gray-400">Thank you for your business.</p>
                  <p className="text-xs text-gray-400">FlippedPOS SaaS Platform</p>
                </div>
              </div>
            </div>

            {/* Action bar — screen only */}
            <div className="px-10 py-4 bg-gray-50 border-t border-gray-200 flex items-center gap-3 print:hidden">
              <button onClick={() => window.print()}
                className="flex items-center gap-2 px-4 py-2 bg-gray-900 text-foreground font-semibold text-sm rounded-none hover:bg-black transition-colors">
                <Printer className="w-4 h-4" /> Print / Save PDF
              </button>
              {printInvoice.status === 'pending' && (
                <button onClick={() => payInvoice(printInvoice)}
                  className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-foreground font-semibold text-sm rounded-none hover:bg-emerald-700 transition-colors">
                  <CheckCircle2 className="w-4 h-4" /> Mark as Paid
                </button>
              )}
              <button onClick={() => setPrintInvoice(null)}
                className="ml-auto flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-600 font-semibold text-sm rounded-none hover:bg-gray-100 transition-colors">
                <X className="w-4 h-4" /> Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── ADD NEW PLAN MODAL ────────────────────────────────────────── */}
      {showAddPlan && (
        <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setShowAddPlan(false); }}>
          <div className="bg-chassis border border-border-subtle rounded-none w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground">Add Pricing Plan</h2>
              <button onClick={() => setShowAddPlan(false)} className="text-muted-foreground hover:text-foreground"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="field-label">Plan Name *</label>
                <input value={addPlanForm.name} onChange={e => setAddPlanForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="e.g. Professional"
                  className="field-input" />
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="field-label">Price *</label>
                  <input value={addPlanForm.price} onChange={e => setAddPlanForm(f => ({ ...f, price: e.target.value }))}
                    placeholder="$29"
                    className="field-input" />
                </div>
                <div className="flex-1">
                  <label className="field-label">Display Label</label>
                  <input value={addPlanForm.sub_label} onChange={e => setAddPlanForm(f => ({ ...f, sub_label: e.target.value }))}
                    placeholder="per month"
                    className="field-input" />
                </div>
              </div>
              <div>
                <label className="field-label">Billing Period</label>
                <select value={addPlanForm.billing_period} onChange={e => setAddPlanForm(f => ({ ...f, billing_period: e.target.value }))}
                  className="field-input">
                  <option value="monthly">Monthly (30 days)</option>
                  <option value="quarterly">Quarterly (90 days)</option>
                  <option value="annual">Annual (365 days)</option>
                </select>
              </div>
              <div>
                <label className="field-label">Description</label>
                <input value={addPlanForm.description} onChange={e => setAddPlanForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="Short plan description"
                  className="field-input" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowAddPlan(false)}
                className="flex-1 py-2.5 border border-border-subtle text-muted-foreground rounded-none text-sm hover:border-white/20 hover:text-foreground transition-colors">
                Cancel
              </button>
              <button onClick={createNewPlan} disabled={savingAddPlan || !addPlanForm.name || !addPlanForm.price}
                className="flex-1 py-2.5 bg-primary text-black font-bold rounded-none text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {savingAddPlan ? (
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                ) : <Plus className="w-4 h-4" />}
                {savingAddPlan ? 'Saving…' : 'Add Plan'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── CREATE ADMIN MODAL ────────────────────────────────────────── */}
      {showCreateAdmin && (
        <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setShowCreateAdmin(false); }}>
          <div className="bg-chassis border border-border-subtle rounded-none w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground">Add Administrator</h2>
              <button onClick={() => setShowCreateAdmin(false)} className="text-muted-foreground hover:text-foreground"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="field-label">Name *</label>
                <input value={adminForm.name} onChange={e => setAdminForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="John Doe"
                  className="field-input" />
              </div>
              <div>
                <label className="field-label">Email *</label>
                <input value={adminForm.email} onChange={e => setAdminForm(f => ({ ...f, email: e.target.value }))}
                  placeholder="admin@example.com" type="email"
                  className="field-input" />
              </div>
              <div>
                <label className="field-label">Password *</label>
                <input value={adminForm.password} onChange={e => setAdminForm(f => ({ ...f, password: e.target.value }))}
                  placeholder="Secure password" type="password"
                  className="field-input" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowCreateAdmin(false)}
                className="flex-1 py-2.5 border border-border-subtle text-muted-foreground rounded-none text-sm hover:border-white/20 hover:text-foreground transition-colors">
                Cancel
              </button>
              <button onClick={createAdmin} disabled={savingAdmin || !adminForm.name || !adminForm.email || !adminForm.password}
                className="flex-1 py-2.5 bg-primary text-black font-bold rounded-none text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {savingAdmin ? 'Saving…' : 'Add Admin'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Plan editor card ──────────────────────────────────────────────── */
function PlanEditor({ plan: initial, saving, onSave, onDelete }: { plan: PricingPlan; saving: boolean; onSave: (p: PricingPlan) => void; onDelete: (id: number) => void }) {
  const [p, setP] = useState<PricingPlan>(initial);
  const [open, setOpen] = useState(false);

  useEffect(() => { setP(initial); }, [initial]);

  const updateFeature = (i: number, val: string) =>
    setP(prev => ({ ...prev, features: prev.features.map((f, idx) => idx === i ? val : f) }));
  const addFeature = () => setP(prev => ({ ...prev, features: [...prev.features, ''] }));
  const removeFeature = (i: number) => setP(prev => ({ ...prev, features: prev.features.filter((_, idx) => idx !== i) }));

  const changed = JSON.stringify(p) !== JSON.stringify(initial);

  return (
    <div className={`bg-[#0d1117] border rounded-none overflow-hidden ${p.highlight ? 'border-brand/40' : 'border-border-subtle'}`}>
      {/* Drag handle bar */}
      <div className="flex items-center justify-between px-4 pt-3 pb-1">
        <span className="text-[10px] text-muted-foreground/40 select-none tracking-widest">⠿⠿⠿ drag to reorder</span>
        <button
          onClick={() => onDelete(p.id)}
          title="Delete plan"
          className="text-muted-foreground/30 hover:text-red-400 transition-colors p-0.5"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
      {/* Card body */}
      <div className="px-4 pb-4">
        {p.highlight && <div className="text-[10px] font-mono text-primary uppercase tracking-widest mb-2">★ Most Popular</div>}
        <div className="flex items-start justify-between gap-2">
          <div>
            <input value={p.name} onChange={e => setP(prev => ({ ...prev, name: e.target.value }))}
              className="bg-transparent text-foreground font-bold text-lg w-full focus:outline-none focus:border-b focus:border-primary/60" />
            <div className="flex items-end gap-1.5 mt-1">
              <input value={p.price} onChange={e => setP(prev => ({ ...prev, price: e.target.value }))}
                className="bg-transparent text-primary font-bold font-mono text-2xl w-24 focus:outline-none border-b border-transparent focus:border-primary/60" />
              <input value={p.sub_label} onChange={e => setP(prev => ({ ...prev, sub_label: e.target.value }))}
                className="bg-transparent text-muted-foreground text-xs mb-1 w-24 focus:outline-none border-b border-transparent focus:border-primary/60/40" />
            </div>
          </div>
          <label className="flex items-center gap-1.5 cursor-pointer mt-1 flex-shrink-0">
            <input type="checkbox" checked={p.highlight} onChange={e => setP(prev => ({ ...prev, highlight: e.target.checked }))} className="accent-brand" />
            <span className="text-xs text-muted-foreground">Popular</span>
          </label>
        </div>

        <textarea value={p.description} onChange={e => setP(prev => ({ ...prev, description: e.target.value }))} rows={2}
          className="mt-3 w-full bg-black/30 border border-border-subtle rounded-none text-sm text-muted-foreground p-2 focus:outline-none focus:border-primary/60/50 resize-none" />
      </div>

      {/* Features accordion */}
      <div className="border-t border-border-subtle">
        <button onClick={() => setOpen(o => !o)}
          className="w-full flex items-center justify-between px-4 py-2.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
          <span>{p.features.length} features</span>
          {open ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
        {open && (
          <div className="px-4 pb-3 space-y-1.5">
            {p.features.map((f, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <input value={f} onChange={e => updateFeature(i, e.target.value)}
                  className="flex-1 bg-black/30 border border-border-subtle rounded px-2 py-1 text-xs text-zinc-300 focus:outline-none focus:border-primary/60/50" />
                <button onClick={() => removeFeature(i)} className="text-muted-foreground/50 hover:text-red-400 p-0.5">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            <button onClick={addFeature} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors mt-1">
              <Plus className="w-3.5 h-3.5" /> Add feature
            </button>
          </div>
        )}
      </div>

      {/* Billing period */}
      <div className="border-t border-border-subtle px-4 py-2">
        <label className="block text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Billing Period</label>
        <select value={p.billing_period || 'monthly'} onChange={e => setP(prev => ({ ...prev, billing_period: e.target.value as PricingPlan['billing_period'] }))}
          className="w-full px-2 py-1.5 bg-black/30 border border-border-subtle rounded text-xs text-zinc-300 focus:outline-none focus:border-primary/60/50">
          <option value="monthly">Monthly (30 days)</option>
          <option value="quarterly">Quarterly (90 days)</option>
          <option value="annual">Annual (365 days)</option>
        </select>
      </div>

      {/* CTA + save */}
      <div className="border-t border-border-subtle p-4 space-y-2">
        <div className="flex gap-2">
          <input value={p.cta_label} onChange={e => setP(prev => ({ ...prev, cta_label: e.target.value }))}
            placeholder="Button label"
            className="flex-1 bg-black/30 border border-border-subtle rounded px-2 py-1 text-xs text-zinc-300 focus:outline-none focus:border-primary/60/50" />
          <input value={p.cta_href} onChange={e => setP(prev => ({ ...prev, cta_href: e.target.value }))}
            placeholder="Button URL"
            className="flex-1 bg-black/30 border border-border-subtle rounded px-2 py-1 text-xs text-zinc-300 focus:outline-none focus:border-primary/60/50" />
        </div>
        <button onClick={() => onSave(p)} disabled={saving || !changed}
          className={`w-full flex items-center justify-center gap-2 py-2 rounded-none text-sm font-semibold transition-colors
            ${changed ? 'bg-primary text-black hover:bg-primary/90' : 'bg-background/50 text-muted-foreground/50 cursor-not-allowed'}`}>
          {saving ? (
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </span>
          ) : <Save className="w-4 h-4" />}
          {saving ? 'Saving…' : 'Save Plan'}
        </button>
      </div>
    </div>
  );
}

/* ── suppress unused import warnings ─ */
const _unused = { TrendingUp };
