import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, Clock, FileText, Download, AlertTriangle, CreditCard, Loader2 } from 'lucide-react';
// @ts-ignore
import html2pdf from 'html2pdf.js';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;

interface Invoice {
  id: number;
  invoice_number: string;
  plan_name: string;
  amount: number;
  currency: string;
  billing_period: string;
  status: 'pending' | 'paid';
  issued_at: string;
  paid_at: string | null;
}

interface TenantInfo {
  business_name: string;
  customer_code: string;
  email: string;
}

function fmtDate(d: string | null) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

const PERIOD: Record<string, string> = { monthly: 'Monthly', quarterly: 'Quarterly', annual: 'Annual' };

function downloadInvoice(inv: Invoice, tenant: TenantInfo | null) {
  const html = `
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; color: #1e293b; background: #fff; padding: 48px; box-sizing: border-box;">
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; }
        .brand { font-size: 22px; font-weight: 800; color: #0f172a; letter-spacing: -0.5px; text-transform: uppercase; }
        .invoice-meta { text-align: right; }
        .invoice-meta h1 { font-size: 28px; font-weight: 800; color: #0f172a; letter-spacing: -1px; text-transform: uppercase; }
        .invoice-meta p { font-size: 13px; color: #64748b; margin-top: 4px; font-family: monospace; }
        .divider { border: none; border-top: 2px solid #e2e8f0; margin: 24px 0; }
        .parties { display: flex; gap: 64px; margin-bottom: 32px; }
        .party h3 { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #94a3b8; margin-bottom: 8px; }
        .party p { font-size: 14px; color: #334155; line-height: 1.6; font-family: monospace; }
        .party .name { font-weight: 700; font-size: 15px; color: #0f172a; font-family: sans-serif; text-transform: uppercase; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
        thead tr { background: #f8fafc; }
        th { padding: 10px 14px; text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #64748b; border-bottom: 2px solid #000; }
        td { padding: 14px; font-size: 14px; color: #334155; border-bottom: 1px solid #e2e8f0; font-family: monospace; }
        .amount-col { text-align: right; }
        .total-row td { font-weight: 800; font-size: 16px; color: #0f172a; border-top: 2px solid #000; border-bottom: none; }
        .status-badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; border: 1px solid #000; }
        .paid   { background: #dcfce7; color: #15803d; border-color: #15803d; }
        .pending { background: #fef9c3; color: #92400e; border-color: #92400e; }
        .footer { margin-top: 48px; padding-top: 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #94a3b8; font-family: monospace; }
      </style>
      <div class="header">
        <img src="https://flippedpos.com/logo.png" alt="FlippedPOS" style="height: 100px; width: auto;" />
        <div class="invoice-meta">
          <h1>INVOICE</h1>
          <p>#${inv.invoice_number}</p>
          <p>Issued: ${fmtDate(inv.issued_at)}</p>
          ${inv.paid_at ? `<p>Paid: ${fmtDate(inv.paid_at)}</p>` : ''}
        </div>
      </div>
      <hr class="divider" />
      <div class="parties">
        <div class="party">
          <h3>From</h3>
          <p class="name">FlippedPOS</p>
          <p>accounts@flippedpos.com</p>
          <p>flippedpos.com</p>
        </div>
        <div class="party">
          <h3>Bill To</h3>
          <p class="name">${tenant?.business_name ?? 'Customer'}</p>
          ${tenant?.email ? `<p>${tenant.email}</p>` : ''}
          ${tenant?.customer_code ? `<p>Code: ${tenant.customer_code}</p>` : ''}
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Description</th>
            <th>Billing Period</th>
            <th class="amount-col">Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${inv.plan_name || 'FlippedPOS Subscription'}</td>
            <td>${PERIOD[inv.billing_period] ?? inv.billing_period ?? '—'}</td>
            <td class="amount-col">${inv.currency} ${Number(inv.amount).toFixed(2)}</td>
            <td><span class="status-badge ${inv.status}">${inv.status === 'paid' ? 'PAID' : 'PENDING'}</span></td>
          </tr>
        </tbody>
        <tfoot>
          <tr class="total-row">
            <td colspan="2">TOTAL</td>
            <td class="amount-col">${inv.currency} ${Number(inv.amount).toFixed(2)}</td>
            <td></td>
          </tr>
        </tfoot>
      </table>
      <div class="footer">
        <span>FlippedPOS — Thank you for your business!</span>
        <span>Generated ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
      </div>
    </div>`;

  const container = document.createElement('div');
  container.innerHTML = html;

  const opt = {
    margin: 0,
    filename: `Invoice_${inv.invoice_number}.pdf`,
    image: { type: 'jpeg' as const, quality: 0.98 },
    html2canvas: { scale: 2, useCORS: true },
    jsPDF: { unit: 'in' as const, format: 'letter' as const, orientation: 'portrait' as const }
  };

  html2pdf().set(opt).from(container).save();
}

export default function CustomerBilling() {
  const navigate = useNavigate();
  const token = localStorage.getItem('customer_token');
  const [tenant] = useState<TenantInfo | null>(() => {
    try { return JSON.parse(localStorage.getItem('customer_tenant') || 'null'); } catch { return null; }
  });
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [payingInvoiceId, setPayingInvoiceId] = useState<number | null>(null);

  const handlePayInvoice = async (invoiceId: number) => {
    setPayingInvoiceId(invoiceId);
    setError('');
    try {
      const res = await fetch(`${API}/customer/pay-invoice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ invoice_id: invoiceId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to initiate payment');
      
      if (data.redirect_url) {
        window.location.href = data.redirect_url;
      }
    } catch (err: any) {
      setError(err.message);
      setPayingInvoiceId(null);
    }
  };

  useEffect(() => {
    if (!token) { navigate('/account'); return; }
    fetch(`${API}/customer/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(data => {
        if (data.error) { setError(data.error); return; }
        setInvoices(data.invoices || []);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [navigate, token]);

  const paid = invoices.filter(i => i.status === 'paid');
  const pending = invoices.filter(i => i.status === 'pending');
  const total = paid.reduce((s, i) => s + Number(i.amount), 0);

  return (
    <div className="space-y-6 w-full text-foreground">
      <div>
        <h1 className="text-xl font-bold uppercase tracking-wide">Billing</h1>
        <p className="text-muted-foreground text-xs mt-1 font-mono">All invoices issued to your account. Download any invoice as a PDF.</p>
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {error}
        </div>
      )}

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Invoices', value: invoices.length, color: 'text-foreground', border: 'border-border-subtle' },
          { label: 'Paid', value: paid.length, color: 'text-primary', border: 'border-primary/20' },
          { label: 'Pending', value: pending.length, color: pending.length > 0 ? 'text-orange-400' : 'text-foreground', border: pending.length > 0 ? 'border-orange-500/20' : 'border-border-subtle' },
        ].map(s => (
          <div key={s.label} className={`bg-chassis border ${s.border} p-5 text-center`}>
            <p className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</p>
            <p className="text-[9px] text-muted-foreground font-mono-tech mt-2 uppercase tracking-widest">{s.label}</p>
          </div>
        ))}
      </div>

      {paid.length > 0 && (
        <div className="bg-primary/5 border border-primary/20 px-5 py-4 flex items-center justify-between">
          <p className="text-[10px] font-mono-tech text-primary uppercase tracking-widest">Total paid to date</p>
          <p className="text-lg font-bold font-mono text-primary">${total.toFixed(2)}</p>
        </div>
      )}

      {/* Invoices table */}
      <div className="bg-chassis border border-border-subtle overflow-hidden">
        <div className="px-5 py-4 border-b border-border-subtle flex items-center gap-2 bg-background/30">
          <FileText className="w-4 h-4 text-primary" />
          <h2 className="text-[10px] font-mono-tech uppercase tracking-widest text-primary">Invoices</h2>
        </div>

        {loading ? (
          <div className="p-10 text-center text-muted-foreground font-mono uppercase tracking-widest text-xs">Loading…</div>
        ) : invoices.length === 0 ? (
          <div className="p-12 text-center space-y-4">
            <FileText className="w-8 h-8 text-muted-foreground/30 mx-auto" />
            <p className="text-muted-foreground text-xs font-mono uppercase tracking-widest">No invoices yet</p>
            <p className="text-muted-foreground/60 text-[10px] font-mono">Invoices will appear here once raised by the FlippedPOS team.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-background/50 border-b border-border-subtle">
                  <th className="text-left px-5 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech">Invoice #</th>
                  <th className="text-left px-4 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech">Plan</th>
                  <th className="text-left px-4 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech">Period</th>
                  <th className="text-right px-4 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech">Amount</th>
                  <th className="text-left px-4 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech">Issued</th>
                  <th className="text-left px-4 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech">Status</th>
                  <th className="px-4 py-3 text-[9px] text-muted-foreground uppercase tracking-widest font-mono-tech"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-subtle">
                {invoices.map(inv => (
                  <tr key={inv.id} className="hover:bg-background/30 transition-colors">
                    <td className="px-5 py-4 font-mono text-xs text-muted-foreground">{inv.invoice_number}</td>
                    <td className="px-4 py-4 text-foreground text-xs">{inv.plan_name || '—'}</td>
                    <td className="px-4 py-4 text-muted-foreground text-xs capitalize">{PERIOD[inv.billing_period] ?? inv.billing_period ?? '—'}</td>
                    <td className="px-4 py-4 text-right font-mono text-xs font-bold text-foreground">{inv.currency} {Number(inv.amount).toFixed(2)}</td>
                    <td className="px-4 py-4 text-muted-foreground text-[10px] font-mono whitespace-nowrap">{fmtDate(inv.issued_at)}</td>
                    <td className="px-4 py-4">
                      {inv.status === 'paid' ? (
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 border border-primary/20 bg-primary/10 text-primary text-[9px] font-mono-tech uppercase tracking-widest">
                          <CheckCircle2 className="w-3 h-3" /> Paid
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 border border-orange-500/20 bg-orange-500/10 text-orange-400 text-[9px] font-mono-tech uppercase tracking-widest">
                          <Clock className="w-3 h-3" /> Pending
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-4 flex items-center justify-end gap-2">
                      {inv.status === 'pending' && (
                        <button
                          onClick={() => handlePayInvoice(inv.id)}
                          disabled={payingInvoiceId === inv.id}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-background hover:bg-primary/90 transition-colors text-[9px] font-mono-tech uppercase tracking-widest disabled:opacity-50"
                        >
                          {payingInvoiceId === inv.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <CreditCard className="w-3.5 h-3.5" />
                          )}
                          Pay Now
                        </button>
                      )}
                      <button
                        onClick={() => downloadInvoice(inv, tenant)}
                        className="flex items-center gap-1.5 px-3 py-1.5 border border-border-subtle text-muted-foreground hover:text-foreground hover:border-foreground transition-all text-[9px] font-mono-tech uppercase tracking-widest"
                        title="Download as PDF"
                      >
                        <Download className="w-3.5 h-3.5" /> Download
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
