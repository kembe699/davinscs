import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, Copy, Check, ExternalLink, Database, AlertTriangle } from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;
const POS_BASE = import.meta.env.VITE_POS_URL || 'https://app.flippedpos.com';
const DB_LIMIT = 500 * 1024 * 1024;

interface TenantInfo {
  business_name: string; customer_code: string; tenant_slug: string;
  schema_name: string; email: string;
}
interface Snapshot { size_bytes: string; recorded_at: string; }

function fmtBytes(bytes: number) {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function fmtAxisDate(d: string) {
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-chassis border border-border-subtle p-3 text-xs font-mono">
        <p className="text-muted-foreground mb-1">{new Date(label).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
        <p className="font-bold text-foreground">{fmtBytes(payload[0].value)}</p>
      </div>
    );
  }
  return null;
};

export default function CustomerInstance() {
  const navigate = useNavigate();
  const token = localStorage.getItem('customer_token');
  const [tenant] = useState<TenantInfo | null>(() => {
    try { return JSON.parse(localStorage.getItem('customer_tenant') || 'null'); } catch { return null; }
  });
  const [dbSize, setDbSize] = useState(0);
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [copied, setCopied] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) { navigate('/account'); return; }
    const h = { Authorization: `Bearer ${token}` };
    Promise.all([
      fetch(`${API}/customer/me`, { headers: h }).then(r => r.json()),
      fetch(`${API}/customer/db-history`, { headers: h }).then(r => r.json()),
    ]).then(([me, hist]) => {
      if (me.error) { setError(me.error); return; }
      setDbSize(me.db_size_bytes || 0);
      setSnapshots(Array.isArray(hist) ? hist : []);
    }).catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [navigate, token]);

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(''), 1500);
    });
  };

  const dbPct = Math.min((dbSize / DB_LIMIT) * 100, 100);

  const chartData = snapshots.map(s => ({
    date: s.recorded_at,
    bytes: parseInt(s.size_bytes),
  }));

  const barColor = dbPct > 80 ? '#ef4444' : dbPct > 50 ? '#f97316' : '#00dc82';

  return (
    <div className="space-y-6 w-full text-foreground">
      <div>
        <h1 className="text-xl font-bold uppercase tracking-wide">My POS Instance</h1>
        <p className="text-muted-foreground text-xs mt-1 font-mono">Your hosted FlippedPOS environment details and database analytics.</p>
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {error}
        </div>
      )}

      {/* Instance details */}
      {tenant && (
        <div className="bg-chassis border border-border-subtle p-6">
          <h2 className="text-[10px] font-mono-tech uppercase tracking-widest text-primary flex items-center gap-2 mb-5">
            <Building2 className="w-4 h-4" /> Instance Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-4">
              <div>
                <p className="text-[9px] text-muted-foreground font-mono-tech uppercase tracking-widest mb-1">Business Name</p>
                <p className="text-foreground font-bold text-sm tracking-wide">{tenant.business_name}</p>
              </div>
              <div className="h-px bg-border-subtle" />
              <div>
                <p className="text-[9px] text-muted-foreground font-mono-tech uppercase tracking-widest mb-1">Customer Code</p>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-primary bg-primary/10 border border-primary/20 px-3 py-1.5 text-xs">
                    {tenant.customer_code}
                  </span>
                  <button
                    onClick={() => copyText(tenant.customer_code, 'code')}
                    className="p-1.5 border border-transparent hover:border-border-subtle text-muted-foreground hover:text-foreground hover:bg-background/50 transition-colors"
                  >
                    {copied === 'code' ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-[9px] text-muted-foreground font-mono-tech uppercase tracking-widest mb-1">Instance URL</p>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-foreground font-mono bg-background border border-border-subtle px-3 py-1.5 truncate flex-1 min-w-0">
                    {POS_BASE}/{tenant.tenant_slug}/admin
                  </span>
                  <button
                    onClick={() => copyText(`${POS_BASE}/${tenant.tenant_slug}/admin`, 'url')}
                    className="p-1.5 border border-transparent hover:border-border-subtle text-muted-foreground hover:text-foreground hover:bg-background/50 transition-colors flex-shrink-0"
                  >
                    {copied === 'url' ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div className="h-px bg-border-subtle" />
              <div>
                <p className="text-[9px] text-muted-foreground font-mono-tech uppercase tracking-widest mb-2">Current DB Usage</p>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-mono text-foreground">{fmtBytes(dbSize)}</span>
                  <span className="text-[10px] font-mono text-muted-foreground">of 500 MB ({dbPct.toFixed(1)}%)</span>
                </div>
                <div className="h-2 bg-background border border-border-subtle overflow-hidden">
                  <div
                    className="h-full transition-all"
                    style={{ width: `${Math.max(dbPct, 0.5)}%`, backgroundColor: barColor }}
                  />
                </div>
              </div>
            </div>
          </div>

          {tenant.tenant_slug && (
            <a
              href={`${POS_BASE}/${tenant.tenant_slug}/admin/login`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 flex items-center justify-center gap-2 w-full py-3 bg-primary text-background text-[11px] font-mono-tech uppercase tracking-widest hover:bg-primary/90 transition-colors"
            >
              Open POS Dashboard <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>
      )}

      {/* DB Growth Chart */}
      <div className="bg-chassis border border-border-subtle p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[10px] font-mono-tech uppercase tracking-widest text-primary flex items-center gap-2">
            <Database className="w-4 h-4" /> Database Growth Over Time
          </h2>
          {snapshots.length > 0 && (
            <span className="text-[9px] font-mono text-muted-foreground uppercase tracking-widest">{snapshots.length} snapshots recorded</span>
          )}
        </div>

        {loading ? (
          <div className="h-56 flex items-center justify-center text-muted-foreground text-xs font-mono">Loading chart…</div>
        ) : chartData.length < 2 ? (
          <div className="h-56 flex flex-col items-center justify-center text-center gap-3">
            <Database className="w-8 h-8 text-muted-foreground/30" />
            <p className="text-muted-foreground text-xs font-mono uppercase tracking-widest">Not enough data yet</p>
            <p className="text-muted-foreground/60 text-[10px] max-w-xs font-mono">
              Snapshots are recorded every 6 hours. Check back after a day to see your database growth chart.
            </p>
            {chartData.length === 1 && (
              <div className="mt-2 px-3 py-2 bg-background border border-border-subtle text-[10px] font-mono text-muted-foreground">
                First snapshot: <span className="font-bold text-foreground">{fmtBytes(chartData[0].bytes)}</span> — recorded {fmtAxisDate(chartData[0].date)}
              </div>
            )}
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
              <defs>
                <linearGradient id="dbGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor={barColor} stopOpacity={0.25} />
                  <stop offset="95%" stopColor={barColor} stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border-subtle))" vertical={false} />
              <XAxis
                dataKey="date"
                tickFormatter={fmtAxisDate}
                tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))', fontFamily: 'monospace' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tickFormatter={v => fmtBytes(v)}
                tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))', fontFamily: 'monospace' }}
                axisLine={false}
                tickLine={false}
                width={70}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="stepAfter"
                dataKey="bytes"
                stroke={barColor}
                strokeWidth={2}
                fill="url(#dbGradient)"
                dot={chartData.length <= 15}
                activeDot={{ r: 4, strokeWidth: 0 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
