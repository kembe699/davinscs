import { useEffect } from 'react';
import { Link, useNavigate, useLocation, Outlet } from 'react-router-dom';
import { LogOut, LayoutDashboard, CreditCard, Building2, Menu, X } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { path: '/account/dashboard', label: 'Overview',    icon: <LayoutDashboard className="w-4 h-4" /> },
  { path: '/account/billing',   label: 'Billing',      icon: <CreditCard className="w-4 h-4" /> },
  { path: '/account/instance',  label: 'My Instance',  icon: <Building2 className="w-4 h-4" /> },
];

export default function CustomerLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('customer_token');
    if (!token) navigate('/account');
  }, [navigate]);

  const logout = () => {
    localStorage.removeItem('customer_token');
    localStorage.removeItem('customer_tenant');
    navigate('/account');
  };

  const tenant = (() => {
    try { return JSON.parse(localStorage.getItem('customer_tenant') || 'null'); } catch { return null; }
  })();

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-chassis border-r border-border-subtle text-foreground">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-border-subtle flex items-center justify-between">
        <Link to="/" onClick={() => setOpen(false)}>
          <img src="/logo.png" alt="FlippedPOS" className="h-10 w-auto" />
        </Link>
        <button onClick={() => setOpen(false)} className="lg:hidden p-1 text-muted-foreground hover:text-foreground">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        <p className="px-3 mb-2 text-[10px] font-mono-tech text-muted-foreground uppercase tracking-widest">Menu</p>
        {navItems.map(item => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition-colors border ${
                active 
                  ? 'bg-primary/10 border-primary/20 text-primary' 
                  : 'border-transparent text-muted-foreground hover:text-foreground hover:bg-background/50 hover:border-border-subtle'
              }`}
            >
              {item.icon}
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Bottom: user + logout */}
      <div className="px-3 pb-5 border-t border-border-subtle pt-4 space-y-2">
        {tenant && (
          <div className="px-3 py-2.5 border border-border-subtle bg-background/50">
            <p className="text-[9px] font-mono-tech text-muted-foreground uppercase tracking-widest mb-1">Signed in as</p>
            <p className="text-xs text-foreground truncate font-mono">{tenant.email}</p>
            {tenant.business_name && (
              <p className="text-[10px] text-muted-foreground truncate mt-1 uppercase tracking-widest">{tenant.business_name}</p>
            )}
          </div>
        )}
        <button
          onClick={logout}
          className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm font-mono-tech uppercase tracking-widest text-red-400 hover:text-red-300 hover:bg-red-500/10 border border-transparent hover:border-red-500/20 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background text-foreground font-sans overflow-hidden selection:bg-primary/30">
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-64 flex-shrink-0 h-full">
        <SidebarContent />
      </div>

      {/* Mobile overlay */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-64 z-50">
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Topbar */}
        <header className="bg-chassis border-b border-border-subtle px-4 sm:px-6 py-4 flex items-center gap-3 flex-shrink-0">
          <button
            onClick={() => setOpen(true)}
            className="lg:hidden p-1.5 border border-border-subtle text-muted-foreground hover:text-foreground hover:bg-background/50 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <p className="text-xs font-mono-tech uppercase tracking-widest text-foreground">
            {navItems.find(n => n.path === location.pathname)?.label ?? 'Account'}
          </p>
          {tenant && (
            <span className="ml-auto hidden sm:block text-[10px] text-muted-foreground font-mono-tech uppercase tracking-widest bg-background border border-border-subtle px-2 py-1">
              {tenant.customer_code}
            </span>
          )}
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-8 py-7">
          <Outlet />
          <p className="text-center text-[10px] font-mono-tech uppercase tracking-widest text-muted-foreground mt-10 pb-2">
            Need help?{' '}
            <a href="mailto:support@flippedpos.com" className="hover:text-foreground underline underline-offset-4 transition-colors">
              support@flippedpos.com
            </a>
          </p>
        </main>
      </div>
    </div>
  );
}
