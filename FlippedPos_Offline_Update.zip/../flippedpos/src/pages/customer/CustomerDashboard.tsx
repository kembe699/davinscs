import { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  LogOut, RefreshCw, CheckCircle2, XCircle, Clock, Database,
  ExternalLink, CreditCard, FileText, Building2, Copy, Check,
  AlertTriangle, Calendar, Zap, LayoutDashboard, Menu, X,
} from 'lucide-react';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;
const POS_BASE = import.meta.env.VITE_POS_URL || 'https://app.flippedpos.com';

type Section = 'overview' | 'billing' | 'instance';

interface TenantInfo {
  id: number;
  business_name: string;
  customer_code: string;
  tenant_slug: string;
  schema_name: string;
  status: 'active' | 'trial' | 'suspended';
  trial_ends_at: string;
  subscription_start: string | null;
  subscription_end: string | null;
  created_at: string;
  email: string;
}

interface Invoice {
  id: number;
  invoice_number: string;
  plan_name: string;
  amount: number;
  currency: string;
  billing_period: string;
  status: 'pending' | 'paid';
  issued_at: string;
  paid_at: string | null;
}

function fmtBytes(bytes: number) {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function fmtDate(d: string | null) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function daysLeft(d: string | null) {
  if (!d) return null;
  return Math.ceil((new Date(d).getTime() - Date.now()) / 86400000);
}

function StatusBadge({ status }: { status: TenantInfo['status'] }) {
  if (status === 'active') return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-semibold">
      <CheckCircle2 className="w-3 h-3" /> Active
    </span>
  );
  if (status === 'trial') return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">
      <Clock className="w-3 h-3" /> Trial
    </span>
  );
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-semibold">
      <XCircle className="w-3 h-3" /> Suspended
    </span>
  );
}

export default function CustomerDashboard() {
  const navigate = useNavigate();
  const token = localStorage.getItem('customer_token');

  const [section, setSection] = useState<Section>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [tenant, setTenant] = useState<TenantInfo | null>(() => {
    const s = localStorage.getItem('customer_tenant');
    return s ? JSON.parse(s) : null;
  });
  const [dbSize, setDbSize] = useState(0);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState('');

  const authHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  const fetchMe = useCallback(async () => {
    if (!token) { navigate('/account'); return; }
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API}/customer/me`, { headers: authHeaders });
      if (res.status === 401 || res.status === 403) {
        localStorage.removeItem('customer_token');
        localStorage.removeItem('customer_tenant');
        navigate('/account');
        return;
      }
      if (!res.ok) throw new Error('Failed to load account data');
      const data = await res.json();
      setTenant(data.tenant);
      setDbSize(data.db_size_bytes);
      setInvoices(data.invoices);
      localStorage.setItem('customer_tenant', JSON.stringify(data.tenant));
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchMe(); }, [fetchMe]);

  const logout = () => {
    localStorage.removeItem('customer_token');
    localStorage.removeItem('customer_tenant');
    navigate('/account');
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(''), 1500);
    });
  };

  if (!token) return null;

  const periodLabel: Record<string, string> = { monthly: 'Monthly', quarterly: 'Quarterly', annual: 'Annual' };
  const activeDate = tenant?.status === 'active' ? tenant.subscription_end : tenant?.trial_ends_at ?? null;
  const days = daysLeft(activeDate);
  const isExpiringSoon = days !== null && days >= 0 && days <= 7;
  const DB_LIMIT = 500 * 1024 * 1024;
  const dbPct = Math.min((dbSize / DB_LIMIT) * 100, 100);

  const navItems: { id: Section; label: string; icon: React.ReactNode }[] = [
    { id: 'overview',  label: 'Overview',      icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'billing',   label: 'Billing',        icon: <CreditCard className="w-4 h-4" /> },
    { id: 'instance',  label: 'My Instance',    icon: <Building2 className="w-4 h-4" /> },
  ];

  /* ── Sidebar ── */
  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <aside className={`${mobile ? 'flex' : 'hidden lg:flex'} flex-col w-64 bg-[#181f2e] text-white h-full`}>
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/10">
        <Link to="/" onClick={() => setSidebarOpen(false)}>
          <img src="/logo.png" alt="FlippedPOS" className="h-14 w-auto" />
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        <p className="px-3 mb-2 text-[10px] font-semibold text-white/30 uppercase tracking-widest">Menu</p>
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => { setSection(item.id); setSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
              section === item.id
                ? 'bg-brand text-black'
                : 'text-white/60 hover:text-white hover:bg-white/8'
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      {/* User / logout */}
      <div className="px-3 pb-5 border-t border-white/10 pt-4 space-y-2">
        {tenant && (
          <div className="px-3 py-2 rounded-xl bg-white/5">
            <p className="text-[10px] text-white/40 uppercase tracking-wide font-medium mb-0.5">Signed in as</p>
            <p className="text-xs text-white/70 truncate font-mono">{tenant.email}</p>
          </div>
        )}
        <button
          onClick={logout}
          className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-white/50 hover:text-red-400 hover:bg-red-400/10 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );

  /* ── Section: Overview ── */
  const OverviewSection = () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-800">{tenant?.business_name ?? 'My Account'}</h1>
        <p className="text-slate-500 text-sm mt-0.5">Welcome back — here's your account overview.</p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {error}
        </div>
      )}

      {tenant && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Subscription */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                <Zap className="w-4 h-4 text-brand" /> Subscription
              </div>
              <StatusBadge status={tenant.status} />
            </div>

            {tenant.status === 'trial' && (
              <div className={`rounded-xl p-3.5 border text-sm ${isExpiringSoon ? 'bg-orange-50 border-orange-200 text-orange-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
                <p className="font-semibold">Trial period</p>
                <p className="mt-0.5">
                  Ends <span className="font-semibold text-slate-800">{fmtDate(tenant.trial_ends_at)}</span>
                  {days !== null && days >= 0 && <span className="ml-1 text-xs text-slate-400">({days}d left)</span>}
                  {days !== null && days < 0 && <span className="ml-1 text-orange-600 text-xs">(expired)</span>}
                </p>
                <p className="mt-2 text-xs text-slate-400">Pay an invoice before the trial ends to keep your account active.</p>
              </div>
            )}

            {tenant.status === 'active' && (
              <div className={`rounded-xl p-3.5 border text-sm ${isExpiringSoon ? 'bg-orange-50 border-orange-200 text-orange-700' : 'bg-emerald-50 border-emerald-200'}`}>
                <p className="font-semibold text-emerald-700">Subscription active</p>
                {tenant.subscription_end && (
                  <p className="mt-0.5 text-slate-600">
                    Renews <span className="font-semibold text-slate-800">{fmtDate(tenant.subscription_end)}</span>
                    {days !== null && days >= 0 && <span className="ml-1 text-xs text-slate-400">({days}d left)</span>}
                  </p>
                )}
                {tenant.subscription_start && (
                  <p className="mt-1 text-xs text-slate-400">Started {fmtDate(tenant.subscription_start)}</p>
                )}
              </div>
            )}

            {tenant.status === 'suspended' && (
              <div className="rounded-xl p-3.5 border bg-red-50 border-red-200 text-sm text-red-700">
                <p className="font-semibold">Account suspended</p>
                <p className="mt-0.5 text-xs text-red-400">Contact support or wait for a payment confirmation.</p>
              </div>
            )}

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Calendar className="w-3.5 h-3.5" /> Member since {fmtDate(tenant.created_at)}
            </div>
          </div>

          {/* Quick stats */}
          <div className="flex flex-col gap-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 uppercase tracking-wide font-medium mb-1">Invoices</p>
                <p className="text-2xl font-bold text-slate-800">{invoices.length}</p>
                <p className="text-xs text-slate-400 mt-0.5">{invoices.filter(i => i.status === 'paid').length} paid</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
                <FileText className="w-5 h-5 text-brand" />
              </div>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-slate-400 uppercase tracking-wide font-medium flex items-center gap-1">
                  <Database className="w-3.5 h-3.5" /> DB Usage
                </p>
                <span className="text-xs font-semibold text-slate-600">{fmtBytes(dbSize)}</span>
              </div>
              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${dbPct > 80 ? 'bg-red-500' : dbPct > 50 ? 'bg-orange-400' : 'bg-brand'}`}
                  style={{ width: `${Math.max(dbPct, 1)}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">{dbPct.toFixed(1)}% of 500 MB</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  /* ── Section: Billing ── */
  const BillingSection = () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Billing History</h1>
        <p className="text-slate-500 text-sm mt-0.5">All invoices issued to your account.</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading && invoices.length === 0 ? (
          <div className="p-10 text-center text-slate-400 text-sm">Loading…</div>
        ) : invoices.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <FileText className="w-9 h-9 text-slate-300 mx-auto" />
            <p className="text-slate-500 text-sm font-medium">No invoices yet</p>
            <p className="text-slate-400 text-xs">Invoices will appear here once raised by the FlippedPOS team.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="text-left px-5 py-3 text-[11px] text-slate-400 uppercase tracking-wide font-semibold">Invoice</th>
                  <th className="text-left px-4 py-3 text-[11px] text-slate-400 uppercase tracking-wide font-semibold">Plan</th>
                  <th className="text-left px-4 py-3 text-[11px] text-slate-400 uppercase tracking-wide font-semibold">Period</th>
                  <th className="text-right px-4 py-3 text-[11px] text-slate-400 uppercase tracking-wide font-semibold">Amount</th>
                  <th className="text-left px-4 py-3 text-[11px] text-slate-400 uppercase tracking-wide font-semibold">Date</th>
                  <th className="text-left px-4 py-3 text-[11px] text-slate-400 uppercase tracking-wide font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5 font-mono text-xs text-slate-500">{inv.invoice_number}</td>
                    <td className="px-4 py-3.5 text-slate-700">{inv.plan_name || '—'}</td>
                    <td className="px-4 py-3.5 text-slate-500 capitalize">{periodLabel[inv.billing_period] ?? inv.billing_period ?? '—'}</td>
                    <td className="px-4 py-3.5 text-right font-semibold text-slate-800">{inv.currency} {Number(inv.amount).toFixed(2)}</td>
                    <td className="px-4 py-3.5 text-slate-400 text-xs whitespace-nowrap">{fmtDate(inv.issued_at)}</td>
                    <td className="px-4 py-3.5">
                      {inv.status === 'paid' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-semibold">
                          <CheckCircle2 className="w-3 h-3" /> Paid
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">
                          <Clock className="w-3 h-3" /> Pending
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );

  /* ── Section: Instance ── */
  const InstanceSection = () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-800">My POS Instance</h1>
        <p className="text-slate-500 text-sm mt-0.5">Your hosted FlippedPOS environment details.</p>
      </div>

      {tenant && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-5 max-w-lg">
          <div className="space-y-4">
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1">Business Name</p>
              <p className="text-slate-800 font-semibold text-lg">{tenant.business_name}</p>
            </div>
            <div className="h-px bg-slate-100" />
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1">Customer Code</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="font-mono text-brand bg-brand/5 border border-brand/20 px-3 py-1.5 rounded-lg font-semibold text-sm">
                  {tenant.customer_code}
                </span>
                <button
                  onClick={() => copyText(tenant.customer_code, 'code')}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                  title="Copy"
                >
                  {copied === 'code' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="h-px bg-slate-100" />
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1">Instance URL</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-sm text-slate-600 font-mono bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg truncate">
                  {POS_BASE}/{tenant.tenant_slug}/admin
                </span>
                <button
                  onClick={() => copyText(`${POS_BASE}/${tenant.tenant_slug}/admin`, 'url')}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex-shrink-0"
                >
                  {copied === 'url' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="h-px bg-slate-100" />
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-2">Database Usage</p>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-sm text-slate-600 font-medium">{fmtBytes(dbSize)}</span>
                <span className="text-xs text-slate-400">of 500 MB</span>
              </div>
              <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${dbPct > 80 ? 'bg-red-500' : dbPct > 50 ? 'bg-orange-400' : 'bg-brand'}`}
                  style={{ width: `${Math.max(dbPct, 1)}%` }}
                />
              </div>
              <p className="text-xs text-slate-400 mt-1">{dbPct.toFixed(1)}% used</p>
            </div>
          </div>

          {tenant.tenant_slug && (
            <a
              href={`${POS_BASE}/${tenant.tenant_slug}/admin/login`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-brand text-black text-sm font-bold hover:bg-brand/90 transition-colors"
            >
              Open POS Dashboard <ExternalLink className="w-4 h-4" />
            </a>
          )}
        </div>
      )}
    </div>
  );

  return (
    <div className="flex h-screen bg-[#eef0f5] font-sans overflow-hidden">
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-64 z-50">
            <Sidebar mobile />
          </div>
        </div>
      )}

      {/* Main area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center gap-3 flex-shrink-0 shadow-sm">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <p className="text-sm font-semibold text-slate-700 capitalize">{section}</p>
          </div>
          <button
            onClick={fetchMe}
            disabled={loading}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            title="Refresh"
          >
            {loading ? (
              <span className="flex items-center gap-1">
                <span className="w-1 h-1 bg-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1 h-1 bg-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1 h-1 bg-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </span>
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
          </button>
        </header>

        {/* Scrollable content */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-8 py-7">
          {section === 'overview'  && <OverviewSection />}
          {section === 'billing'   && <BillingSection />}
          {section === 'instance'  && <InstanceSection />}

          <p className="text-center text-xs text-slate-400 mt-8 pb-2">
            Need help?{' '}
            <a href="mailto:support@flippedpos.com" className="hover:text-slate-700 underline underline-offset-2 transition-colors">
              support@flippedpos.com
            </a>
          </p>
        </main>
      </div>
    </div>
  );
}
