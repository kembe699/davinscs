import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { CheckCircle2, XCircle, Loader2, ArrowLeft } from 'lucide-react';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;

export default function PaymentResult() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const orderTrackingId = searchParams.get('OrderTrackingId');
  const [status, setStatus] = useState<'processing' | 'completed' | 'failed'>('processing');
  const [attempts, setAttempts] = useState(0);

  useEffect(() => {
    if (!orderTrackingId) {
      setStatus('failed');
      return;
    }

    let intervalId: ReturnType<typeof setInterval>;

    const checkStatus = async () => {
      try {
        const res = await fetch(`${API}/pesapal/callback?OrderTrackingId=${orderTrackingId}`);
        const data = await res.json();

        if (data.status === 'completed') {
          setStatus('completed');
          clearInterval(intervalId);
        } else if (data.status === 'failed') {
          setStatus('failed');
          clearInterval(intervalId);
        } else {
          // pending, keep trying until 10 attempts (30s)
          setAttempts(a => {
            if (a >= 10) {
              clearInterval(intervalId);
              setStatus('failed');
              return a;
            }
            return a + 1;
          });
        }
      } catch (err) {
        console.error('Failed to check status', err);
        setAttempts(a => {
          if (a >= 10) {
            clearInterval(intervalId);
            setStatus('failed');
            return a;
          }
          return a + 1;
        });
      }
    };

    checkStatus(); // Initial check
    intervalId = setInterval(checkStatus, 3000);

    return () => clearInterval(intervalId);
  }, [orderTrackingId]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 text-foreground font-mono">
      <div className="w-full max-w-md bg-chassis border border-border-subtle p-8 text-center space-y-6">
        
        {status === 'processing' && (
          <div className="space-y-4">
            <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto" />
            <h1 className="text-xl font-bold uppercase tracking-wide">Processing Payment</h1>
            <p className="text-xs text-muted-foreground">Please wait while we confirm your payment with PesaPal... ({attempts}/10)</p>
          </div>
        )}

        {status === 'completed' && (
          <div className="space-y-4">
            <CheckCircle2 className="w-12 h-12 text-primary mx-auto" />
            <h1 className="text-xl font-bold uppercase tracking-wide text-primary">Payment Confirmed</h1>
            <p className="text-xs text-muted-foreground">Your transaction was successful. Your subscription has been updated.</p>
          </div>
        )}

        {status === 'failed' && (
          <div className="space-y-4">
            <XCircle className="w-12 h-12 text-red-500 mx-auto" />
            <h1 className="text-xl font-bold uppercase tracking-wide text-red-500">Payment Failed</h1>
            <p className="text-xs text-muted-foreground">We could not confirm your payment. Please try again or contact support if the issue persists.</p>
          </div>
        )}

        <div className="pt-6 border-t border-border-subtle">
          <button 
            onClick={() => navigate('/account')}
            className="flex items-center justify-center gap-2 w-full px-4 py-3 bg-background border border-border-subtle hover:bg-background/50 hover:border-foreground/20 text-xs uppercase tracking-widest transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Account
          </button>
        </div>

      </div>
    </div>
  );
}
