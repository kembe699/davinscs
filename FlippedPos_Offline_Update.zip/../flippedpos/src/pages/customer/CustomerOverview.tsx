import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, XCircle, Clock, Zap, Calendar, FileText, CreditCard, Building2, AlertTriangle, X, ArrowRight, Check } from 'lucide-react';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;

interface TenantInfo {
  business_name: string; customer_code: string; tenant_slug: string;
  status: 'active' | 'trial' | 'suspended';
  trial_ends_at: string; subscription_start: string | null; subscription_end: string | null;
  created_at: string; email: string;
}
interface Invoice { id: number; status: 'pending' | 'paid'; amount: number; currency: string; plan_name: string; }
interface Plan { id: number; name: string; price: string; sub_label: string; description: string; features: string[]; highlight: boolean; billing_period: string; }

function fmtDate(d: string | null) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}
function daysLeft(d: string | null) {
  if (!d) return null;
  return Math.ceil((new Date(d).getTime() - Date.now()) / 86400000);
}

function StatusBadge({ status }: { status: TenantInfo['status'] }) {
  if (status === 'active') return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 border border-primary/20 bg-primary/10 text-primary text-[10px] font-mono-tech uppercase tracking-widest">
      <CheckCircle2 className="w-3 h-3" /> Active
    </span>
  );
  if (status === 'trial') return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 border border-blue-500/20 bg-blue-500/10 text-blue-400 text-[10px] font-mono-tech uppercase tracking-widest">
      <Clock className="w-3 h-3" /> Trial
    </span>
  );
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 border border-red-500/20 bg-red-500/10 text-red-400 text-[10px] font-mono-tech uppercase tracking-widest">
      <XCircle className="w-3 h-3" /> Suspended
    </span>
  );
}

// Helper to calculate dynamic pricing
function getDisplayPrice(priceStr: string, period: string) {
  const num = parseFloat(priceStr.replace(/[^0-9.]/g, ''));
  if (isNaN(num)) return priceStr;
  
  const isUSD = priceStr.includes('$');
  let finalNum = num;
  
  if (period === 'quarterly') {
    finalNum = num * 3;
  } else if (period === 'annual') {
    finalNum = num * 12 * 0.95;
  }
  
  // Format keeping the original currency symbol if it was USD, otherwise just the number
  return isUSD ? `$${finalNum.toFixed(2)}` : finalNum.toString();
}

// ── Upgrade Modal ────────────────────────────────────────────────────────────
function UpgradeModal({ token, onClose, onSuccess }: { token: string; onClose: () => void; onSuccess: (msg: string) => void }) {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selected, setSelected] = useState<Plan | null>(null);
  const [period, setPeriod] = useState('monthly');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`${API}/pricing`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) {
          const parsed = data.map((p: any) => ({
            ...p,
            features: Array.isArray(p.features) ? p.features : JSON.parse(p.features || '[]'),
          }));
          setPlans(parsed);
          const popular = parsed.find((p: Plan) => p.highlight);
          setSelected(popular || parsed[0] || null);
          if (popular) setPeriod(popular.billing_period || 'monthly');
        }
      })
      .catch(() => setError('Failed to load plans'))
      .finally(() => setLoading(false));
  }, []);

  const handleSubscribe = async () => {
    if (!selected) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API}/customer/pay-subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ plan_id: selected.id, billing_period: period }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Subscription failed');
      
      if (data.redirect_url) {
        window.location.href = data.redirect_url;
      } else {
        onSuccess(data.message || 'Subscription request submitted!');
      }
    } catch (err: any) {
      setError(err.message);
      setSubmitting(false);
    }
  };

  const PERIODS = [
    { value: 'monthly', label: 'Monthly' },
    { value: 'quarterly', label: 'Quarterly' },
    { value: 'annual', label: 'Annual' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
      <div className="w-full max-w-2xl bg-chassis border border-border-subtle shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border-subtle">
          <div>
            <p className="text-[9px] font-mono-tech uppercase tracking-widest text-primary mb-1">Subscription</p>
            <h2 className="text-sm font-bold uppercase tracking-wide text-foreground">Choose Your Plan</h2>
          </div>
          <button onClick={onClose} className="p-1.5 border border-transparent hover:border-border-subtle text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {error}
            </div>
          )}

          {/* Billing period selector */}
          <div>
            <p className="text-[9px] font-mono-tech uppercase tracking-widest text-muted-foreground mb-3">Billing Period</p>
            <div className="flex gap-2">
              {PERIODS.map(p => (
                <button
                  key={p.value}
                  onClick={() => setPeriod(p.value)}
                  className={`px-4 py-2 text-[10px] font-mono-tech uppercase tracking-widest border transition-colors ${
                    period === p.value
                      ? 'bg-primary/10 border-primary/30 text-primary'
                      : 'border-border-subtle text-muted-foreground hover:text-foreground hover:border-foreground/20'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Plans */}
          {loading ? (
            <div className="py-10 text-center text-muted-foreground text-xs font-mono uppercase tracking-widest">Loading plans…</div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {plans.map(plan => {
                const isSelected = selected?.id === plan.id;
                return (
                  <button
                    key={plan.id}
                    onClick={() => setSelected(plan)}
                    className={`relative p-4 text-left border transition-all ${
                      isSelected
                        ? 'border-primary/40 bg-primary/5'
                        : 'border-border-subtle bg-background/30 hover:border-foreground/20'
                    }`}
                  >
                    {plan.highlight && (
                      <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-primary text-background text-[8px] font-bold px-2 py-0.5 uppercase tracking-widest whitespace-nowrap">
                        Popular
                      </span>
                    )}
                    {isSelected && (
                      <span className="absolute top-3 right-3 w-4 h-4 bg-primary flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-background" />
                      </span>
                    )}
                    <p className="text-[9px] font-mono-tech text-muted-foreground uppercase tracking-widest mb-2">{plan.name}</p>
                    <p className="text-xl font-bold text-foreground font-mono">{getDisplayPrice(plan.price, period)}</p>
                    <p className="text-[9px] text-muted-foreground mb-3">{plan.sub_label}</p>
                    <ul className="space-y-1.5">
                      {plan.features.slice(0, 4).map((f, i) => (
                        <li key={i} className="flex items-start gap-1.5 text-[9px] font-mono text-muted-foreground">
                          <CheckCircle2 className="w-3 h-3 text-primary flex-shrink-0 mt-0.5" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </button>
                );
              })}
            </div>
          )}

          {/* Summary + CTA */}
          {selected && (
            <div className="border border-border-subtle bg-background/50 p-4 flex items-center justify-between gap-4">
              <div>
                <p className="text-[9px] text-muted-foreground font-mono-tech uppercase tracking-widest mb-1">Selected</p>
                <p className="text-sm font-bold text-foreground font-mono">
                  {selected.name} — {getDisplayPrice(selected.price, period)} <span className="text-muted-foreground text-xs font-normal">/ {period}</span>
                </p>
                <p className="text-[10px] text-muted-foreground font-mono mt-1">
                  You will be redirected to PesaPal to complete payment securely in UGX.
                </p>
              </div>
              <button
                onClick={handleSubscribe}
                disabled={submitting}
                className="flex items-center gap-2 px-5 py-3 bg-primary text-background text-[10px] font-mono-tech uppercase tracking-widest hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
              >
                {submitting ? (
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                ) : (
                  <ArrowRight className="w-3.5 h-3.5" />
                )}
                {submitting ? 'Redirecting…' : 'Subscribe & Pay'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function CustomerOverview() {
  const navigate = useNavigate();
  const token = localStorage.getItem('customer_token') || '';
  const [tenant, setTenant] = useState<TenantInfo | null>(() => {
    try { return JSON.parse(localStorage.getItem('customer_tenant') || 'null'); } catch { return null; }
  });
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(!tenant);
  const [error, setError] = useState('');
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    if (!token) { navigate('/account'); return; }
    const headers = { Authorization: `Bearer ${token}` };
    fetch(`${API}/customer/me`, { headers })
      .then(r => r.json())
      .then(me => {
        if (me.error) { setError(me.error); return; }
        setTenant(me.tenant);
        setInvoices(me.invoices || []);
        localStorage.setItem('customer_tenant', JSON.stringify(me.tenant));
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [navigate, token]);

  if (loading) return <div className="flex items-center justify-center h-40 text-muted-foreground font-mono uppercase tracking-widest text-xs">Loading…</div>;

  const activeDate = tenant?.status === 'active' ? tenant.subscription_end : tenant?.trial_ends_at ?? null;
  const days = daysLeft(activeDate);
  const isExpiringSoon = days !== null && days >= 0 && days <= 7;
  const isExpired = days !== null && days < 0;
  const showUpgradeCTA = tenant?.status === 'trial' || tenant?.status === 'suspended';
  const paid = invoices.filter(i => i.status === 'paid');
  const pending = invoices.filter(i => i.status === 'pending');
  const totalSpent = paid.reduce((s, i) => s + Number(i.amount), 0);

  const handleUpgradeSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setShowUpgrade(false);
    // Refresh invoices
    fetch(`${API}/customer/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(me => { if (!me.error) setInvoices(me.invoices || []); });
  };

  return (
    <>
      {showUpgrade && (
        <UpgradeModal
          token={token}
          onClose={() => setShowUpgrade(false)}
          onSuccess={handleUpgradeSuccess}
        />
      )}

      <div className="space-y-6 w-full text-foreground">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold uppercase tracking-wide">{tenant?.business_name ?? 'My Account'}</h1>
            <p className="text-muted-foreground text-xs mt-1 font-mono">Welcome back — here's your account overview.</p>
          </div>
          {showUpgradeCTA && (
            <button
              onClick={() => setShowUpgrade(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-primary text-background text-[10px] font-mono-tech uppercase tracking-widest hover:bg-primary/90 transition-colors shrink-0"
            >
              <Zap className="w-3.5 h-3.5" /> Upgrade Plan
            </button>
          )}
        </div>

        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" /> {error}
          </div>
        )}

        {successMsg && (
          <div className="p-3 bg-primary/10 border border-primary/20 text-primary text-xs font-mono-tech uppercase tracking-widest flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" /> {successMsg}
          </div>
        )}

        {/* Upgrade prompt banner — trial expiring / expired */}
        {showUpgradeCTA && (
          <div className={`p-4 border flex items-center justify-between gap-4 ${isExpired ? 'bg-red-500/10 border-red-500/20' : 'bg-orange-500/10 border-orange-500/20'}`}>
            <div>
              <p className={`text-[10px] font-mono-tech uppercase tracking-widest mb-1 ${isExpired ? 'text-red-400' : 'text-orange-400'}`}>
                {isExpired ? 'Trial Expired' : `Trial ends in ${days} day${days !== 1 ? 's' : ''}`}
              </p>
              <p className="text-xs font-mono text-muted-foreground">
                Upgrade to a paid plan to keep your POS system running without interruption.
              </p>
            </div>
            <button
              onClick={() => setShowUpgrade(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-background text-[10px] font-mono-tech uppercase tracking-widest hover:bg-primary/90 transition-colors shrink-0"
            >
              Upgrade Now <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Stat cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Status', value: tenant ? <StatusBadge status={tenant.status} /> : '—', icon: <Zap className="w-5 h-5 text-primary" />, bg: 'bg-primary/5 border border-primary/10' },
            { label: 'Invoices', value: invoices.length, icon: <FileText className="w-5 h-5 text-violet-400" />, bg: 'bg-violet-500/5 border border-violet-500/10' },
            { label: 'Paid', value: `${paid.length}`, icon: <CreditCard className="w-5 h-5 text-primary" />, bg: 'bg-primary/5 border border-primary/10' },
            { label: 'Total Spent', value: `$${totalSpent.toFixed(2)}`, icon: <Building2 className="w-5 h-5 text-blue-400" />, bg: 'bg-blue-500/5 border border-blue-500/10' },
          ].map((s, i) => (
            <div key={i} className="bg-chassis border border-border-subtle p-4 flex items-center gap-3">
              <div className={`w-10 h-10 flex items-center justify-center flex-shrink-0 ${s.bg}`}>{s.icon}</div>
              <div className="min-w-0">
                <p className="text-[9px] text-muted-foreground font-mono-tech uppercase tracking-widest">{s.label}</p>
                <div className="text-sm font-bold text-foreground mt-1 font-mono">{s.value}</div>
              </div>
            </div>
          ))}
        </div>

        {tenant && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Subscription details */}
            <div className="bg-chassis border border-border-subtle p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-[10px] font-mono-tech uppercase tracking-widest text-primary flex items-center gap-2">
                  <Zap className="w-4 h-4" /> Subscription
                </h2>
                <StatusBadge status={tenant.status} />
              </div>

              {tenant.status === 'trial' && (
                <div className={`p-4 border text-xs font-mono ${isExpiringSoon ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' : 'bg-background border-border-subtle text-muted-foreground'}`}>
                  <p className="font-bold text-foreground uppercase tracking-widest text-[10px]">Trial Period</p>
                  <p className="mt-2">Ends <span className="font-bold text-foreground">{fmtDate(tenant.trial_ends_at)}</span>
                    {days !== null && days >= 0 && <span className="ml-1.5 opacity-70">({days} days left)</span>}
                    {days !== null && days < 0 && <span className="ml-1.5 text-orange-400 font-bold">(expired)</span>}
                  </p>
                  <p className="mt-2 text-[10px] opacity-70">Upgrade to a paid plan to continue using the system.</p>
                  <button
                    onClick={() => setShowUpgrade(true)}
                    className="mt-3 flex items-center gap-1.5 text-[10px] font-mono-tech uppercase tracking-widest text-primary hover:text-primary/80 transition-colors"
                  >
                    <Zap className="w-3 h-3" /> Choose a Plan →
                  </button>
                </div>
              )}

              {tenant.status === 'active' && (
                <div className={`p-4 border text-xs font-mono ${isExpiringSoon ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' : 'bg-primary/5 border-primary/20 text-foreground'}`}>
                  <p className="font-bold text-primary uppercase tracking-widest text-[10px]">Subscription Active</p>
                  {tenant.subscription_end && (
                    <p className="mt-2 text-foreground">Renews <span className="font-bold">{fmtDate(tenant.subscription_end)}</span>
                      {days !== null && days >= 0 && <span className="ml-1.5 text-[10px] text-muted-foreground">({days} days left)</span>}
                    </p>
                  )}
                  {tenant.subscription_start && (
                    <p className="mt-2 text-[10px] text-muted-foreground">Started {fmtDate(tenant.subscription_start)}</p>
                  )}
                </div>
              )}

              {tenant.status === 'suspended' && (
                <div className="p-4 border bg-red-500/10 border-red-500/20 text-xs font-mono text-red-400">
                  <p className="font-bold uppercase tracking-widest text-[10px]">Account Suspended</p>
                  <p className="mt-2">Contact support to restore access.</p>
                  <button
                    onClick={() => setShowUpgrade(true)}
                    className="mt-3 flex items-center gap-1.5 text-[10px] font-mono-tech uppercase tracking-widest text-primary hover:text-primary/80 transition-colors"
                  >
                    <Zap className="w-3 h-3" /> Resubscribe →
                  </button>
                </div>
              )}

              <div className="flex items-center gap-2 text-[10px] font-mono-tech uppercase tracking-widest text-muted-foreground pt-3 border-t border-border-subtle">
                <Calendar className="w-3.5 h-3.5" /> Member since {fmtDate(tenant.created_at)}
              </div>
            </div>

            {/* Recent invoices */}
            <div className="bg-chassis border border-border-subtle p-5 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-[10px] font-mono-tech uppercase tracking-widest text-primary flex items-center gap-2">
                  <CreditCard className="w-4 h-4" /> Recent Invoices
                </h2>
                <button onClick={() => navigate('/account/billing')} className="text-[9px] font-mono-tech text-muted-foreground hover:text-foreground uppercase tracking-widest transition-colors">
                  View all →
                </button>
              </div>
              <div className="flex-1 flex flex-col justify-center">
                {invoices.length === 0 ? (
                  <div className="py-6 text-center text-muted-foreground text-xs font-mono uppercase tracking-widest">No invoices yet.</div>
                ) : (
                  <div className="space-y-0.5">
                    {invoices.slice(0, 4).map(inv => (
                      <div key={inv.id} className="flex items-center justify-between py-2 border-b border-border-subtle last:border-0">
                        <div className="min-w-0">
                          <span className="text-xs font-mono text-foreground">{inv.currency} {Number(inv.amount).toFixed(2)}</span>
                          {inv.plan_name && <span className="ml-2 text-[9px] text-muted-foreground font-mono">{inv.plan_name}</span>}
                        </div>
                        {inv.status === 'paid' ? (
                          <span className="px-2 py-0.5 bg-primary/10 border border-primary/20 text-primary text-[9px] font-mono-tech uppercase tracking-widest shrink-0">Paid</span>
                        ) : (
                          <span className="px-2 py-0.5 bg-orange-500/10 border border-orange-500/20 text-orange-400 text-[9px] font-mono-tech uppercase tracking-widest shrink-0">Pending</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              {pending.length > 0 && (
                <div className="mt-4 p-3 bg-orange-500/10 border border-orange-500/20 text-[10px] font-mono text-orange-400 flex items-center gap-2 uppercase tracking-widest">
                  <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                  {pending.length} pending invoice{pending.length > 1 ? 's' : ''} — awaiting payment confirmation
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
