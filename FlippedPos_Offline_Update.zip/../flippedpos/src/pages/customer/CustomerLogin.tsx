import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Mail, Lock, ArrowRight, AlertCircle } from 'lucide-react';

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`;

const STATUS_MSGS: Record<string, string> = {
  ACCOUNT_SUSPENDED: 'Your account has been suspended. Please contact support.',
  TRIAL_EXPIRED: 'Your 7-day trial has expired. Please contact support to pay an invoice.',
  SUBSCRIPTION_EXPIRED: 'Your subscription has expired. Please contact support to renew.',
};

export default function CustomerLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API}/customer/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(STATUS_MSGS[data.error] || data.message || data.error || 'Login failed');
      }
      localStorage.setItem('customer_token', data.token);
      localStorage.setItem('customer_tenant', JSON.stringify(data.tenant));
      navigate('/account/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">

      {/* Logo & branding */}
      <div className="text-center mb-8">
        <img src="/logo.png" alt="FlippedPOS" className="h-20 w-auto mx-auto mb-5 object-contain" />
        <p className="font-mono-tech text-[10px] text-white tracking-[0.5em] uppercase mb-1">
          Customer Portal
        </p>
        <p className="text-xs text-white/70">
          Manage your FlippedPOS subscription &amp; billing
        </p>
      </div>

      {/* Card */}
      <div className="w-full max-w-xs bg-chassis border border-border-subtle p-6">

        {error && (
          <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono-tech mb-4">
            <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="font-mono-tech text-[10px] text-white uppercase tracking-widest block mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 pointer-events-none" />
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full h-11 pl-9 pr-4 bg-background border border-border-subtle text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-white/40 transition-colors"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="font-mono-tech text-[10px] text-white uppercase tracking-widest block mb-2">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 pointer-events-none" />
              <input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full h-11 pl-9 pr-4 bg-background border border-border-subtle text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-white/40 transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 bg-primary text-background font-bold uppercase tracking-widest text-xs hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-2"
          >
            {loading ? (
              <>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-1.5 h-1.5 bg-background rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </span>
                Signing in…
              </>
            ) : (
              <>Sign In <ArrowRight className="w-3.5 h-3.5" /></>
            )}
          </button>
        </form>
      </div>

      {/* Footer links */}
      <div className="mt-6 flex flex-col items-center gap-2">
        <p className="text-[10px] font-mono-tech text-white/60 uppercase tracking-widest">
          No account?{' '}
          <Link to="/register" className="text-white underline hover:text-white/80 transition-colors">
            Register here
          </Link>
        </p>
      </div>
    </div>
  );
}
