import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function TermsOfUse() {
  useEffect(() => { window.scrollTo(0, 0) }, [])

  return (
    <div className="min-h-screen bg-[#080a0e] text-zinc-100">
      <Navbar />
      <div className="max-w-4xl mx-auto px-6 pt-32 pb-16">
        <div className="mb-10">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-3">Legal</p>
          <h1 className="text-4xl font-black text-white mb-3">Terms of Use</h1>
          <p className="text-zinc-500 text-sm">Last updated: April 2026</p>
        </div>

        <div className="space-y-8 text-zinc-300 leading-relaxed">

          <Section title="1. Acceptance of Terms">
            <p>By accessing or using FlippedPos ("the Service"), you agree to be bound by these Terms of Use ("Terms"). If you do not agree to all of these Terms, you may not access or use the Service. These Terms apply to all users, including businesses and individuals who use the software in a self-hosted or cloud-hosted capacity.</p>
          </Section>

          <Section title="2. Description of Service">
            <p>FlippedPos is a point-of-sale and business management software system that includes features such as:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Sales processing and receipt generation</li>
              <li>Inventory and stock management</li>
              <li>Customer and supplier management</li>
              <li>Financial reporting and analytics</li>
              <li>User roles and permissions management</li>
              <li>Multi-currency transaction support</li>
            </ul>
            <p className="mt-3">The Service is available as a self-hosted solution (open source) or as a managed cloud-hosted subscription.</p>
          </Section>

          <Section title="3. Eligibility">
            <p>You must be at least 18 years of age and have the legal authority to enter into contracts on behalf of your business to use this Service. By using FlippedPos, you represent and warrant that you meet these requirements.</p>
          </Section>

          <Section title="4. Account Registration">
            <p>To use certain features of the Service, you must create an account. You agree to:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Provide accurate, current, and complete information during registration.</li>
              <li>Maintain and promptly update your account information.</li>
              <li>Keep your password secure and confidential.</li>
              <li>Notify us immediately of any unauthorised use of your account.</li>
              <li>Accept responsibility for all activities that occur under your account.</li>
            </ul>
          </Section>

          <Section title="5. Acceptable Use">
            <p>You agree to use FlippedPos only for lawful business purposes. You must NOT:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Use the Service for any illegal, fraudulent, or unauthorised purpose.</li>
              <li>Violate any applicable local, national, or international laws or regulations.</li>
              <li>Attempt to gain unauthorised access to any part of the Service or its related systems.</li>
              <li>Reverse engineer, decompile, or disassemble any part of the proprietary software.</li>
              <li>Use the Service to process transactions for prohibited goods or services.</li>
              <li>Introduce viruses, malware, or any other malicious code into the system.</li>
              <li>Interfere with or disrupt the integrity or performance of the Service.</li>
            </ul>
          </Section>

          <Section title="6. Subscription and Payment">
            <p>For paid cloud-hosted plans:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Subscription fees are billed monthly or annually as selected at signup.</li>
              <li>All fees are non-refundable except where required by law.</li>
              <li>We reserve the right to change pricing with 30 days' written notice.</li>
              <li>Failure to pay may result in suspension or termination of your account.</li>
              <li>You are responsible for all applicable taxes in your jurisdiction.</li>
            </ul>
            <p className="mt-3">The self-hosted version is provided free of charge under its open-source licence terms.</p>
          </Section>

          <Section title="7. Intellectual Property">
            <p>The FlippedPos name, logo, website design, and proprietary software components are owned by FlippedPos and protected by applicable intellectual property laws. The open-source portions of the software are made available under their respective licences.</p>
            <p className="mt-3">You retain full ownership of all business data you enter into the system. By using the hosted service, you grant us a limited licence to store and process that data solely for the purpose of providing the Service to you.</p>
          </Section>

          <Section title="8. Data and Privacy">
            <p>Your use of the Service is also governed by our <Link to="/privacy" className="text-brand hover:underline">Privacy Policy</Link>, which is incorporated into these Terms by reference. By using the Service, you consent to our collection and use of data as described in the Privacy Policy.</p>
          </Section>

          <Section title="9. Disclaimer of Warranties">
            <p>THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. TO THE FULLEST EXTENT PERMITTED BY LAW, WE DISCLAIM ALL WARRANTIES INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.</p>
            <p className="mt-3">We do not warrant that the Service will be uninterrupted, error-free, or completely secure. You use the Service at your own risk.</p>
          </Section>

          <Section title="10. Limitation of Liability">
            <p>TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, FLIPPEDPOS SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING LOSS OF PROFITS, DATA, OR BUSINESS OPPORTUNITIES, ARISING FROM YOUR USE OF OR INABILITY TO USE THE SERVICE.</p>
            <p className="mt-3">Our total liability to you for any claim arising from these Terms or the Service shall not exceed the total amount you paid us in the three months preceding the claim.</p>
          </Section>

          <Section title="11. Termination">
            <p>We reserve the right to suspend or terminate your access to the Service at our sole discretion, with or without notice, for conduct that we believe violates these Terms or is harmful to other users, us, or third parties.</p>
            <p className="mt-3">You may terminate your account at any time by contacting us. Upon termination, your right to use the Service will immediately cease.</p>
          </Section>

          <Section title="12. Governing Law">
            <p>These Terms shall be governed by and construed in accordance with the laws of the Republic of South Sudan, without regard to its conflict of law provisions. Any disputes arising under these Terms shall be subject to the exclusive jurisdiction of the courts of Juba, South Sudan.</p>
          </Section>

          <Section title="13. Changes to Terms">
            <p>We reserve the right to modify these Terms at any time. We will provide notice of significant changes by posting the updated Terms on our website with a revised "Last updated" date. Your continued use of the Service after changes are posted constitutes your acceptance of the new Terms.</p>
          </Section>

          <Section title="14. Contact Us">
            <div className="card-border rounded-xl p-5 space-y-1">
              <p><strong className="text-white">FlippedPos</strong></p>
              <p>Juba, South Sudan</p>
              <p>Email: <a href="mailto:info@flippedpos.com" className="text-brand hover:underline">info@flippedpos.com</a></p>
              <p>Phone: <a href="tel:+211920000000" className="text-brand hover:underline">+211 92 000 0000</a></p>
            </div>
          </Section>

        </div>
      </div>
      <Footer />
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-3 pb-2 border-b border-white/8">{title}</h2>
      <div className="space-y-3 text-zinc-400">{children}</div>
    </div>
  )
}
