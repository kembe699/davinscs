export const docsContent = `
# SYSTEM DOCUMENTATION

## Unified Point-of-Sale + E-Commerce Platform

**For Any Business That Sells — Products or Services**

**Version 1.0  |  2025**  
*Confidential — Internal Use Only*

---

## 1. About FlippedPOS
FlippedPOS is a unified Point-of-Sale (POS) and E-Commerce platform built for any business that sells — whether you run a pharmacy, restaurant, supermarket, boutique, electronics shop, hardware store, salon, or any other retail or service-based business. It is a 2-in-1 system that lets you manage in-store operations and a branded online storefront from a single admin panel, with no syncing, no duplication, and no switching between tools.

| Business Type | Examples |
|---|---|
| **Retail & General Shops** | Convenience stores, gift shops, bookshops, stationery |
| **Pharmacies & Health** | Drug stores, clinics, optical shops, wellness centres |
| **Food & Beverage** | Restaurants, cafes, fast food outlets, juice bars |
| **Grocery & Supermarkets** | Supermarkets, mini-marts, fresh produce stores |
| **Fashion & Lifestyle** | Boutiques, shoe shops, salons, spas, barbershops |
| **Technical & Electronics** | Phone shops, electronics, hardware, auto parts |
| **Services** | Laundries, printing shops, repair centres, studios |

> **The FlippedPOS Story**  
> FlippedPOS started as a simple e-commerce website project for a single client. When that client repeatedly dodged and rejected the proposal, the developer flipped the rejection into something far bigger — a full POS + E-Commerce product applicable to any business, anywhere. Every feature in this system exists because of that pivot.

### 1.1 What FlippedPOS Does
* Run a complete in-store POS terminal — cashier, sales, refunds, cash management, end-of-day reporting
* Operate a fully branded public e-commerce storefront — product browsing, cart, checkout, order tracking
* Manage everything from one admin panel — products, inventory, procurement, accounting, invoices, promotions, currencies, and price lists
* Works for any store type: retail, pharmacy, restaurant, supermarket, salon, hardware, electronics, and more
* Customize storefront layout, branding, and contact details in real time — no code required

### 1.2 System Access URLs

| Location | URL |
|---|---|
| **Public Website (Storefront)** | \`http://localhost:8080\` |
| **Admin Panel / Backend API** | \`https://app.flippedpos.com\` |

### 1.3 Technology Stack

| Layer | Technology |
|---|---|
| **Frontend** | React 18, TypeScript, Vite, TailwindCSS |
| **UI Components** | shadcn/ui, Lucide Icons |
| **Backend** | Node.js, Express.js |
| **Database** | PostgreSQL |
| **Authentication** | JWT Tokens (stored in localStorage) |
| **File Handling** | Base64 image encoding |
| **Spreadsheet** | XLSX library — import & export |
| **Styling** | Custom theme with CSS variables |

## 2. User Roles & Authentication
FlippedPOS uses a Role-Based Access Control (RBAC) system. Each admin user is assigned a role that defines exactly which modules and actions they can access. The sidebar automatically shows only what each user is permitted to see.

### 2.1 Login & Password Reset
* Login page at \`/admin/login\` — email and password authentication
* On successful login, a JWT token is issued and stored locally
* Protected routes redirect to login if the token is missing or expired
* Password reset available at \`/admin/reset-password\`

### 2.2 Built-In Roles

| Role | Typical Access Level |
|---|---|
| **Admin** | Full access to all modules, settings, users, and reports |
| **Manager** | Products, inventory, orders, reports, and promotions |
| **Cashier** | POS terminal, sales history, and cash management only |

Roles are fully customizable — permissions are assigned per module: \`products.view\`, \`pos.access\`, \`orders.view\`, \`reports.view\`, \`accounting.view\`, and more.

### 2.3 User Management  (\`/admin/users\`)
* View all system users
* Create new users — assign email, password, and role
* Edit role assignments for existing users
* Delete users and reset passwords

## 3. Company Settings  (\`/admin/company\`)
The central configuration page for your business. Every setting saved here is reflected live on the public website immediately — no code changes or deployments needed.

### 3.1 Company Logo
* Upload a PNG or JPG logo (recommended: 500 × 500 px)
* Displayed automatically in: the website navbar, footer, contact page, and all printed receipts

### 3.2 Basic Business Information

| Field | Where It Appears |
|---|---|
| **Company Name** | Website navbar, footer, receipts, and page titles |
| **Email** | Website footer and contact page |
| **Phone Number** | Website footer and contact page |
| **Website URL** | Business website reference link |
| **WhatsApp Number** | WhatsApp chat links on the website (digits only, include country code) |
| **Tax ID / Reg. Number** | All printed invoices and receipts |

### 3.3 Address Information
Street Address, City, Postal Code, and Country — displayed dynamically in the website footer and contact page.

### 3.4 Company Description
Appears on the Contact and About sections of the website. Also used as the footer text on all printed receipts.

### 3.5 Website Layout Picker
Choose from 6 professionally designed homepage layouts. The selected layout saves immediately and the storefront reflects it on next page refresh.

| Layout Name | Description |
|---|---|
| **Tech Grid (Default)** | Dark technical aesthetic, 12-column hero, 3-column mono product grid |
| **Magazine** | Editorial split-screen hero, image left, content right, overlay category cards |
| **Minimal** | Clean centered headline, generous white space, 6-column category strip |
| **Showcase** | Cinematic full-height hero, horizontal scroll product picker |
| **Bold** | Oversized typography, numbered featured products, high-contrast grid |
| **Boutique** | Luxury elegant, portrait hero image, refined 3-column product grid |

## 4. Product Management  (\`/admin/products\`)
Products in FlippedPOS represent anything your business sells — physical goods, medications, food items, services, or bundled packages. The same product catalogue powers both your POS terminal and your online store.

### 4.1 Product List
* Search by name, brand, or category
* Filter by category using the dropdown
* Table columns: Name, Brand, Category, Price, Stock, Status

### 4.2 Adding & Editing a Product

| Field | Description |
|---|---|
| **Name** | The product or service display name |
| **Slug** | URL-friendly ID for the product page (e.g. \`paracetamol-500mg\`) |
| **Brand / Supplier** | Manufacturer, brand, or supplier name |
| **Category** | The category this product belongs to |
| **Description** | Rich text description shown on the website product page |
| **Base Price** | The selling price shown to customers |
| **Cost Price** | Purchase cost — used to calculate profit margins in reports |
| **Initial Stock Quantity** | Starting inventory count |
| **Low Stock Threshold** | Alert triggers when stock falls below this number |
| **Images** | Upload multiple product images |
| **Status** | Active = visible on website and POS; Inactive = hidden |
| **Featured** | Mark as featured to display prominently on the homepage |
| **Tax Rate** | Assign a tax rate for automatic tax calculation at checkout |

### 4.3 Bulk Import & Export
* **Export**: Downloads all products as a \`.xlsx\` spreadsheet
* **Import**: Upload a \`.xlsx\` or \`.csv\` file to bulk-create products — useful for large catalogues like pharmacies or supermarkets
* Duplicate slug detection prevents overwriting existing records

### 4.4 Deleting a Product
* A confirmation prompt appears before deletion
* Deleted products are removed from the website and POS immediately

## 5. Category Management  (\`/admin/categories\`)
Categories organize your product catalogue and appear in the website navigation and product filters. You can create categories that match your specific business type — e.g. Prescription Drugs, Over-the-Counter, Main Course, Beverages, Fresh Produce, Electronics, Apparel, and so on.

* Create, edit, and delete categories at any time
* Each category has a name and a slug (URL identifier)
* Every product is assigned to one category
* Categories appear in the website navigation bar and POS filter tabs

## 6. Inventory Management  (\`/admin/inventory\`)
* View current stock levels for all products in one table
* Manually adjust stock — add or subtract units with a logged reason
* Low stock indicator highlights products below their set threshold
* All stock movements are tracked for full audit history
* Stock deducted automatically with every POS sale or online order
* Stock restored automatically when a refund is processed

## 7. Procurement  (\`/admin/procurement\`)
Full purchase order management for restocking from suppliers — whether you are ordering medications, groceries, raw ingredients, or any other goods.

### 7.1 Purchase Orders
* Create purchase orders for one or more products from a supplier
* Fields: Supplier, expected delivery date, line items (product, quantity, unit cost)
* Status flow: Draft → Sent → Partially Received → Received → Cancelled

### 7.2 Goods Received Notes (GRN)
* When stock arrives, create a GRN against the corresponding Purchase Order
* Enter actual received quantities per line item
* GRN automatically increases inventory stock — no manual adjustment needed
* Partial deliveries are supported; remaining balance is tracked

### 7.3 Suppliers
* Manage your full supplier list: name, contact details, and address
* Link each supplier to their purchase orders

### 7.4 Bills
* Bills are auto-generated from received GRNs
* Track outstanding amounts owed to each supplier
* Mark bills as paid when payment is made

## 8. Price Lists  (\`/admin/price-lists\`)
Price lists allow you to offer different pricing tiers to different customer groups — for example Retail vs. Wholesale pricing for a supermarket, or Standard vs. Insurance pricing for a pharmacy.

* Create multiple named price lists — e.g. Retail, Wholesale, VIP, Staff, Insurance
* Each list overrides the base product price for selected products
* Assign a price list to a POS session or specific customer
* Cart prices update automatically when a price list is selected
* Bulk upload price list items via \`.xlsx\` import
* Price lists can be configured per currency

## 9. Promotions  (\`/admin/promotions\`)
* Create discount promotions with configurable rules
* Types: Percentage discount or Fixed amount discount
* Scope: Apply to entire order, or to specific products/categories
* Set a start and end date — promotions activate and expire automatically
* Applied at the POS during checkout via code or manual selection
* Promotion name is tracked on each sale for reporting and analytics

## 10. Currencies & Exchange Rates  (\`/admin/currencies\`)
* Define multiple currencies (e.g. SSP, UGX, USD, KES)
* Set one currency as the base/default display currency
* Set exchange rates against the base currency
* POS currency selector allows cashiers to accept payment in any currency
* Prices converted automatically using the stored exchange rate

## 11. Payment Types  (\`/admin/payment-types\`)
* Define all accepted payment methods — Cash, Mobile Money, Card, Bank Transfer, Insurance, Voucher, etc.
* Each payment type has a name and optional notes
* Used across POS checkout, refunds, and invoice payments
* Each payment type is tracked separately in the end-of-day report

## 12. Tax Rates  (\`/admin/tax-rates\`)
* Define tax rates by name and percentage — e.g. VAT 18%, Zero-Rated 0%, Exempt
* Assign specific tax rates to individual products
* Tax calculated automatically on POS and e-commerce checkout
* Tax amounts fully itemized on all receipts and invoices

## 13. Accounting  (\`/admin/accounting\`)
### 13.1 Chart of Accounts
* Full double-entry bookkeeping chart of accounts
* Account types: Asset, Liability, Equity, Revenue, Expense
* Create, edit, and delete accounts

### 13.2 Journal Entries
* Manual journal entries with debit/credit pairs
* Attach notes and dates to each entry

### 13.3 Financial Reports
* Profit & Loss summary
* Revenue vs expense tracking
* Account balance overview

### 13.4 Payments Tracking
* Track all payments received and made
* Link payments to invoices, bills, and purchase orders

## 14. Invoices  (\`/admin/invoices\`)
* Create professional invoices for customers or business clients
* Fields: Customer name/email, line items (product/service, quantity, price, tax), notes, due date
* Statuses: Draft, Sent, Paid, Overdue
* Invoice number auto-generated
* Print or export to PDF — formatted with your company logo, address, and Tax ID
* Tax fully itemized per line on every invoice
* All branding pulled dynamically from company settings

## 15. Reports  (\`/admin/reports\`)
### 15.1 Sales Reports
* Sales summary by custom date range
* Revenue by product, category, or cashier
* Daily, weekly, and monthly breakdowns
* Average order value

### 15.2 Inventory Reports
* Current stock levels across all products
* Stock movement history and audit trail
* Low stock alerts list

### 15.3 Profit & Loss
* Revenue minus cost of goods sold
* Gross margin per product

### 15.4 Customer Reports
* Order count per customer
* Customer spending history

### 15.5 Export
All report data can be exported to \`.xlsx\` spreadsheet for further analysis or accounting.

## 16. Admin Dashboard  (\`/admin\`)
Real-time business overview at a glance.

| Widget | Description |
|---|---|
| **Sales Today** | Total revenue generated for the current day |
| **Total Orders** | Count of all orders and POS sales |
| **Low Stock Alerts** | Products currently below their threshold |
| **Recent Sales** | Live feed of the latest transactions |
| **Revenue Chart** | Graphical sales trend over a selected time period |
| **Top Products** | Best-selling items ranked by units sold |
| **Quick Stats** | Total products, categories, and active promotions count |

## 17. E-Commerce Orders  (\`/admin/orders\`)
* View all orders placed through the public website
* Statuses: Pending, Processing, Shipped, Delivered, Cancelled
* Full order details: customer info, items, totals, payment status
* Update order status as it progresses through fulfilment
* Print order summary for packing or dispatch

## 18. Point of Sale (POS) System
The POS is a full in-store cashier terminal at \`/pos\`. Designed for speed — a cashier can process a complete sale in seconds, whether in a pharmacy, restaurant, supermarket, or any other store.

### 18.1 POS Main Terminal  (\`/pos\`)
**Product Browsing & Cart**
* Grid of all active products with images, names, and prices
* Search bar to find products instantly by name
* Category filter tabs for quick browsing
* Add items to cart with + / − quantity controls; remove individual items
* Apply a promotion code or select an active promotion from a list
* Cart shows: item list, subtotal, discount, tax, and grand total

**Customer Assignment**
* Search and select an existing customer
* Create a new customer on the fly during checkout
* Customer linked to the sale for history and reporting

**Price List Selection**
* Select a price list (Retail, Wholesale, Insurance, Staff, etc.)
* All cart prices update automatically to the selected list

**Payment Processing**
* Select payment type: Cash, Mobile Money, Card, Insurance, Bank Transfer, etc.
* Select currency — automatic exchange rate conversion applied
* Enter amount tendered — system calculates change due
* Split payment across multiple payment types supported

**Receipt Printing**
A formatted receipt is generated for the thermal printer or browser print. Includes: company logo, name, address, itemized products/services, tax, total, payment method, cashier name, date/time, and sale number.

**Sale Completion**
Each completed sale is saved with: sale number, cashier, customer, all line items, totals, payment method, currency, exchange rate, and promotion applied. Stock is automatically deducted for every item sold.

### 18.2 Sales History  (\`/pos/sales-history\`)
* View all completed sales — defaults to today
* Search by customer name or sale number
* View full sale details — all line items, quantities, and prices
* Reprint receipt for any past sale

**Refund Workflow:**
* Select items and quantities to refund
* Enter refund reason and select refund payment method
* On submission: inventory restored, refund record created, original sale updated
* Refunded sales show a REFUND badge; voided sales show with strikethrough
* Void/Delete an entire sale — admin only

### 18.3 Cash Management  (\`/pos/cash-management\`)
* Open Session — enter opening cash at the start of each day or shift
* Close Session — enter closing cash; system calculates expected vs actual
* Cash Difference — over/short variance displayed clearly
* Full session history with amounts and cashier name

### 18.4 End of Day Report  (\`/pos/end-of-day\`)
A full A4-printable report covering the entire trading day.

| Report Section | Contents |
|---|---|
| **Summary Cards** | Total Sales, Gross Revenue, Tax Collected, Discounts Given, Net Revenue |
| **Refund Summary** | Count and total amount of all refunds for the day |
| **Payment Breakdown** | Revenue split by each payment type |
| **Cashier Breakdown** | Sales count and revenue per cashier |
| **Top Selling Products** | Ranked by units sold |
| **Refund Details** | Itemized list of all refunds |
| **Print** | Full A4 formatted printout with company logo and all sections |

## 19. Public Storefront (Website)
The customer-facing website is live at the root URL \`/\`. All content is fetched dynamically from the database — nothing is hardcoded. Any change in Admin → Company Settings appears on the website instantly.

### 19.1 Homepage
* Renders the layout selected from Admin → Company Settings
* All 6 layouts include: Hero section, Category grid, Featured products, About/marquee, and Footer
* Company name, logo, address, phone, and WhatsApp all fetched live

### 19.2 Product/Service Category Pages
* One page per category — filterable and searchable product grid
* Categories are fully customizable to match your business type
* Product cards show: image, name, brand/supplier, and price

### 19.3 Product Detail Page  (\`/:category/:slug\`)
* Full product page with image gallery
* Description, brand, price, and live stock status
* Add to Cart button
* Related products section and breadcrumb navigation

### 19.4 Shopping Cart  (\`/cart\`)
* View all cart items with quantities and pricing
* Update quantities or remove items
* Cart totals with tax — proceed to checkout

### 19.5 Checkout  (\`/checkout\`)
* Customer form: name, email, phone, and delivery address
* Order summary and payment method selection
* Submitting an order creates a Pending order in the admin panel

### 19.6 Contact Page  (\`/contact\`)
* Address, phone, email — all dynamic from company settings
* WhatsApp direct chat link — number from database
* Contact form that sends a WhatsApp message

### 19.7 Support Pages
* \`/support\`  — General support information
* \`/shipping\` — Shipping policy
* \`/returns\`  — Returns and refund policy
* \`/warranty\` — Warranty information

## 20. Key Workflows
### 20.1 Making a Sale (POS Flow)
1. **Open Session** - Go to Cash Management → Open Session. Enter the opening cash to start the shift.
2. **Browse & Add to Cart** - Search or browse products/services. Add items to the cart and adjust quantities.
3. **Assign Customer & Price List** - Select an existing customer or create a new one. Apply the appropriate price list.
4. **Apply Promotion** - Enter a promo code or select an active promotion to apply a discount.
5. **Process Payment** - Select payment type and currency. Enter amount tendered — change calculated automatically. Split payments supported.
6. **Complete & Print** - Sale saved. Stock deducted automatically. Print the receipt for the customer.

### 20.2 Processing a Refund
1. **Find the Sale** - Go to Sales History. Search by customer name or sale number.
2. **Initiate Refund** - Click Refund. Select items and quantities to return.
3. **Enter Details** - Enter the refund reason and select the refund payment method.
4. **Submit** - Inventory restored automatically. Refund record created. Original sale updated.

### 20.3 End of Day Procedure
1. **Run End of Day Report** - POS → End of Day Report. Review sales, payments, refunds, and cashier totals.
2. **Print the Report** - Print the full A4 report for your records.
3. **Close Session** - Cash Management → Close Session. Enter closing cash. Review variance.

### 20.4 Adding Products or Services
1. **New Product** - Admin → Products → New Product.
2. **Fill Details** - Enter name, slug, price, cost, category, and upload images. Works for physical goods, medications, menu items, or services.
3. **Set Status** - Set Featured = true for homepage. Set Status = Active to make it visible.
4. **Save** - Product appears immediately on the website storefront and in the POS grid.

### 20.5 Customizing Your Storefront
1. **Open Company Settings** - Admin → My Company.
2. **Update Branding** - Upload logo, fill in name, phone, email, WhatsApp, and address.
3. **Choose Layout** - Select one of 6 homepage layouts that best fits your brand.
4. **Save & View** - Save Changes. Visit the homepage — live immediately.

### 20.6 Receiving Stock from Suppliers
1. **Create Purchase Order** - Procurement → New PO. Select supplier, add products and quantities.
2. **Receive Stock** - When goods arrive, create a GRN against the Purchase Order.
3. **Enter Quantities** - Enter actual received quantities. Stock levels update automatically.
4. **Bill Generated** - Supplier bill created automatically. Mark as paid when payment is made.

## 21. Dynamic Content System
All public-facing website content is fetched live from the company settings database. Changes in the admin panel appear on the website with no code changes or deployments.

| Website Element | Database Source |
|---|---|
| **Company Name** | \`company_settings.company_name\` |
| **Logo** | \`company_settings.logo_url\` (base64) |
| **Address** | \`company_settings.address\`, city, country |
| **Phone Number** | \`company_settings.phone\` |
| **Email Address** | \`company_settings.email\` |
| **WhatsApp Number** | \`company_settings.whatsapp\` |
| **Homepage Layout** | \`company_settings.site_layout\` |
| **Receipt / About Text** | \`company_settings.receipt_footer\` |

## 22. Database Schema Reference

| Table | Purpose |
|---|---|
| \`users\` | Admin and cashier accounts |
| \`roles / permissions\` | RBAC role and permission definitions |
| \`company_settings\` | All company info and active site layout |
| \`products\` | Full product and service catalogue |
| \`categories\` | Product/service categories |
| \`inventory\` | Stock levels per product |
| \`pos_sales\` | Every POS transaction record |
| \`pos_sale_items\` | Line items for each POS sale |
| \`cash_drawer_sessions\` | POS cash open/close sessions |
| \`orders\` | E-commerce orders from the website |
| \`order_items\` | Line items for each e-commerce order |
| \`price_lists\` | Named price lists (Retail, Wholesale, etc.) |
| \`price_list_items\` | Per-product prices within each price list |
| \`promotions\` | Discount promotion rules |
| \`currencies\` | Currency definitions and codes |
| \`exchange_rates\` | Exchange rate vs base currency |
| \`payment_types\` | Cash, mobile money, card, insurance, etc. |
| \`tax_rates\` | Tax rate definitions |
| \`purchase_orders\` | Supplier purchase orders |
| \`grn / grn_items\` | Goods received notes |
| \`suppliers\` | Supplier contact records |
| \`invoices / invoice_items\` | Customer invoices |
| \`bills\` | Supplier bills |
| \`accounts\` | Chart of accounts |
| \`journal_entries\` | Double-entry bookkeeping records |
| \`customers\` | Customer records |

## 23. API Reference
All endpoints are under \`https://app.flippedpos.com/api/\`. Protected routes require a Bearer JWT token in the \`Authorization\` header.

| Endpoint | Purpose |
|---|---|
| \`POST /api/auth/login\` | Login and receive JWT token |
| \`GET /api/company\` | Fetch company settings (public) |
| \`POST /api/company\` | Save company settings (authenticated) |
| \`GET /api/products\` | List all products |
| \`POST /api/products\` | Create a new product |
| \`PUT /api/products/:id\` | Update an existing product |
| \`DELETE /api/products/:id\` | Delete a product |
| \`GET /api/categories\` | List all categories |
| \`GET /api/inventory\` | Get current stock levels |
| \`POST /api/pos/sales\` | Create a new POS sale |
| \`GET /api/pos/sales\` | Get sales history |
| \`POST /api/pos/sales/:id/refund\` | Process a refund |
| \`POST /api/pos/sales/:id/void\` | Void a sale (admin only) |
| \`GET /api/pos/reports/end-of-day\` | Fetch end-of-day report data |
| \`GET /api/currencies\` | List currencies |
| \`GET /api/price-lists\` | List price lists |
| \`GET /api/promotions\` | List active promotions |
| \`GET /api/payment-types\` | List payment types |
| \`GET /api/tax-rates\` | List tax rates |
| \`GET /api/invoices\` | List invoices |
| \`GET /api/orders\` | List e-commerce orders |
| \`GET /api/procurement\` | List purchase orders |
| \`GET /api/accounting/accounts\` | Chart of accounts |
| \`GET /api/reports/*\` | Various report endpoints |
| \`GET /api/dashboard\` | Dashboard statistics |
| \`GET /api/users\` | List admin users (authenticated) |
| \`GET /api/roles\` | List roles and permissions |

## 24. Why FlippedPOS?
FlippedPOS is one of the only platforms that combines a full retail POS with a customizable e-commerce storefront in a single unified system — and it works for every type of business.

Traditional platforms fall short:
* Square, Shopify POS, Lightspeed — POS only, or e-commerce only
* Most solutions require two separate platforms with constant manual syncing
* Industry-specific tools (pharmacy software, restaurant POS) don't offer an online storefront

FlippedPOS gives every client:

* **✓** One platform for both in-store and online sales — any business type
* **✓** Shared real-time inventory across POS and website — one sale, one deduction
* **✓** Same product catalogue for both channels — zero duplication
* **✓** Six unique brandable website layouts — no developer or designer needed
* **✓** Full accounting, procurement, and reporting built in — no third-party apps
* **✓** Multi-currency and multi-price list support out of the box
* **✓** Complete audit trail: every sale, refund, stock movement, and session logged
* **✓** Works for pharmacies, restaurants, supermarkets, boutiques, electronics shops, salons, and more

> **FlippedPOS  —  Rejection Flipped Into Value.**

*Document generated from live codebase analysis. All features described are implemented and functional.*
`
