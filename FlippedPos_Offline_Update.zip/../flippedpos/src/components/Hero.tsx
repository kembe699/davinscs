import { ArrowRight, CheckCircle, Play } from 'lucide-react'
import { useTranslation } from 'react-i18next'

export default function Hero() {
  const { t } = useTranslation()

  const HIGHLIGHTS = [
    t('hero.highlight1'),
    t('hero.highlight2'),
    t('hero.highlight3'),
  ]

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
      {/* Background glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-brand/5 blur-[120px] pointer-events-none" />
      <div className="absolute top-1/4 right-0 w-[400px] h-[400px] rounded-full bg-blue-500/5 blur-[100px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6 py-24 grid lg:grid-cols-2 gap-16 items-center">
        {/* Left — copy */}
        <div>
          <div className="inline-flex items-center gap-2 bg-brand/10 border border-brand/20 rounded-full px-4 py-1.5 text-brand text-xs font-medium mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse" />
            {t('hero.builtFor')}
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white leading-tight mb-6">
            {t('hero.titlePart1')}{' '}
            <span className="gradient-text">{t('hero.titlePart2')}</span>
          </h1>

          <p className="text-lg text-zinc-400 leading-relaxed mb-8 max-w-xl">
            {t('hero.description')}
          </p>

          <ul className="space-y-2 mb-10">
            {HIGHLIGHTS.map(h => (
              <li key={h} className="flex items-center gap-2 text-sm text-zinc-300">
                <CheckCircle size={16} className="text-brand flex-shrink-0" />
                {h}
              </li>
            ))}
          </ul>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="/register"
              className="inline-flex items-center justify-center gap-2 bg-brand hover:bg-brand-dark text-black font-bold px-6 py-3 rounded-xl transition-all glow"
            >
              {t('hero.getFlippedPos')} <ArrowRight size={18} />
            </a>
            <a
              href="#features"
              className="inline-flex items-center justify-center gap-2 border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white px-6 py-3 rounded-xl transition-all"
            >
              <Play size={16} className="text-brand" /> {t('hero.seeFeatures')}
            </a>
          </div>
        </div>

        {/* Right — screenshots stacked */}
        <div className="flex flex-col gap-4">
          {/* Dashboard screenshot */}
          <div className="rounded-2xl overflow-hidden border border-white/10 glow">
            <img
              src="/dashh.png"
              alt="FlippedPos dashboard screenshot"
              className="w-full h-auto block"
            />
          </div>

          {/* POS terminal screenshot */}
          <div className="rounded-2xl overflow-hidden border border-white/10">
            <img
              src="/pooss.png"
              alt="FlippedPos POS terminal screenshot"
              className="w-full h-auto block"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
