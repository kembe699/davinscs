import { Check, Zap } from 'lucide-react'
import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'

export default function Pricing() {
  const { t } = useTranslation()

  const FALLBACK_PLANS = [
    {
      id: 0, name: t('pricing.plans.selfHosted.name'), price: t('pricing.plans.selfHosted.price'), sub_label: t('pricing.plans.selfHosted.sub_label'), highlight: false,
      description: t('pricing.plans.selfHosted.description'),
      features: t('pricing.plans.selfHosted.features', { returnObjects: true }) as string[],
      cta_label: t('pricing.plans.selfHosted.cta_label'), cta_href: 'https://github.com/kembe699/davinscs',
    },
    {
      id: 0, name: t('pricing.plans.professional.name'), price: t('pricing.plans.professional.price'), sub_label: t('pricing.plans.professional.sub_label'), highlight: true,
      description: t('pricing.plans.professional.description'),
      features: t('pricing.plans.professional.features', { returnObjects: true }) as string[],
      cta_label: t('pricing.plans.professional.cta_label'), cta_href: '/register',
    },
    {
      id: 0, name: t('pricing.plans.enterprise.name'), price: t('pricing.plans.enterprise.price'), sub_label: t('pricing.plans.enterprise.sub_label'), highlight: false,
      description: t('pricing.plans.enterprise.description'),
      features: t('pricing.plans.enterprise.features', { returnObjects: true }) as string[],
      cta_label: t('pricing.plans.enterprise.cta_label'), cta_href: '#contact',
    },
  ]

  const [plans, setPlans] = useState(FALLBACK_PLANS)

  // Update plans when language changes
  useEffect(() => {
    setPlans(FALLBACK_PLANS)
  }, [t])

  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas/pricing`)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data && data.length > 0) {
          setPlans(data.map((p: any) => ({
            ...p,
            features: Array.isArray(p.features) ? p.features : JSON.parse(p.features || '[]'),
          })))
        }
      })
      .catch(() => {})
  }, [])

  return (
    <section id="pricing" className="py-24 relative">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-3">{t('pricing.tagline')}</p>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white mb-4">
            {t('pricing.titlePart1')} <span className="gradient-text">{t('pricing.titlePart2')}</span>
          </h2>
          <p className="text-zinc-400 text-lg max-w-xl mx-auto">
            {t('pricing.desc')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {plans.map(plan => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-8 flex flex-col ${
                plan.highlight
                  ? 'bg-brand/10 border-2 border-brand/50 glow'
                  : 'card-border'
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-brand text-black text-xs font-bold px-4 py-1 rounded-full flex items-center gap-1 whitespace-nowrap">
                  <Zap size={11} className="fill-black" /> {t('pricing.mostPopular')}
                </div>
              )}

              <div className="mb-6">
                <p className={`text-xs font-mono uppercase tracking-widest mb-2 ${plan.highlight ? 'text-brand' : 'text-zinc-500'}`}>
                  {plan.name}
                </p>
                <div className="flex items-end gap-1 mb-2">
                  <span className="text-4xl font-black text-white">{plan.price}</span>
                  {plan.price !== t('pricing.plans.selfHosted.price') && plan.price !== t('pricing.plans.enterprise.price') && (
                    <span className="text-zinc-500 text-sm mb-1">{t('pricing.month')}</span>
                  )}
                </div>
                <p className="text-xs text-zinc-500">{plan.sub_label}</p>
                <p className="text-sm text-zinc-400 mt-3 leading-relaxed">{plan.description}</p>
              </div>

              <ul className="space-y-2.5 mb-8 flex-1">
                {plan.features.map((f: string) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-zinc-300">
                    <Check size={14} className="text-brand flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>

              <a
                href={plan.cta_href}
                target={plan.cta_href.startsWith('http') ? '_blank' : undefined}
                rel={plan.cta_href.startsWith('http') ? 'noopener noreferrer' : undefined}
                className={`block text-center font-semibold py-3 rounded-xl transition-all text-sm ${
                  plan.highlight
                    ? 'bg-brand hover:bg-brand-dark text-black'
                    : 'border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white'
                }`}
              >
                {plan.cta_label}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
