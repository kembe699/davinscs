import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Menu, X, ShoppingCart, Search, ChevronDown, Globe, Home, LayoutGrid, Sun, Moon } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api, ApiCategory } from "@/lib/api";
import { useLayout } from "@/contexts/LayoutContext";
import { useTenantPath } from "@/contexts/TenantContext";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";

const staticLinks = [
  { label: "Contact", to: "/contact" },
];

/* ── Mobile nav tab item ─────────────────────────────────── */
interface MobileNavTabProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
  id: string;
}

const MobileNavTab = ({ icon, label, isActive, onClick, id }: MobileNavTabProps) => {
  const [ripple, setRipple] = useState(false);

  const handleClick = () => {
    setRipple(true);
    setTimeout(() => setRipple(false), 400);
    onClick();
  };

  return (
    <button
      id={id}
      type="button"
      onClick={handleClick}
      className="relative flex-1 flex flex-col items-center justify-center gap-[3px] overflow-hidden select-none focus:outline-none"
      style={{ WebkitTapHighlightColor: "transparent" }}
      aria-label={label}
    >
      {/* Ripple */}
      {ripple && (
        <span
          className="absolute inset-0 m-auto w-12 h-12 rounded-full animate-ping"
          style={{ background: "rgba(0,139,139,0.18)", animationDuration: "0.4s", animationIterationCount: 1 }}
        />
      )}

      {/* Icon wrapper — scales up & brightens when active */}
      <span
        className="transition-all duration-300"
        style={{
          transform: isActive ? "scale(1.22) translateY(-1px)" : "scale(1) translateY(0)",
          filter: isActive
            ? "drop-shadow(0 0 6px rgba(0,139,139,0.7))"
            : "none",
          color: isActive ? "#00d4d4" : "hsl(var(--muted-foreground))",
        }}
      >
        {icon}
      </span>

      {/* Label */}
      <span
        className="font-mono-tech text-[9px] uppercase tracking-[0.12em] transition-all duration-300"
        style={{
          color: isActive ? "#00d4d4" : "hsl(var(--muted-foreground))",
          fontWeight: isActive ? 700 : 400,
          letterSpacing: isActive ? "0.16em" : "0.12em",
        }}
      >
        {label}
      </span>
    </button>
  );
};

const Navbar = () => {
  const { t, i18n } = useTranslation();
  const { logo, companyName } = useLayout();
  const { theme, setTheme } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [categories, setCategories] = useState<ApiCategory[]>([]);
  const [cartCount, setCartCount] = useState(0);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [megaOpen, setMegaOpen] = useState(false);
  const megaLeaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const openMega  = () => { if (megaLeaveTimer.current) clearTimeout(megaLeaveTimer.current); setMegaOpen(true); };
  const closeMega = () => { megaLeaveTimer.current = setTimeout(() => setMegaOpen(false), 120); };
  const location = useLocation();
  const navigate = useNavigate();
  const tp = useTenantPath();

  const { user } = useAuth();

  // Determine active bottom-nav tab (0=Home, 1=Shop, 2=Search, 3=Cart)
  const activeTabIndex = (() => {
    const p = location.pathname;
    if (p === tp("/cart")) return 3;
    if (searchOpen) return 2;
    // any category / product page is still "Shop"
    if (p !== tp("/") && p !== "/") return 1;
    return 0; // home
  })();

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    document.documentElement.dir = lng === 'ar' ? 'rtl' : 'ltr';
    if (user) {
      localStorage.setItem(`i18nextLng_${user.id}`, lng);
    }
    setLangOpen(false);
  };

  useEffect(() => {
    document.documentElement.dir = i18n.language.startsWith('ar') ? 'rtl' : 'ltr';
    api.categories.list().then(setCategories).catch(() => {});
  }, [i18n.language]);

  useEffect(() => {
    const loadCartCount = async () => {
      try {
        const items = await api.cart.get();
        setCartCount(items.reduce((sum, item) => sum + item.quantity, 0));
      } catch {
        setCartCount(0);
      }
    };
    loadCartCount();
    const interval = setInterval(loadCartCount, 5000);
    return () => clearInterval(interval);
  }, [location.pathname]);

  useEffect(() => {
    const prev = document.body.style.paddingBottom;
    // Account for safe-area-inset-bottom too
    document.body.style.paddingBottom = "calc(64px + env(safe-area-inset-bottom, 0px))";
    return () => {
      document.body.style.paddingBottom = prev;
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    if (location.pathname !== tp("/")) {
      navigate(tp(`/?q=${encodeURIComponent(searchQuery.trim())}`));
    } else {
      const params = new URLSearchParams(location.search);
      params.set("q", searchQuery.trim());
      navigate(`${location.pathname}?${params.toString()}`);
      const el = document.getElementById("shop");
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }
    setSearchOpen(false);
  };

  const toggleSearch = () => {
    setSearchOpen(o => !o);
    setTimeout(() => searchRef.current?.focus(), 50);
  };

  const categoryLinks = categories.map((c) => ({
    label: c.name,
    to: tp(`/${c.slug}`),
  }));
  const tenantStaticLinks = staticLinks.map((l) => ({ ...l, to: tp(l.to) }));

  const visibleCategoryLinks = categoryLinks.slice(0, 4);
  const overflowLinks = categoryLinks.slice(4);

  const overflowCategories = categories.slice(4);

  return (
    <div className="sticky top-0 z-50">
    <nav className="border-b border-border-subtle px-6 lg:px-8 h-16 flex items-center justify-between bg-chassis/95 backdrop-blur-md relative">
      <div className="flex items-center gap-8 lg:gap-12">
        <Link to={tp("/")} className="flex items-center">
          {logo
            ? <img src={logo} alt={companyName || "Logo"} className="h-14 w-auto object-contain" />
            : <span className="font-bold text-sm text-foreground tracking-widest uppercase">{companyName}</span>
          }
        </Link>
        <div className="hidden lg:flex items-center gap-6 text-xs font-medium uppercase tracking-widest text-muted-foreground">
          {visibleCategoryLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`hover:text-primary transition-colors whitespace-nowrap ${location.pathname.startsWith(link.to) ? "text-primary" : ""}`}
            >
              {link.label}
            </Link>
          ))}
          {overflowLinks.length > 0 && (
            <div onMouseEnter={openMega} onMouseLeave={closeMega}>
              <button
                type="button"
                className={`flex items-center gap-1 transition-colors ${megaOpen ? "text-primary" : "hover:text-primary"}`}
              >
                More <ChevronDown size={11} className={`transition-transform duration-200 ${megaOpen ? "rotate-180" : ""}`} />
              </button>
            </div>
          )}
          <div className="w-px h-4 bg-border-subtle" />
          {tenantStaticLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`hover:text-primary transition-colors whitespace-nowrap ${location.pathname.startsWith(link.to) ? "text-primary" : ""}`}
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="hidden lg:flex items-center gap-4 font-mono-tech text-xs">
        {/* Search */}
        <form onSubmit={handleSearch} className="flex items-center">
          {searchOpen ? (
            <div className="flex items-center gap-1 border border-primary bg-chassis/90 px-2">
              <input
                ref={searchRef}
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search products…"
                className="bg-transparent text-xs text-foreground placeholder:text-muted-foreground outline-none py-1.5 w-44"
              />
              <button type="submit" className="text-primary hover:text-primary/80">
                <Search size={13} />
              </button>
              <button type="button" onClick={() => setSearchOpen(false)} className="text-muted-foreground hover:text-foreground ml-1">
                <X size={13} />
              </button>
            </div>
          ) : (
            <button type="button" onClick={toggleSearch} className="text-muted-foreground hover:text-primary transition-colors">
              <Search size={18} />
            </button>
          )}
        </form>

        {/* Language Switcher */}
        <div className="relative">
          <button 
            type="button"
            onClick={() => setLangOpen(!langOpen)} 
            className="flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors p-1"
          >
            <Globe size={18} />
            <span className="uppercase text-[10px]">{i18n.language.split('-')[0]}</span>
          </button>
          {langOpen && (
            <div className="absolute right-0 mt-2 w-32 bg-chassis border border-border-subtle rounded-md shadow-xl overflow-hidden py-1 z-50">
              <button onClick={() => changeLanguage('en')} className="block w-full text-left px-4 py-2 text-xs text-muted-foreground hover:bg-white/5 hover:text-primary">English</button>
              <button onClick={() => changeLanguage('ar')} className="block w-full text-left px-4 py-2 text-xs text-muted-foreground hover:bg-white/5 hover:text-primary">العربية</button>
              <button onClick={() => changeLanguage('fr')} className="block w-full text-left px-4 py-2 text-xs text-muted-foreground hover:bg-white/5 hover:text-primary">Français</button>
            </div>
          )}
        </div>

        {/* Theme Toggle */}
        <button
          type="button"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className="text-muted-foreground hover:text-primary transition-colors p-1"
        >
          {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        <span className="text-muted-foreground uppercase tracking-tighter hidden md:inline">Status: Open</span>
        <div className="size-2 bg-primary animate-pulse" />
      </div>

      <div className="flex lg:hidden items-center gap-4">
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden text-foreground"
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
          title={mobileOpen ? "Close" : "Menu"}
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {mobileOpen && (
        <div className="absolute top-16 left-0 right-0 bg-chassis border-b border-border-subtle p-6 flex flex-col gap-4 lg:hidden z-50">
          {[...visibleCategoryLinks, ...overflowLinks, ...tenantStaticLinks].map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`hover:text-primary transition-colors whitespace-nowrap ${location.pathname.startsWith(link.to) ? "text-primary" : ""}`}
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          {/* Theme toggle in mobile menu */}
          <button
            type="button"
            onClick={() => { setTheme(theme === 'dark' ? 'light' : 'dark'); setMobileOpen(false); }}
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors text-sm"
          >
            {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
            {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
          </button>
        </div>
      )}
    </nav>

    {/* ── Mega menu (hover) ──────────────────────────────── */}
    {overflowCategories.length > 0 && (
      <div
        onMouseEnter={openMega}
        onMouseLeave={closeMega}
        className={`absolute left-0 right-0 bg-chassis border-b border-border-subtle shadow-2xl z-40
          transition-all duration-200 ease-out
          ${megaOpen ? "opacity-100 translate-y-0 pointer-events-auto" : "opacity-0 -translate-y-2 pointer-events-none"}`}
      >
        <div className="max-w-[1440px] mx-auto px-6 lg:px-8 py-8">
          <p className="font-mono-tech text-[10px] text-primary tracking-[0.4em] uppercase mb-6">
            More Categories
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {overflowCategories.map((cat) => (
              <Link
                key={cat.id}
                to={tp(`/${cat.slug}`)}
                className="group/cat flex flex-col gap-3 hover:text-primary transition-colors"
              >
                <div className="aspect-square overflow-hidden border border-border-subtle bg-grip group-hover/cat:border-primary/40 transition-colors">
                  {cat.image_url ? (
                    <img
                      src={cat.image_url}
                      alt={cat.name}
                      className="w-full h-full object-cover opacity-80 group-hover/cat:opacity-100 group-hover/cat:scale-105 transition-all duration-500"
                      onError={(e) => { (e.currentTarget as HTMLImageElement).src = "/placeholder.svg"; }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="font-mono-tech text-2xl font-black text-primary/20">
                        {cat.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>
                <span className="font-mono-tech text-[10px] font-semibold uppercase tracking-widest text-muted-foreground group-hover/cat:text-primary transition-colors leading-snug">
                  {cat.name}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    )}

    {/* ── Mobile Search Drawer (slides up above bottom nav) ─── */}
    <div
      className="fixed left-0 right-0 z-[49] lg:hidden"
      style={{
        bottom: "calc(64px + env(safe-area-inset-bottom, 0px))",
        transform: searchOpen ? "translateY(0)" : "translateY(100%)",
        transition: "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        pointerEvents: searchOpen ? "auto" : "none",
      }}
    >
      <form
        onSubmit={handleSearch}
        className="bg-chassis/95 backdrop-blur-xl border-t border-border-subtle shadow-[0_-4px_24px_rgba(0,0,0,0.35)] px-4 py-3 flex items-center gap-3"
      >
        <Search size={16} className="text-muted-foreground shrink-0" style={{ color: searchOpen ? "#00d4d4" : undefined }} />
        <input
          ref={searchRef}
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search products…"
          className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none py-1"
        />
        {searchQuery && (
          <button type="submit" className="font-mono-tech text-[10px] uppercase tracking-widest px-3 py-1.5 border border-[#00d4d4]/40 text-[#00d4d4] hover:bg-[#00d4d4]/10 transition-colors">
            Go
          </button>
        )}
        <button type="button" onClick={() => setSearchOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors ml-1">
          <X size={16} />
        </button>
      </form>
    </div>

    {/* ── Modern Mobile Bottom Nav ──────────────────────────── */}
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      {/* Frosted glass bar — full width, no outer padding */}
      <div
        className="relative flex items-stretch bg-chassis/80 backdrop-blur-xl border-t border-border-subtle shadow-[0_-8px_32px_rgba(0,0,0,0.45)]"
        style={{ height: "64px" }}
      >
        {/* Sliding active pill indicator */}
        <div
          className="absolute bottom-0 transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)]"
          style={{
            left: `${activeTabIndex * 25}%`,
            width: "25%",
            height: "3px",
            background: "linear-gradient(90deg, var(--brand-start) 0%, var(--brand-mid) 50%, var(--brand-end) 100%)",
          }}
        />

        {/* Home Tab */}
        <MobileNavTab
          icon={<Home size={20} />}
          label="Home"
          isActive={activeTabIndex === 0}
          onClick={() => navigate(tp("/"))}
          id="bottom-nav-home"
        />

        {/* Shop Tab */}
        <MobileNavTab
          icon={<LayoutGrid size={20} />}
          label="Shop"
          isActive={activeTabIndex === 1}
          onClick={() => {
            if (location.pathname !== tp("/")) {
              navigate(tp("/"));
              setTimeout(() => {
                const el = document.getElementById("shop");
                if (el) el.scrollIntoView({ behavior: "smooth" });
              }, 300);
            } else {
              const el = document.getElementById("shop");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }
          }}
          id="bottom-nav-shop"
        />

        {/* Search Tab */}
        <MobileNavTab
          icon={<Search size={20} />}
          label="Search"
          isActive={activeTabIndex === 2}
          onClick={toggleSearch}
          id="bottom-nav-search"
        />

        {/* Cart Tab */}
        <MobileNavTab
          icon={
            <span className="relative inline-flex">
              <ShoppingCart size={20} />
              {cartCount > 0 && (
                <span
                  className="absolute -top-2 -right-2.5 min-w-[18px] h-[18px] flex items-center justify-center rounded-full text-[10px] font-bold leading-none text-black px-0.5"
                  style={{ background: "linear-gradient(90deg, var(--brand-start) 0%, var(--brand-mid) 50%, var(--brand-end) 100%)" }}
                >
                  {cartCount}
                </span>
              )}
            </span>
          }
          label="Cart"
          isActive={activeTabIndex === 3}
          onClick={() => navigate(tp("/cart"))}
          id="bottom-nav-cart"
        />
      </div>
    </div>
    </div>
  );
};

export default Navbar;
