import { useTranslation } from 'react-i18next'


export default function HowItWorks() {
  const { t } = useTranslation()

  const STEPS = [
    { number: '01', title: t('howItWorks.step1.title'), desc: t('howItWorks.step1.desc') },
    { number: '02', title: t('howItWorks.step2.title'), desc: t('howItWorks.step2.desc') },
    { number: '03', title: t('howItWorks.step3.title'), desc: t('howItWorks.step3.desc') },
  ]

  return (
    <section id="how-it-works" className="py-24 relative">
      {/* Subtle divider */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-3">{t('howItWorks.tagline')}</p>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white mb-4">
            {t('howItWorks.titlePart1')} <span className="gradient-text">{t('howItWorks.titlePart2')}</span>
          </h2>
          <p className="text-zinc-400 text-lg max-w-xl mx-auto">
            {t('howItWorks.desc')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connector line */}
          <div className="hidden md:block absolute top-12 left-1/6 right-1/6 h-px bg-gradient-to-r from-brand/30 via-brand/60 to-brand/30" />

          {STEPS.map((step, i) => (
            <div key={step.number} className="relative text-center group">
              {/* Step circle */}
              <div className="relative inline-flex items-center justify-center w-24 h-24 rounded-full border-2 border-brand/30 bg-brand/5 mb-6 group-hover:border-brand/60 group-hover:bg-brand/10 transition-all glow-sm">
                <span className="font-mono font-bold text-2xl text-brand">{step.number}</span>
                <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-brand" />
              </div>

              <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
              <p className="text-zinc-400 leading-relaxed max-w-xs mx-auto">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
