import { useState, useRef } from 'react'
import { ArrowRight, Mail, Phone, MessageCircle, Send, X, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'
import { useTranslation } from 'react-i18next'

const API = `${import.meta.env.VITE_API_URL || 'https://app.flippedpos.com'}/api/saas`

interface FormState {
  name: string
  email: string
  phone: string
  message: string
}

type Status = 'idle' | 'sending' | 'success' | 'error'

export default function CTA() {
  const { t } = useTranslation()
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState<FormState>({ name: '', email: '', phone: '', message: '' })
  const [status, setStatus] = useState<Status>('idle')
  const [statusMsg, setStatusMsg] = useState('')
  const formRef = useRef<HTMLDivElement>(null)

  const toggle = () => {
    setOpen(o => !o)
    if (status === 'success') {
      setStatus('idle')
      setForm({ name: '', email: '', phone: '', message: '' })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('sending')
    setStatusMsg('')
    try {
      const res = await fetch(`${API}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to send')
      setStatus('success')
      setStatusMsg(data.message || t('cta.messageSent'))
    } catch (err: any) {
      setStatus('error')
      setStatusMsg(err.message || 'Something went wrong. Please try again.')
    }
  }

  const set = (k: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      {/* Big glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-brand/8 blur-[100px] rounded-full pointer-events-none" />

      <div className="relative max-w-5xl mx-auto px-6">
        <div className="card-border rounded-3xl p-6 sm:p-10 md:p-16 text-center border-brand/20">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-4">{t('cta.tagline')}</p>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white mb-4 leading-tight">
            {t('cta.titlePart1')}<br />
            <span className="gradient-text">{t('cta.titlePart2')}</span>
          </h2>
          <p className="text-zinc-400 text-lg max-w-xl mx-auto mb-10">
            {t('cta.desc')}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            {/* Email Us — triggers slide-down form */}
            <button
              onClick={toggle}
              className={`inline-flex items-center gap-2 font-bold px-7 py-3.5 rounded-xl transition-all glow ${
                open
                  ? 'bg-zinc-700 text-white hover:bg-zinc-600'
                  : 'bg-brand hover:bg-brand-dark text-black'
              }`}
            >
              {open ? <X size={18} /> : <Mail size={18} />}
              {open ? t('cta.closeForm') : t('cta.emailUs')}
              {!open && <ArrowRight size={16} />}
            </button>

            <a
              href="https://wa.me/211920000000"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white px-7 py-3.5 rounded-xl transition-all"
            >
              <MessageCircle size={18} className="text-green-400" /> {t('cta.whatsapp')}
            </a>
          </div>

          {/* ── Slide-down contact form ── */}
          <div
            ref={formRef}
            style={{
              maxHeight: open ? '600px' : '0px',
              opacity: open ? 1 : 0,
              overflow: 'hidden',
              transition: 'max-height 0.45s cubic-bezier(0.4,0,0.2,1), opacity 0.35s ease',
            }}
          >
            <div className="mt-2 mb-8 text-left max-w-2xl mx-auto bg-white/5 border border-white/10 rounded-2xl p-8">
              {status === 'success' ? (
                <div className="flex flex-col items-center justify-center py-8 gap-4 text-center">
                  <div className="w-14 h-14 rounded-full bg-green-500/15 border border-green-500/30 flex items-center justify-center">
                    <CheckCircle className="w-7 h-7 text-green-400" />
                  </div>
                  <div>
                    <p className="text-white font-bold text-lg">{t('cta.messageSent')}</p>
                    <p className="text-zinc-400 text-sm mt-1">{statusMsg}</p>
                  </div>
                  <button
                    onClick={toggle}
                    className="mt-2 text-sm text-zinc-400 hover:text-white underline transition-colors"
                  >
                    {t('cta.sendAnother')}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-8 h-8 rounded-lg bg-brand/20 border border-brand/30 flex items-center justify-center flex-shrink-0">
                      <Mail className="w-4 h-4 text-brand" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">{t('cta.formTitle')}</p>
                      <p className="text-zinc-500 text-xs">{t('cta.formSubtitle')}</p>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-1.5">
                        {t('cta.fullName')} <span className="text-brand">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={set('name')}
                        placeholder={t('cta.fullName')}
                        className="w-full h-11 px-4 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-zinc-600 focus:outline-none focus:border-brand/50 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-1.5">
                        {t('cta.email')} <span className="text-brand">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        value={form.email}
                        onChange={set('email')}
                        placeholder="you@example.com"
                        className="w-full h-11 px-4 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-zinc-600 focus:outline-none focus:border-brand/50 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-1.5">
                      {t('cta.phone')} <span className="text-zinc-600">{t('cta.phoneOptional')}</span>
                    </label>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={set('phone')}
                      placeholder="+211 92 000 0000"
                      className="w-full h-11 px-4 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-zinc-600 focus:outline-none focus:border-brand/50 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-400 uppercase tracking-widest mb-1.5">
                      {t('cta.message')} <span className="text-brand">*</span>
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={form.message}
                      onChange={set('message')}
                      placeholder="Tell us about your business and what you need…"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-zinc-600 focus:outline-none focus:border-brand/50 transition-colors resize-none"
                    />
                  </div>

                  {status === 'error' && (
                    <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm">
                      <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                      {statusMsg}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={status === 'sending'}
                    className="w-full h-12 bg-brand hover:bg-brand-dark text-black font-bold rounded-xl transition-all glow disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {status === 'sending' ? (
                      <>
                      <span className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-1.5 h-1.5 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </span>
                        {t('cta.sending')}
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        {t('cta.sendMessage')}
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Contact details */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-zinc-500">
            <a href="mailto:info@flippedpos.com" className="flex items-center gap-2 hover:text-zinc-300 transition-colors">
              <Mail size={14} /> info@flippedpos.com
            </a>
            <span className="hidden sm:block text-zinc-700">·</span>
            <a href="tel:+211920000000" className="flex items-center gap-2 hover:text-zinc-300 transition-colors">
              <Phone size={14} /> +211 92 000 0000
            </a>
            <span className="hidden sm:block text-zinc-700">·</span>
            <span>Juba, South Sudan</span>
          </div>
        </div>
      </div>
    </section>
  )
}
