import { useTranslation } from 'react-i18next'


export default function Testimonials() {
  const { t } = useTranslation()

  const TESTIMONIALS = [
    {
      name: t('testimonials.items.t1.name'),
      role: t('testimonials.items.t1.role'),
      body: t('testimonials.items.t1.body'),
      initials: 'MA',
    },
    {
      name: t('testimonials.items.t2.name'),
      role: t('testimonials.items.t2.role'),
      body: t('testimonials.items.t2.body'),
      initials: 'PD',
    },
    {
      name: t('testimonials.items.t3.name'),
      role: t('testimonials.items.t3.role'),
      body: t('testimonials.items.t3.body'),
      initials: 'GL',
    },
  ]

  return (
    <section className="py-24 relative">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-3">{t('testimonials.tagline')}</p>
          <h2 className="text-4xl lg:text-5xl font-black text-white mb-4">
            {t('testimonials.titlePart1')} <span className="gradient-text">{t('testimonials.titlePart2')}</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map(t => (
            <div key={t.name} className="card-border rounded-2xl p-6 hover:border-white/15 transition-all">
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} viewBox="0 0 20 20" className="w-4 h-4 fill-brand">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>

              <p className="text-zinc-300 text-sm leading-relaxed mb-6">"{t.body}"</p>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-brand/20 flex items-center justify-center text-brand text-xs font-bold">
                  {t.initials}
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{t.name}</p>
                  <p className="text-xs text-zinc-500">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
