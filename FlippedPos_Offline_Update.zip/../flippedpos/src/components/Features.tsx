import {
  ShoppingCart, BarChart3, Package, Users, Receipt, CreditCard,
  Shield, Globe, Smartphone, FileText, Tag, Printer
} from 'lucide-react'
import { useTranslation } from 'react-i18next'


export default function Features() {
  const { t } = useTranslation()

  const FEATURES = [
    { icon: ShoppingCart, title: t('features.items.pos.title'), desc: t('features.items.pos.desc') },
    { icon: Package, title: t('features.items.inventory.title'), desc: t('features.items.inventory.desc') },
    { icon: BarChart3, title: t('features.items.reports.title'), desc: t('features.items.reports.desc') },
    { icon: Users, title: t('features.items.customer.title'), desc: t('features.items.customer.desc') },
    { icon: Receipt, title: t('features.items.invoicing.title'), desc: t('features.items.invoicing.desc') },
    { icon: CreditCard, title: t('features.items.payment.title'), desc: t('features.items.payment.desc') },
    { icon: Globe, title: t('features.items.currency.title'), desc: t('features.items.currency.desc') },
    { icon: Shield, title: t('features.items.roles.title'), desc: t('features.items.roles.desc') },
    { icon: FileText, title: t('features.items.procurement.title'), desc: t('features.items.procurement.desc') },
    { icon: Tag, title: t('features.items.promotions.title'), desc: t('features.items.promotions.desc') },
    { icon: Printer, title: t('features.items.receipt.title'), desc: t('features.items.receipt.desc') },
    { icon: Smartphone, title: t('features.items.devices.title'), desc: t('features.items.devices.desc') },
  ]

  return (
    <section id="features" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-brand text-xs font-mono uppercase tracking-widest mb-3">{t('features.tagline')}</p>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white mb-4">
            {t('features.titlePart1')} <span className="gradient-text">{t('features.titlePart2')}</span>
          </h2>
          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            {t('features.desc')}
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {FEATURES.map((f) => {
            const Icon = f.icon
            return (
              <div
                key={f.title}
                className="card-border rounded-2xl p-5 hover:border-brand/30 hover:bg-brand/5 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center mb-4 group-hover:bg-brand/20 transition-colors">
                  <Icon size={20} className="text-brand" />
                </div>
                <h3 className="font-semibold text-white mb-2">{f.title}</h3>
                <p className="text-sm text-zinc-400 leading-relaxed">{f.desc}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
