const fs = require('fs');
const path = require('path');

const dir = '/home/levi96/Documents/Int/flippedpos/src';
const filesToFix = [
  'components/Pricing.tsx',
  'components/CTA.tsx',
  'pages/saas-admin/SaaSLogin.tsx',
  'pages/customer/CustomerOverview.tsx',
  'pages/customer/CustomerLogin.tsx',
  'pages/customer/CustomerInstance.tsx',
  'pages/customer/CustomerDashboard.tsx',
  'pages/customer/CustomerBilling.tsx',
  'pages/Register.tsx',
  'pages/saas-admin/SaaSDashboard.tsx'
];

filesToFix.forEach(file => {
  const filePath = path.join(dir, file);
  if (fs.existsSync(filePath)) {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Replace const API = 'http://localhost:3001/api/saas' and fetch('http://localhost:3001/api/saas/pricing')
    content = content.replace(/'http:\/\/localhost:3001([^']*)'/g, "`\${import.meta.env.VITE_API_URL || 'http://localhost:3001'}$1`");
    
    fs.writeFileSync(filePath, content);
    console.log(`Fixed ${file}`);
  }
});
