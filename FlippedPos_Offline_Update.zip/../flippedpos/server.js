import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// Serve all static files from the Vite build output
app.use(express.static(path.join(__dirname, 'dist')));

// SPA fallback — every unmatched route returns index.html
// so React Router can handle /admin, /register, /account, etc.
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`FlippedPOS website running on port ${PORT}`);
});
